#include "my_filter.h"

void my_filter(
    hls::stream<axis24_t> &stream_in,
    hls::stream<axis24_t> &stream_out
) {
#pragma HLS INTERFACE axis port=stream_in
#pragma HLS INTERFACE axis port=stream_out
#pragma HLS INTERFACE ap_ctrl_none port=return

  for (;;) {
#pragma HLS PIPELINE II=1
    // Free-running in hardware; exit when TB input is drained in C-sim.
#ifndef __SYNTHESIS__
    if (stream_in.empty())
      break;
#endif
    axis24_t pix = stream_in.read();

    ap_uint<8> b = pix.data.range(7, 0);
    ap_uint<8> g = pix.data.range(15, 8);
    ap_uint<8> r = pix.data.range(23, 16);

    ap_uint<8> y = (r + g + b) / 3;
    pix.data.range(7, 0)   = y;
    pix.data.range(15, 8)  = y;
    pix.data.range(23, 16) = y;
    

    stream_out.write(pix);
  }
}
