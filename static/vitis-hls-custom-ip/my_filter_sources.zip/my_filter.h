#include "ap_axi_sdata.h"
#include "ap_int.h"
#include "hls_stream.h"


// 24-bit RGB, 1-bit TUSER (SOF), TID/TDEST present (unused is fine)
typedef ap_axiu<24, 1, 1, 1> axis24_t;

extern "C" void my_filter(
    hls::stream<axis24_t> &stream_in,
    hls::stream<axis24_t> &stream_out
);