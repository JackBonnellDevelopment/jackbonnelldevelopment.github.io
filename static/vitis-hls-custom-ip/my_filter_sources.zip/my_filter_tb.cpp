// C-simulation testbench for my_filter (grayscale)
//
// Vitis HLS GUI:
//   Design Sources: my_filter.cpp (+ my_filter.h)
//   Test Bench:     my_filter_tb.cpp
//   Top function:   my_filter
//   Run C Simulation
#include <cstdio>
#include "my_filter.h"
static const int WIDTH = 8;
static const int HEIGHT = 4;
static axis24_t make_pix(ap_uint<8> r, ap_uint<8> g, ap_uint<8> b,
                         bool sof, bool eol) {
  axis24_t p;
  p.data = 0;
  p.data.range(7, 0) = b;
  p.data.range(15, 8) = g;
  p.data.range(23, 16) = r;
  p.keep = 0x7;
  p.strb = 0x7;
  p.user = sof ? 1 : 0;
  p.last = eol ? 1 : 0;
  p.id = 0;
  p.dest = 0;
  return p;
}
static void fill_frame(hls::stream<axis24_t> &s) {
  for (int y = 0; y < HEIGHT; ++y) {
    for (int x = 0; x < WIDTH; ++x) {
      ap_uint<8> r = (ap_uint<8>)(30 + x * 10);
      ap_uint<8> g = (ap_uint<8>)(60 + y * 20);
      ap_uint<8> b = (ap_uint<8>)(90);
      s.write(make_pix(r, g, b, (x == 0 && y == 0), (x == WIDTH - 1)));
    }
  }
}
static int check_frame(hls::stream<axis24_t> &dst, bool gray) {
  int errors = 0;
  for (int y = 0; y < HEIGHT; ++y) {
    for (int x = 0; x < WIDTH; ++x) {
      if (dst.empty()) {
        std::printf("ERROR: missing pixel (%d,%d)\n", x, y);
        return 1;
      }
      axis24_t out = dst.read();
      ap_uint<8> r_in = (ap_uint<8>)(30 + x * 10);
      ap_uint<8> g_in = (ap_uint<8>)(60 + y * 20);
      ap_uint<8> b_in = 90;
      ap_uint<8> r_exp = r_in;
      ap_uint<8> g_exp = g_in;
      ap_uint<8> b_exp = b_in;
      if (gray) {
        ap_uint<8> yv = (r_in + g_in + b_in) / 3;
        r_exp = g_exp = b_exp = yv;
      }
      ap_uint<8> r_out = out.data.range(23, 16);
      ap_uint<8> g_out = out.data.range(15, 8);
      ap_uint<8> b_out = out.data.range(7, 0);
      bool sof = (x == 0 && y == 0);
      bool eol = (x == WIDTH - 1);
      if (r_out != r_exp || g_out != g_exp || b_out != b_exp ||
          out.user != (sof ? 1 : 0) || out.last != (eol ? 1 : 0)) {
        std::printf(
            "Mismatch (%d,%d) gray=%d: got (%u,%u,%u) u=%u l=%u "
            "exp (%u,%u,%u) u=%u l=%u\n",
            x, y, gray ? 1 : 0, (unsigned)r_out, (unsigned)g_out,
            (unsigned)b_out, (unsigned)out.user, (unsigned)out.last,
            (unsigned)r_exp, (unsigned)g_exp, (unsigned)b_exp, sof ? 1 : 0,
            eol ? 1 : 0);
        ++errors;
      }
    }
  }
  if (!dst.empty()) {
    std::printf("ERROR: extra output pixels\n");
    ++errors;
  }
  return errors;
}
int main() {
  hls::stream<axis24_t> src("src");
  hls::stream<axis24_t> dst("dst");
  int errors = 0;
  fill_frame(src);
  my_filter(src, dst);
  errors += check_frame(dst, true);
  if (errors) {
    std::printf("FAIL: %d error(s)\n", errors);
    return 1;
  }
  std::printf("PASS: passthrough + grayscale OK (%dx%d)\n", WIDTH, HEIGHT);
  return 0;
}