#!/usr/bin/env python3
"""Reassemble the TE0950 dual-MIPI UDP stitch and display one RGB8 image.

The board composes J15 | HS1 side-by-side and sends a single stream on UDP
55000 (640x180 RGB8 ≈ 30 fps). Left half = J15, right half = CR00240/HS1.
This viewer listens on that port only unless --dual is passed.
"""
import argparse
import socket
import struct
import sys
import time

# Little-endian mipi_udp_hdr (udp_stream.h): magic 'MIP1'
MAGIC = 0x3150494D
HDR_LEN = 24
HDR_FMT = "<IHHIIIHH"
PAYLOAD = 1460  # MIPI_UDP_PAYLOAD


def is_wsl():
    try:
        return "microsoft" in open("/proc/version", encoding="utf-8").read().lower()
    except OSError:
        return False


def iface_ipv4s():
    ips = []
    try:
        import subprocess

        out = subprocess.check_output(
            ["ip", "-4", "-o", "addr", "show"], stderr=subprocess.DEVNULL, text=True
        )
        for line in out.splitlines():
            parts = line.split()
            if "inet" in parts:
                ip = parts[parts.index("inet") + 1].split("/")[0]
                if ip and not ip.startswith("127.") and ip not in ips:
                    ips.append(ip)
    except Exception:
        pass
    return ips or local_ipv4s()


def local_ipv4s():
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip not in ips and not ip.startswith("127."):
            ips.append(ip)
    except OSError:
        pass
    return ips


def guess_lan_ip(ips):
    for ip in ips:
        if ip.startswith("192.168.8."):
            return ip
    return ips[0] if ips else "0.0.0.0"


_WINDOWS = set()
_LAST_SHOW = 0.0


def show_frame(title, w, h, raw, have_cv, np, cv2, view_scale, min_dt=1.0 / 30.0):
    """Draw at most ~30 fps to match board UDP pacing."""
    global _LAST_SHOW
    n_rgb = w * h * 3
    if not have_cv or len(raw) < n_rgb:
        return
    now = time.time()
    if (now - _LAST_SHOW) < min_dt:
        cv2.waitKey(1)
        return
    _LAST_SHOW = now

    img = np.frombuffer(raw[:n_rgb], dtype=np.uint8).reshape((h, w, 3))
    vis = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    # Label left/right halves for the default J15|HS1 stitch.
    if "J15" in title and w >= 2:
        mid = w // 2
        cv2.putText(
            vis, "J15", (8, max(16, h // 6)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1, cv2.LINE_AA,
        )
        cv2.putText(
            vis, "HS1", (mid + 8, max(16, h // 6)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1, cv2.LINE_AA,
        )
        cv2.line(vis, (mid, 0), (mid, h - 1), (0, 200, 0), 1)
    if view_scale != 1.0:
        vis = cv2.resize(
            vis,
            (max(1, int(w * view_scale)), max(1, int(h * view_scale))),
            interpolation=cv2.INTER_NEAREST,
        )
    if title not in _WINDOWS:
        cv2.namedWindow(title, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(
            title,
            max(1, int(w * view_scale)),
            max(1, int(h * view_scale)),
        )
        _WINDOWS.add(title)
    cv2.imshow(title, vis)
    cv2.waitKey(1)


def main():
    ap = argparse.ArgumentParser(
        description="Show TE0950 dual-MIPI stitch: J15 | HS1 on UDP 55000."
    )
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=55000)
    ap.add_argument("--dual", action="store_true")
    ap.add_argument("--save", action="store_true")
    ap.add_argument("--scale", type=float, default=2.0)
    ap.add_argument("--rgb", action="store_true", default=True)
    ap.add_argument("--bayer", action="store_true")
    args = ap.parse_args()

    ports = [args.port]
    if args.dual:
        ports.append(args.port + 1)

    socks = []
    bind_ip = args.bind
    local_ips = iface_ipv4s()
    if is_wsl():
        print(
            "This is WSL2. LAN unicast/broadcast may not reach WSL.\n"
            "Run Windows Python:\n"
            "  python host\\udp_viewer.py --rgb"
        )
    if bind_ip not in ("0.0.0.0", "", "::") and bind_ip not in local_ips:
        print(f"{bind_ip} not local; binding 0.0.0.0")
        bind_ip = "0.0.0.0"

    for port in ports:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
        try:
            s.bind((bind_ip, port))
        except OSError as e:
            if getattr(e, "winerror", None) == 10013:
                raise SystemExit(f"UDP port {port} blocked by Windows") from e
            raise
        s.settimeout(0.05)
        socks.append(s)
        print(f"listening UDP {bind_ip}:{port}")

    print(
        f"Expect J15|HS1 RGB stitch on {args.port} (~30 fps). "
        f"This PC: {guess_lan_ip(local_ips)}\n"
        "Board unicasts to 192.168.8.220. Ctrl+C to quit."
    )

    # Per socket: only the latest frame_id is kept (avoids RAM / GUI blow-ups).
    cur_id = [None] * len(socks)
    bufs = [None] * len(socks)
    offs = [None] * len(socks)  # set of received offsets
    need = [0] * len(socks)
    meta = [None] * len(socks)  # (w, h, total)
    pkt_n = [0] * len(socks)
    shown = [0] * len(socks)
    drop_n = [0] * len(socks)
    last_hb = time.time()

    try:
        import numpy as np
        import cv2

        have_cv = True
    except ImportError:
        np = cv2 = None
        have_cv = False
        print("numpy/cv2 missing — will only print frame lines")

    while True:
        now = time.time()
        if now - last_hb >= 2.0:
            for idx in range(len(socks)):
                cov = f"{len(offs[idx])}/{need[idx]}" if offs[idx] is not None else "-"
                print(
                    f"hb port={ports[idx]} pkts/2s={pkt_n[idx]} "
                    f"shown={shown[idx]} drop={drop_n[idx]} assembling={cov}"
                )
                pkt_n[idx] = 0
                shown[idx] = 0
                drop_n[idx] = 0
            last_hb = now
            if have_cv:
                cv2.waitKey(1)

        got_any = False
        for idx, s in enumerate(socks):
            # Drain several datagrams per tick so the socket does not overflow,
            # but pump the GUI between bursts.
            for _ in range(64):
                try:
                    pkt, _ = s.recvfrom(2048)
                except socket.timeout:
                    break
                got_any = True
                pkt_n[idx] += 1
                if len(pkt) < HDR_LEN:
                    continue
                magic, _cam, hdr_len, frame_id, offset, total, w, h = struct.unpack(
                    HDR_FMT, pkt[:HDR_LEN]
                )
                if magic != MAGIC or total == 0 or total > 8_000_000:
                    continue
                payload = pkt[hdr_len:]

                # New frame → drop any previous partial (keep only newest).
                if cur_id[idx] != frame_id:
                    if cur_id[idx] is not None and offs[idx] is not None:
                        if len(offs[idx]) < need[idx]:
                            drop_n[idx] += 1
                    cur_id[idx] = frame_id
                    bufs[idx] = bytearray(total)
                    offs[idx] = set()
                    need[idx] = (total + PAYLOAD - 1) // PAYLOAD
                    meta[idx] = (w, h, total)

                end = min(offset + len(payload), total)
                if end > offset:
                    bufs[idx][offset:end] = payload[: end - offset]
                    offs[idx].add(offset)

                if len(offs[idx]) < need[idx]:
                    continue

                raw = bytes(bufs[idx])
                ww, hh, _tot = meta[idx]
                title = "J15 | HS1" if idx == 0 and not args.dual else f"cam{idx}"
                print(f"{title} frame {frame_id} {ww}x{hh} {len(raw)} bytes")
                if args.save:
                    open(f"stitch_frame.bin" if idx == 0 else f"{title}_frame.bin", "wb").write(raw)
                show_frame(title, ww, hh, raw, have_cv, np, cv2, args.scale)
                shown[idx] += 1
                cur_id[idx] = None
                bufs[idx] = None
                offs[idx] = None
                need[idx] = 0
                meta[idx] = None

        if have_cv and not got_any:
            cv2.waitKey(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
