# TE0950 dual MIPI → UDP

Standalone Versal + Artix project: two IMX219 cameras into Gigabit Ethernet UDP.

| Stream | Hardware | I2C |
|--------|----------|-----|
| cam0 | On-board **J15** 15-pin CSI | AXI IIC (A13/B13), GPIO F11/E11 |
| cam1 | **CR00240** CSI on **CRUVI HS1 (J10)** | Artix PCA9548 ch0 → HS1 SMB |

Tools: Vivado / Vitis **2024.2**. Board: TE0950-03 (`xcve2302-sfva784-1LP-e-S`).

## Pipeline

```text
CSI → demosaic → VPSS (320×180) → v_frmbuf_wr  ×2
  → A72 side-by-side stitch (640×180 RGB8) → UDP :55000
```

Sensor capture is **1920×1080** RAW10. Each VPSS scales to a **320×180** tile.
PS stitches **J15 | HS1** to **640×180**. UDP is paced at **25 fps** so a 100 Mbit link can deliver whole frames. The cameras themselves run at about 48 fps.

## Quick start

```powershell
.\scripts\fetch_trenz_refs.ps1
.\scripts\build_artix.ps1
.\scripts\build_hw.ps1
.\scripts\build_sw.ps1
```

Then open Vitis Unified IDE on `sw_vitis\unified_ws` and run `dual_mipi_udp`.

UART: FTDI J2 @ **115200 8N1** (not the Vitis console).

Ethernet: DHCP on `192.168.8.0/24`, UDP **55000** (stitched **640×180** RGB).

```powershell
python host\udp_viewer.py --rgb
```

Rebuild the **Versal PDI** after a BD change (`.\scripts\build_hw.ps1`) before
loading a new ELF.

## Flash order

1. Program Artix bitstream (`hw_artix\export\te0950_artix_mipi.bit`)
2. Run / boot Versal PDI + `dual_mipi_udp.elf`

MIPI CSI-2 Rx Subsystem must be licensed in Vivado. Pin map: [`docs/pin_map.md`](docs/pin_map.md).
