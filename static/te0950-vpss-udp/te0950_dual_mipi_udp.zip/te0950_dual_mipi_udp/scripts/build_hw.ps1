# Build Versal dual-MIPI UDP HW on a short Windows path (MAX_PATH / PLM)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Short = "C:\t\mipi2"

Write-Host "Ensuring Trenz refs..."
& "$Root\scripts\fetch_trenz_refs.ps1"

if (Test-Path $Short) {
  for ($i = 0; $i -lt 8; $i++) {
    try {
      Remove-Item -Recurse -Force $Short -ErrorAction Stop
      break
    } catch {
      Write-Host "Retry remove $Short ($i): $_"
      Get-Process vivado*,vitis*,vitis_hls*,java* -ErrorAction SilentlyContinue |
        Stop-Process -Force -ErrorAction SilentlyContinue
      Start-Sleep 2
    }
  }
  if (Test-Path $Short) {
    cmd /c "rmdir /s /q `"$Short`""
  }
  if (Test-Path $Short) { Write-Error "Cannot remove $Short - close Vivado/HLS locking it" }
}
New-Item -ItemType Directory -Force -Path "$Short\export" | Out-Null
Copy-Item "$Root\board_files\trenz" "$Short\board_files" -Recurse -Force
Copy-Item "$Root\hw_versal\constraints" "$Short\constraints" -Recurse -Force
if (Test-Path "$Root\hw_versal\ip_repo") {
  Copy-Item "$Root\hw_versal\ip_repo" "$Short\ip_repo" -Recurse -Force
}
Copy-Item "$Root\hw_versal\scripts" "$Short\scripts" -Recurse -Force
Copy-Item "$Root\hw_versal\hdl" "$Short\hdl" -Recurse -Force

$cfg = @"
set ::TE0950_PART        `"xcve2302-sfva784-1LP-e-S`"
set ::TE0950_BOARD       `"trenz.biz:te0950_23_1lse:part0:1.1`"
set ::PROJ_NAME          `"te0950_dual_mipi_udp`"
set ::PL0_CLK_MHZ        100.000
set ::PL1_CLK_MHZ        200.000
set ::VIDEO_WIDTH        1920
set ::VIDEO_HEIGHT       1080
set ::TILE_WIDTH         320
set ::TILE_HEIGHT        180
set ::OUT_WIDTH          640
set ::OUT_HEIGHT         180
set ::CSI_LANES          2
set ::CSI_LINE_RATE      1500
set ::CSI_PIXEL_FORMAT   `"RAW10`"
set ::CSI_PPC            2
set ::SHORT_ROOT         `"C:/t/mipi2`"
"@
Set-Content -Path "$Short\scripts\project_config.tcl" -Value $cfg

$create = Get-Content "$Root\hw_versal\scripts\create_project.tcl" -Raw
$create = $create -replace 'set root_dir\s+\[file normalize \[file join \$script_dir \.\. \.\.\]\]', 'set root_dir $::SHORT_ROOT'
$create = $create -replace 'set hw_dir\s+\[file normalize \[file join \$script_dir \.\.\]\]', 'set hw_dir $::SHORT_ROOT'
$create = $create -replace 'set board_repo \[file join \$root_dir board_files trenz\]', 'set board_repo [file join $root_dir board_files]'
$create = $create -replace 'set ip_repo\s+\[file join \$root_dir hw_versal ip_repo\]', 'set ip_repo [file join $root_dir ip_repo]'
Set-Content -Path "$Short\scripts\create_project.tcl" -Value $create

$vivadoBat = "C:\Xilinx\Vivado\2024.2\settings64.bat"
if (-not (Test-Path $vivadoBat)) { Write-Error "Missing $vivadoBat" }

# Advanced IO Wizard PHY regen uses %TEMP%; keep it short on Windows.
$Tmp = "C:\t\tmp"
New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
$env:TEMP = $Tmp
$env:TMP = $Tmp
$env:TE0950_MIPI_BUILD = "1"

# Every Vivado child (impl runme + nested PHY regen) sources this.
$initDir = Join-Path $env:APPDATA "Xilinx\Vivado"
New-Item -ItemType Directory -Force -Path $initDir | Out-Null
Copy-Item "$Root\hw_versal\scripts\vivado_init_win.tcl" "$initDir\Vivado_init.tcl" -Force
New-Item -ItemType Directory -Force -Path "$initDir\2024.2" | Out-Null
Copy-Item "$Root\hw_versal\scripts\vivado_init_win.tcl" "$initDir\2024.2\Vivado_init.tcl" -Force

Write-Host "Building Versal in $Short ..."
$runBat = Join-Path $Short "_run_versal.bat"
@"
@echo off
set TEMP=$Tmp
set TMP=$Tmp
set TE0950_MIPI_BUILD=1
call "$vivadoBat"
cd /d "$Short"
vivado -mode batch -source "$Short\scripts\create_project.tcl"
exit /b %ERRORLEVEL%
"@ | Set-Content -Path $runBat -Encoding ASCII
& cmd /c $runBat
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

New-Item -ItemType Directory -Force -Path "$Root\hw_versal\export" | Out-Null
if (Test-Path "$Short\export\te0950_dual_mipi_udp.xsa") {
    Copy-Item "$Short\export\te0950_dual_mipi_udp.xsa" "$Root\hw_versal\export\" -Force
    Write-Host "XSA -> $Root\hw_versal\export\"
}
Get-ChildItem "$Short\vivado_project\*.runs\impl_1\*.pdi" -ErrorAction SilentlyContinue | ForEach-Object {
    Copy-Item $_.FullName "$Root\hw_versal\export\" -Force
    Write-Host "PDI -> $($_.Name)"
}
