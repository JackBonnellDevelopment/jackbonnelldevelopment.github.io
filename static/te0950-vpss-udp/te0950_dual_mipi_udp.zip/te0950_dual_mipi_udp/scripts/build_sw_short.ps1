# Build dual_mipi_udp software on a short Windows path (MAX_PATH)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Short = "C:\t\vm2"
$Xsa = Join-Path $Root "hw_versal\export\te0950_dual_mipi_udp.xsa"
$vitisBat = "C:\Xilinx\Vitis\2024.2\settings64.bat"

if (-not (Test-Path $Xsa)) { Write-Error "Missing XSA: $Xsa" }
if (-not (Test-Path $vitisBat)) { Write-Error "Missing $vitisBat" }

if (Test-Path $Short) { Remove-Item -Recurse -Force $Short }
New-Item -ItemType Directory -Force -Path $Short | Out-Null
New-Item -ItemType Directory -Force -Path "$Short\hw_versal\export" | Out-Null
New-Item -ItemType Directory -Force -Path "$Short\sw_vitis\dual_mipi_udp\src" | Out-Null
New-Item -ItemType Directory -Force -Path "$Short\sw_vitis\scripts" | Out-Null
New-Item -ItemType Directory -Force -Path "$Short\sw_vitis\export" | Out-Null

Copy-Item $Xsa "$Short\hw_versal\export\" -Force
Copy-Item "$Root\sw_vitis\dual_mipi_udp\src\*" "$Short\sw_vitis\dual_mipi_udp\src\" -Force
Copy-Item "$Root\sw_vitis\scripts\build_unified.py" "$Short\sw_vitis\scripts\" -Force
Copy-Item "$Root\sw_vitis\scripts\vitis_init_versal_artix_chain.tcl" "$Short\sw_vitis\scripts\" -Force -ErrorAction SilentlyContinue

# Point the Python build at the short tree (forward slashes).
$py = Get-Content "$Root\sw_vitis\scripts\build_unified.py" -Raw
$py = $py -replace 'ROOT = Path\(__file__\)\.resolve\(\)\.parents\[2\]', 'ROOT = Path("C:/t/vm2")'
$py = $py -replace 'WS = ROOT / "sw_vitis" / "unified_ws"', 'WS = ROOT / "sw_vitis" / "ws"'
$py = $py -replace 'matches = list\(\(WS / PLAT_NAME\)\.rglob\("\*\.xpfm"\)\)', 'matches = list((WS / PLAT_NAME / "export").rglob("*.xpfm"))'
$utf8 = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText("$Short\sw_vitis\scripts\build_unified.py", $py, $utf8)

$runBat = Join-Path $Short "_run.bat"
@"
@echo off
call "$vitisBat"
cd /d "$Short"
vitis -s "$Short\sw_vitis\scripts\build_unified.py"
exit /b %ERRORLEVEL%
"@ | Set-Content -Path $runBat -Encoding ASCII

Write-Host "Building software in $Short ..."
& cmd /c $runBat
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$elfShort = Join-Path $Short "sw_vitis\export\dual_mipi_udp.elf"
if (-not (Test-Path $elfShort)) {
    Write-Error "ELF missing after build: $elfShort"
}
New-Item -ItemType Directory -Force -Path "$Root\sw_vitis\export" | Out-Null
Copy-Item $elfShort "$Root\sw_vitis\export\dual_mipi_udp.elf" -Force

# Keep Vitis Unified IDE workspace in sync with the short-path platform.
$ide = Join-Path $Root "sw_vitis\unified_ws"
$srcPlat = Join-Path $Short "sw_vitis\ws\te0950_mipi_udp_plat"
$srcApp  = Join-Path $Short "sw_vitis\ws\dual_mipi_udp"
if ((Test-Path $srcPlat) -and (Test-Path $ide)) {
    if (Test-Path "$ide\te0950_mipi_udp_plat") {
        Remove-Item -Recurse -Force "$ide\te0950_mipi_udp_plat"
    }
    if (Test-Path "$ide\dual_mipi_udp") {
        Remove-Item -Recurse -Force "$ide\dual_mipi_udp"
    }
    cmd /c "robocopy `"$srcPlat`" `"$ide\te0950_mipi_udp_plat`" /E /R:2 /W:1 /NFL /NDL /NJH /NJS /nc /ns /np >nul"
    cmd /c "robocopy `"$srcApp`" `"$ide\dual_mipi_udp`" /E /R:2 /W:1 /NFL /NDL /NJH /NJS /nc /ns /np >nul"
    Copy-Item "$Root\sw_vitis\dual_mipi_udp\src\*" "$ide\dual_mipi_udp\src\" -Force
    New-Item -ItemType Directory -Force -Path "$ide\dual_mipi_udp\build" | Out-Null
    Copy-Item $elfShort "$ide\dual_mipi_udp\build\dual_mipi_udp.elf" -Force
    Copy-Item $elfShort "$ide\dual_mipi_udp\dual_mipi_udp.elf" -Force
    New-Item -ItemType Directory -Force -Path "$ide\dual_mipi_udp\_ide\bootimage\resources" | Out-Null
    Copy-Item "$Root\sw_vitis\scripts\launch.json" "$ide\dual_mipi_udp\_ide\launch.json" -Force
    Copy-Item "$Root\sw_vitis\scripts\vitis_init_versal_artix_chain.tcl" "$ide\dual_mipi_udp\_ide\vitis_init_versal_artix_chain.tcl" -Force
    Copy-Item "$Root\hw_versal\export\system_wrapper.pdi" "$ide\dual_mipi_udp\_ide\bootimage\resources\te0950_dual_mipi_udp.pdi" -Force -ErrorAction SilentlyContinue
    Remove-Item -Force "$ide\dual_mipi_udp\src\platform_enable.c" -ErrorAction SilentlyContinue
    $uc = Join-Path $ide "dual_mipi_udp\src\UserConfig.cmake"
    if (Test-Path $uc) {
        $t = [IO.File]::ReadAllText($uc)
        $n = $t -replace '(?m)^"platform_enable\.c"\r?\n', ''
        if ($n -ne $t) { [IO.File]::WriteAllText($uc, $n) }
    }
    $longFwd = ($Root -replace '\\', '/')
    $shortFwd = 'C:/t/vm2'
    $shortBack = 'C:\t\vm2'
    Get-ChildItem $ide -Recurse -Include *.cmake,*.yml,*.yaml,*.json,*.xpfm -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $t = [IO.File]::ReadAllText($_.FullName)
            if ($t.Contains($shortFwd) -or $t.Contains($shortBack)) {
                $n = $t.Replace($shortFwd, $longFwd).Replace($shortBack, $Root)
                [IO.File]::WriteAllText($_.FullName, $n)
            }
        } catch {}
    }
    $xpfmIde = Join-Path $ide "te0950_mipi_udp_plat\export\te0950_mipi_udp_plat\te0950_mipi_udp_plat.xpfm"
    if (-not (Test-Path $xpfmIde)) {
        Write-Warning "IDE platform sync incomplete - missing xpfm (ELF still exported)"
    } else {
        Write-Host "  xpfm: $xpfmIde"
    }
    $wsPlat = Join-Path $Root "sw_vitis\ws\te0950_mipi_udp_plat"
    New-Item -ItemType Directory -Force -Path (Split-Path $wsPlat) | Out-Null
    if (Test-Path $wsPlat) { Remove-Item -Recurse -Force $wsPlat }
    cmd /c "robocopy `"$ide\te0950_mipi_udp_plat`" `"$wsPlat`" /E /R:1 /W:1 /NFL /NDL /NJH /NJS /nc /ns /np >nul"
    $platJson = Join-Path $ide "te0950_mipi_udp_plat\vitis-comp.json"
    if (Test-Path $platJson) {
        $t = [IO.File]::ReadAllText($platJson)
        $rootEsc = $Root.Replace('\', '\\')
        $n = $t.Replace('C:\\t\\vm2', $rootEsc).Replace($shortFwd, $longFwd)
        if ($n -ne $t) { [IO.File]::WriteAllText($platJson, $n) }
    }
    Write-Host "Synced IDE workspace platform + sources + ELF + launch/init"
    Write-Host "  xpfm: $xpfmIde"
}
$elf = Get-Item "$Root\sw_vitis\export\dual_mipi_udp.elf"
Write-Host ("ELF: {0} size={1} time={2}" -f $elf.FullName, $elf.Length, $elf.LastWriteTime)
