#Requires -Version 5.1
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Deps = Join-Path $Root "deps\trenz"
$Cache = Join-Path $Deps "zips"
$VersalExtract = Join-Path $Deps "te0950-rd"
$ArtixExtract = Join-Path $Deps "te0950-artix"
$BoardDst = Join-Path $Root "board_files\trenz"
$ArtixDst = Join-Path $Root "hw_artix\trenz_ref"

$Base = "https://shop.trenz-electronic.de/trenzdownloads/Trenz_Electronic/Development_Boards/TE0950/Reference_Design/2024.2/test_board"
$VersalZipName = "TE0950-te0950-rd_noprebuilt-vivado_2024.2-build_1_20250423075112.zip"
$ArtixZipName  = "TE0950-te0950-artix_noprebuilt-vivado_2024.2-build_1_20250527142942.zip"

New-Item -ItemType Directory -Force -Path $Cache | Out-Null

function Get-TrenzZip {
    param([string]$Name, [string]$OutFile)
    $url = "$Base/$Name"
    if ((Test-Path $OutFile) -and ((Get-Item $OutFile).Length -gt 100000)) {
        Write-Host "Cached: $OutFile"
        return
    }
    Write-Host "Downloading $url"
    Invoke-WebRequest -Uri $url -OutFile $OutFile -UseBasicParsing
    Write-Host ("Saved {0:N1} MB" -f ((Get-Item $OutFile).Length / 1MB))
}

$versalZip = Join-Path $Cache $VersalZipName
$artixZip  = Join-Path $Cache $ArtixZipName
Get-TrenzZip -Name $VersalZipName -OutFile $versalZip
Get-TrenzZip -Name $ArtixZipName  -OutFile $artixZip

foreach ($p in @($VersalExtract, $ArtixExtract, $BoardDst, $ArtixDst)) {
    if (Test-Path $p) {
        cmd /c "rmdir /s /q `"$p`"" 2>$null
        if (Test-Path $p) { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

Write-Host "Extracting Versal RD..."
Expand-Archive -Path $versalZip -DestinationPath $VersalExtract -Force
Write-Host "Extracting Artix RD..."
Expand-Archive -Path $artixZip -DestinationPath $ArtixExtract -Force

$boardSrc = Get-ChildItem -Path $VersalExtract -Recurse -Directory -Filter "board_files" |
    Where-Object { Test-Path (Join-Path $_.FullName "TE0950_board_files.csv") } |
    Select-Object -First 1
if (-not $boardSrc) { throw "board_files not found in Versal zip" }

$artixSrc = Get-ChildItem -Path $ArtixExtract -Recurse -Directory -Filter "te0950-artix" |
    Select-Object -First 1
if (-not $artixSrc) {
    $artixSrc = Get-ChildItem -Path $ArtixExtract -Directory | Select-Object -First 1
}

New-Item -ItemType Directory -Force -Path $BoardDst | Out-Null
Copy-Item -Path (Join-Path $boardSrc.FullName "*") -Destination $BoardDst -Recurse -Force
New-Item -ItemType Directory -Force -Path $ArtixDst | Out-Null
Copy-Item -Path (Join-Path $artixSrc.FullName "*") -Destination $ArtixDst -Recurse -Force

Write-Host "OK board_files -> $BoardDst"
Write-Host "OK artix       -> $ArtixDst"
