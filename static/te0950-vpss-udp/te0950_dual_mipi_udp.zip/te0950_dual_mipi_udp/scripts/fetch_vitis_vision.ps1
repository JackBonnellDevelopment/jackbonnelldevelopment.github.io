# Fetch Vitis Vision L1 headers (xfOpenCV) for HLS resize IP
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Dest = Join-Path $Root "hw_versal\vitis_libraries"
$VisionInclude = Join-Path $Dest "vision\L1\include\imgproc\xf_resize.hpp"

if (Test-Path $VisionInclude) {
  Write-Host "Vitis Vision already present: $Dest"
  exit 0
}

New-Item -ItemType Directory -Force -Path $Dest | Out-Null
$tmp = "C:\t\vitis_libraries_fetch"
if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }

$cloned = $false
$usedRef = ""
foreach ($ref in @("2024.2", "2024.1", "2023.2", "main", "master")) {
  Write-Host "Trying branch/tag $ref ..."
  if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
  cmd /c "git clone --filter=blob:none --sparse --branch $ref --depth 1 https://github.com/Xilinx/Vitis_Libraries.git `"$tmp`""
  if ($LASTEXITCODE -ne 0) { continue }

  Push-Location $tmp
  cmd /c "git sparse-checkout set vision/L1"
  Pop-Location

  $check = Join-Path $tmp "vision\L1\include\imgproc\xf_resize.hpp"
  if (Test-Path $check) {
    $cloned = $true
    $usedRef = $ref
    Write-Host "Using ref $ref"
    break
  }
  Write-Host "Ref $ref cloned but vision/L1 incomplete - trying next"
}

if (-not $cloned) {
  Write-Error "Failed to obtain vision/L1 from Vitis_Libraries"
}

New-Item -ItemType Directory -Force -Path (Join-Path $Dest "vision") | Out-Null
if (Test-Path (Join-Path $Dest "vision\L1")) {
  Remove-Item -Recurse -Force (Join-Path $Dest "vision\L1")
}
Copy-Item (Join-Path $tmp "vision\L1") (Join-Path $Dest "vision\L1") -Recurse -Force
Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue

if (-not (Test-Path $VisionInclude)) {
  Write-Error "xf_resize.hpp missing after fetch: $VisionInclude"
}
Write-Host ("Vitis Vision ready ({0}): {1}" -f $usedRef, $VisionInclude)
