# Create Vitis Unified workspace + platform + dual_mipi_udp app
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Py = Join-Path $Root "sw_vitis\scripts\build_unified.py"
$Xsa = Join-Path $Root "hw_versal\export\te0950_dual_mipi_udp.xsa"

if (-not (Test-Path $Xsa)) {
    Write-Error "Missing XSA. Run scripts/build_hw.ps1 first."
}

$vitisBat = "C:\Xilinx\Vitis\2024.2\settings64.bat"
if (-not (Test-Path $vitisBat)) { Write-Error "Missing $vitisBat" }

$runBat = Join-Path $Root "sw_vitis\_run_vitis.bat"
@"
@echo off
call "$vitisBat"
vitis -s "$Py"
exit /b %ERRORLEVEL%
"@ | Set-Content -Path $runBat -Encoding ASCII
& cmd /c $runBat
$vitisExit = $LASTEXITCODE
$elf = Join-Path $Root "sw_vitis\export\dual_mipi_udp.elf"
$xsa = Join-Path $Root "hw_versal\export\te0950_dual_mipi_udp.xsa"
if ($vitisExit -ne 0) { exit $vitisExit }
if (-not (Test-Path $elf)) {
    Write-Error "Build finished but ELF is missing: $elf"
}
$elfItem = Get-Item $elf
$xsaItem = Get-Item $xsa
if ($elfItem.LastWriteTime -lt $xsaItem.LastWriteTime) {
    Write-Error "ELF is older than XSA - Vitis rebuild did not refresh the binary"
}
Write-Host ("ELF: {0} ({1} bytes, {2})" -f $elf, $elfItem.Length, $elfItem.LastWriteTime)

Write-Host ""
Write-Host "Open Vitis Unified IDE workspace:"
Write-Host "  $Root\sw_vitis\unified_ws"
