# Build lean Artix MIPI companion (I2C mux + CR00240 cam GPIO high)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
& (Join-Path $Root "scripts\fetch_trenz_refs.ps1")

$vivadoBat = "C:\Xilinx\Vivado\2024.2\settings64.bat"
$tcl = Join-Path $Root "hw_artix\scripts\create_project.tcl"
if (-not (Test-Path $vivadoBat)) { Write-Error "Missing $vivadoBat" }
if (-not (Test-Path $tcl)) { Write-Error "Missing $tcl" }

$runBat = Join-Path $Root "hw_artix\_run_artix.bat"
@"
@echo off
call "$vivadoBat"
vivado -mode batch -source "$tcl"
exit /b %ERRORLEVEL%
"@ | Set-Content -Path $runBat -Encoding ASCII
& cmd /c $runBat
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Artix bitstream expected in $Root\hw_artix\export\"
