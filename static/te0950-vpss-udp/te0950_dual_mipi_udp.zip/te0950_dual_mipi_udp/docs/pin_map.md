# Dual MIPI pin map (TE0950-03 + CR00240-02 on HS1)

## cam0 — onboard J15

| Net | Package | IOSTANDARD |
|-----|---------|------------|
| CLK_P / CLK_N | H25 / J26 | MIPI_DPHY |
| D0_P / D0_N | G25 / G26 | MIPI_DPHY |
| D1_P / D1_N | F26 / E26 | MIPI_DPHY |
| SCL / SDA | A13 / B13 | LVCMOS33 |
| GPIO0 / GPIO1 | F11 / E11 | LVCMOS33 |

## cam1 — CR00240 CSI on CRUVI HS1 (J10)

Same CRUVI mapping as CR00300: CLK=B2, D0=B3, D1=B4.

| CR00240 | CRUVI | HS1 | Package |
|---------|-------|-----|---------|
| CSI1_C | B2 | HS1_B2 | J27 / H28 |
| CSI1_D0 | B3 | HS1_B3 | H27 / G28 |
| CSI1_D1 | B4 | HS1_B4 | G27 / F28 |
| CSI I2C | SMB SCL/SDA pins 7/5 | Artix T16/T18 | PCA9548 ch0 |
| CSI GPIO0/1 | ALERT / REFCLK | Artix R16 / N17 | held high |

HDMI TMDS on A1/A2/A3/B1 is unused.

## Artix ↔ Versal I2C

| Versal | Artix |
|--------|-------|
| T23 A_IIC_SCL_O | K13 IIC_SCL_I |
| R23 A_IIC_SDA_O | J13 IIC_SDA_O |
| R24 A_IIC_SDA_I | B18 IIC_SDA_I |
| J22 C2C_RST | A14 C2C_RST |
