# Dual MIPI UDP architecture

```text
IMX219 1080p @ J15 ── CSI ──► demosaic ──► RGB8@2ppc ──► VPSS 320×180 ──► v_frmbuf_wr ──┐
                                                                                         ├─► DDR tiles
IMX219 1080p @ HS1 ── CSI ──► demosaic ──► RGB8@2ppc ──► VPSS 320×180 ──► v_frmbuf_wr ──┘
                                                                                         │
                                                                           A72 PS stitch ┘
                                                                           320|320 → 640×180 → UDP
```

- PL: VPSS bilinear scale.
- CSI core is enabled only after the scaler and frame writer are accepting.
