# Create Vitis Unified IDE workspace + lwIP platform + dual_mipi_udp
#   call C:\Xilinx\Vitis\2024.2\settings64.bat
import re
import shutil
from pathlib import Path

import vitis

ROOT = Path(__file__).resolve().parents[2]
XSA = ROOT / "hw_versal" / "export" / "te0950_dual_mipi_udp.xsa"
SRC_DIR = ROOT / "sw_vitis" / "dual_mipi_udp" / "src"
WS = ROOT / "sw_vitis" / "unified_ws"
PLAT_NAME = "te0950_mipi_udp_plat"
APP_NAME = "dual_mipi_udp"
CPU = "psv_cortexa72_0"
LWIP_LIB = "lwip220"
KEEP_PLATFORM = {
    "platform.c",
    "platform_config.h",
    "platform_config.h.in",
    "platform_mb.c",
    "platform_zynq.c",
    "platform_zynqmp.c",
}
DROP_TEMPLATE_C = {
    "echo.c",
    "helloworld.c",
    "main.c",
    "i2c_access.c",
    "iic_phyreset.c",
    "sfp.c",
    "si5324.c",
}
PLATFORM_ENABLE_C = """#include "xil_exception.h"

void platform_enable_interrupts(void)
{
    Xil_ExceptionEnable();
}
"""


def add_lwip(platform):
    domain = platform.get_domain(name="standalone_domain")
    try:
        domain.set_lib(lib_name=LWIP_LIB)
        print(f"Added {LWIP_LIB} to standalone_domain")
    except Exception as e:
        msg = str(e).lower()
        if "already" in msg or "exist" in msg:
            print(f"{LWIP_LIB} already in BSP ({e})")
        else:
            raise
    for param, value in (
        ("lwip220_dhcp", "true"),
        ("lwip220_temac_phy_link_speed", "CONFIG_LINKSPEED_AUTODETECT"),
        ("temac_use_jumbo_frames", "false"),
        ("lwip220_memp_n_pbuf", "256"),
        ("lwip220_pbuf_pool_size", "256"),
        ("lwip220_pbuf_pool_bufsize", "1700"),
    ):
        try:
            domain.set_config(option="lib", param=param, value=value, lib_name=LWIP_LIB)
            print(f"  {LWIP_LIB}.{param}={value}")
        except Exception as e:
            print(f"  WARN: set_config {param}: {e}")
    return domain


def rewrite_userconfig(ucfg: Path, sources):
    if not ucfg.is_file():
        print("WARN: no UserConfig.cmake")
        return
    text = ucfg.read_text(encoding="utf-8")
    block = "set(USER_COMPILE_SOURCES\n" + "\n".join(f'"{s}"' for s in sources) + "\n)"
    text2, n = re.subn(
        r"set\(\s*USER_COMPILE_SOURCES\s*.*?\)",
        block,
        text,
        count=1,
        flags=re.S,
    )
    if n:
        ucfg.write_text(text2, encoding="utf-8")
    else:
        print("WARN: USER_COMPILE_SOURCES not rewritten; check UserConfig.cmake")


def patch_cmakelists(cmake: Path, sources):
    if not cmake.is_file():
        return
    text = cmake.read_text(encoding="utf-8")
    text = re.sub(r"set\(APP_NAME [^\)]+\)", f"set(APP_NAME {APP_NAME})", text)
    if "lwip220" not in text:
        if "collect(PROJECT_LIB_DEPS xiltimer)" in text:
            text = text.replace(
                "collect(PROJECT_LIB_DEPS xiltimer)",
                "collect(PROJECT_LIB_DEPS xiltimer)\ncollect(PROJECT_LIB_DEPS lwip220)",
            )
        elif "collect(PROJECT_LIB_DEPS xilstandalone;xiltimer)" in text:
            text = text.replace(
                "collect(PROJECT_LIB_DEPS xilstandalone;xiltimer)",
                "collect(PROJECT_LIB_DEPS xilstandalone;xiltimer;lwip220)",
            )
        else:
            text = text.replace(
                "collect(PROJECT_LIB_DEPS xil)",
                "collect(PROJECT_LIB_DEPS xil)\ncollect(PROJECT_LIB_DEPS lwip220)",
            )
    if re.search(r"collect\s*\(\s*PROJECT_LIB_SOURCES", text):
        text = re.sub(r"collect\s*\(\s*PROJECT_LIB_SOURCES[^\)]*\)\s*", "", text)
        inject = "".join(f"collect (PROJECT_LIB_SOURCES {s})\n" for s in sources)
        marker = "collector_list (_sources PROJECT_LIB_SOURCES)"
        if marker in text:
            text = text.replace(marker, inject + marker)
        else:
            text += "\n" + inject
    if "${CMAKE_BINARY_DIR}/include" not in text:
        text += (
            '\ntarget_include_directories(${APP_NAME}.elf PUBLIC '
            '"${CMAKE_BINARY_DIR}/include")\n'
        )
    cmake.write_text(text, encoding="utf-8")


def patch_lwip_phy(plat_root: Path):
    """Force Marvell 88E1512 at MDIO addr 1; never hang in PCS autoneg."""
    marker = "PHY setup MDIO addr 1 (88E1512)"
    old_scan = """#ifndef SGMII_FIXED_LINK
	detect_phy(xemacpsp);
	for (i = 31; i > 0; i--) {
		if (xemacpsp->Config.BaseAddress == XPAR_XEMACPS_0_BASEADDR) {
			if (phymapemac0[i] == TRUE) {
				link_speed = phy_setup_emacps(xemacpsp, i);
				phyfoundforemac0 = TRUE;
				phyaddrforemac = i;
			}
		} else {
			if (phymapemac1[i] == TRUE) {
				link_speed = phy_setup_emacps(xemacpsp, i);
				phyfoundforemac1 = TRUE;
				phyaddrforemac = i;
			}
		}
	}
	/* If no PHY was detected, use broadcast PHY address of 0 */
	if (xemacpsp->Config.BaseAddress == XPAR_XEMACPS_0_BASEADDR) {
		if (phyfoundforemac0 == FALSE)
			link_speed = phy_setup_emacps(xemacpsp, 0);
	} else {
		if (phyfoundforemac1 == FALSE)
			link_speed = phy_setup_emacps(xemacpsp, 0);
	}"""
    new_scan = """#ifndef SGMII_FIXED_LINK
	/* TE0950 Marvell 88E1512 is strapped to MDIO address 1. Scanning 31..1
	 * hits ghost addresses and can hang forever in the Xilinx PCS autoneg
	 * wait (no timeout). */
	(void)i;
	(void)phyfoundforemac0;
	(void)phyfoundforemac1;
	xil_printf("PHY setup MDIO addr 1 (88E1512), skip bus scan\\r\\n");
	link_speed = phy_setup_emacps(xemacpsp, 1);
	phyaddrforemac = 1;"""
    n = 0
    for p in plat_root.rglob("xemacpsif_hw.c"):
        t = p.read_text(encoding="utf-8", errors="ignore")
        if marker in t:
            continue
        if old_scan not in t:
            print(f"WARN: PHY scan block not found in {p}")
            continue
        p.write_text(t.replace(old_scan, new_scan, 1), encoding="utf-8")
        print(f"Patched {p}")
        n += 1
    if n == 0:
        print("INFO: xemacpsif_hw.c already patched or missing")


def patch_lwipopts(plat_root: Path):
    """Zero-copy TX holds many PBUF_REF descriptors; default MEMP_NUM_PBUF=16 is fatal."""
    n = 0
    for p in plat_root.rglob("lwipopts.h"):
        t = p.read_text(encoding="utf-8", errors="ignore")
        t2 = re.sub(r"#define\s+MEMP_NUM_PBUF\s+\d+", "#define MEMP_NUM_PBUF 256", t)
        t2 = re.sub(r"#define\s+PBUF_POOL_SIZE\s+\d+", "#define PBUF_POOL_SIZE 256", t2)
        t2 = re.sub(
            r"#define\s+PBUF_POOL_BUFSIZE\s+\d+", "#define PBUF_POOL_BUFSIZE 1700", t2
        )
        if t2 != t:
            p.write_text(t2, encoding="utf-8")
            print(f"Patched {p} MEMP_NUM_PBUF/PBUF_POOL")
            n += 1
    if n == 0:
        print("INFO: lwipopts.h already has MEMP_NUM_PBUF=256 or missing")


if not XSA.is_file():
    raise SystemExit(f"Missing XSA: {XSA}")

WS.mkdir(parents=True, exist_ok=True)

client = vitis.create_client()
try:
    client.set_workspace(path=str(WS))
except Exception as e:
    print(f"set_workspace failed ({e}); trying update_workspace...")
    client.update_workspace(path=str(WS))
    client.set_workspace(path=str(WS))

# Recreate the app every run. Reuse the platform if it already exists so we
# only rebuild the BSP after adding lwIP instead of regenerating from the XSA.
try:
    client.delete_component(name=APP_NAME)
except Exception:
    pass
app_dir = WS / APP_NAME
if app_dir.exists():
    shutil.rmtree(app_dir, ignore_errors=True)

platform = None
try:
    platform = client.get_component(name=PLAT_NAME)
    print(f"Reusing platform {PLAT_NAME}")
except Exception:
    platform = None

if platform is None:
    plat_dir = WS / PLAT_NAME
    if plat_dir.exists():
        shutil.rmtree(plat_dir, ignore_errors=True)
    try:
        client.delete_component(name=PLAT_NAME)
    except Exception:
        pass
    platform = client.create_platform_component(
        name=PLAT_NAME,
        hw_design=str(XSA),
        os="standalone",
        cpu=CPU,
        domain_name="standalone_domain",
    )

add_lwip(platform)
status = platform.build()
print(f"platform.build -> {status}")
patch_lwip_phy(WS / PLAT_NAME)
patch_lwipopts(WS / PLAT_NAME)
# lwipopts.h is consumed at BSP compile time — rebuild so MEMP_NUM_PBUF sticks.
status = platform.build()
print(f"platform.build (after lwipopts) -> {status}")
patch_lwipopts(WS / PLAT_NAME)
if status not in (True, "SUCCESS", 0, None) and str(status).upper() not in {
    "SUCCESS",
    "TRUE",
    "0",
}:
    # GeneratePlatform returns a protobuf enum; accept SUCCESS-like values.
    print(f"WARN: unusual platform.build status {status!r}")

import time

def find_xpfm():
    preferred = WS / PLAT_NAME / "export" / PLAT_NAME / f"{PLAT_NAME}.xpfm"
    if preferred.is_file():
        return preferred
    matches = list((WS / PLAT_NAME).rglob("*.xpfm"))
    return matches[0] if matches else None

# platform.build() often returns before ninja finishes the BSP on Windows.
xpfm = None
deadline = time.time() + 2400  # up to 40 minutes
while time.time() < deadline:
    xpfm = find_xpfm()
    if xpfm is not None:
        break
    time.sleep(5)
if xpfm is None:
    print("INFO: no .xpfm yet — calling platform.build() again")
    status = platform.build()
    print(f"platform.build(retry) -> {status}")
    deadline = time.time() + 2400
    while time.time() < deadline:
        xpfm = find_xpfm()
        if xpfm is not None:
            break
        time.sleep(5)
if xpfm is None:
    raise SystemExit("Platform .xpfm not found after build")
print(f"Using platform {xpfm}")

app = None
for tmpl in ("lwip_echo_server", "LWIP Echo Server", "lwIP Echo Server", "hello_world"):
    try:
        app = client.create_app_component(
            name=APP_NAME,
            platform=str(xpfm),
            domain="standalone_domain",
            template=tmpl,
        )
        print(f"Created app from template {tmpl}")
        break
    except Exception as e:
        print(f"template {tmpl} failed: {e}")
        try:
            client.delete_component(name=APP_NAME)
        except Exception:
            pass
if app is None:
    raise SystemExit("Could not create application component")

app_src = WS / APP_NAME / "src"
app_src.mkdir(parents=True, exist_ok=True)

had_template_platform = (app_src / "platform.c").is_file()
for old in list(app_src.glob("*")):
    if old.is_file() and old.suffix in {".c", ".h"} and old.name.lower() in DROP_TEMPLATE_C:
        old.unlink()

for src in SRC_DIR.glob("*"):
    if had_template_platform and src.name in KEEP_PLATFORM:
        continue
    shutil.copy2(src, app_src / src.name)

plat_c = app_src / "platform.c"
enable_c = app_src / "platform_enable.c"
if plat_c.is_file() and "platform_enable_interrupts" in plat_c.read_text(
    encoding="utf-8", errors="ignore"
):
    if enable_c.is_file():
        enable_c.unlink()
        print("Removed stale platform_enable.c (already in platform.c)")
elif plat_c.is_file():
    enable_c.write_text(PLATFORM_ENABLE_C, encoding="utf-8")
    print("Added platform_enable.c (SDT echo-server template omits the symbol)")

sources = sorted(p.name for p in app_src.iterdir() if p.suffix == ".c")
rewrite_userconfig(app_src / "UserConfig.cmake", sources)
patch_cmakelists(app_src / "CMakeLists.txt", sources)
print("App C sources:", sources)

status = app.build()
print(f"app.build -> {status}")
status_s = str(status).upper()
if "FAIL" in status_s or "ERROR" in status_s:
    raise SystemExit(f"app.build failed: {status}")

init_src = ROOT / "sw_vitis" / "scripts" / "vitis_init_versal_artix_chain.tcl"
init_dst = WS / APP_NAME / "_ide" / "vitis_init_versal_artix_chain.tcl"
if init_src.is_file():
    init_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(init_src, init_dst)

elfs = [e for e in (WS / APP_NAME).rglob("*.elf") if e.is_file()]
export = ROOT / "sw_vitis" / "export"
export.mkdir(parents=True, exist_ok=True)
copied = None
for e in elfs:
    if e.name.endswith(".elf") and "CompilerId" not in str(e):
        copied = export / "dual_mipi_udp.elf"
        shutil.copy2(e, copied)
        print(f"ELF -> {copied}")
        break

if copied is None or not copied.is_file():
    raise SystemExit(f"No application ELF produced. Candidates: {elfs}")

print("ELFs:", [str(e) for e in elfs])
print(f"Unified workspace ready: {WS}")
print("Open Vitis Unified IDE and select that folder as the workspace.")
