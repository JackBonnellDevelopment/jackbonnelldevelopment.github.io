# One-shot: program Artix bit, then Versal PDI + dual_mipi_udp ELF
set root [file normalize [file join [file dirname [info script]] .. ..]]
set artix_bit [file join $root hw_artix export te0950_artix_mipi.bit]
set ::PDI_FILE [file join $root hw_versal export system_wrapper.pdi]
set ::ELF_FILE [file join $root sw_vitis export dual_mipi_udp.elf]

puts "INFO: connecting hw_server"
connect -url TCP:127.0.0.1:3121

if {![file isfile $artix_bit]} {
  error "Artix bit missing: $artix_bit"
}
puts "INFO: programming Artix $artix_bit"
targets -set -filter {name =~ "xc7a35t"}
fpga -f $artix_bit
puts "INFO: Artix programmed"

# Init script expects an existing connection and programs Versal + ELF
source [file join $root sw_vitis scripts vitis_init_versal_artix_chain.tcl]
puts "INFO: board run complete"
