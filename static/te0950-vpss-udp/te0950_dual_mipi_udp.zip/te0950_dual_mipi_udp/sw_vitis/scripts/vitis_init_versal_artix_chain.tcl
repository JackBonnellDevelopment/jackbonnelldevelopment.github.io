################################################################################
# Vitis Unified IDE init — TE0950 with Artix in the JTAG chain.
# Selects Versal/PMC by exact property match in Tcl (never name =~ "PMC",
# which also hits "RPU (No PMC LPD power)").
#
# Do not use Vitis standalone "program device" — it filters
#   jtag_device_ctx == "...-0"
# but Artix is JTAG index 0 and Versal/PMC is index 1.
#
# Same Vitis attach flow as HDMI TPG: this script programs the PDI, then
# downloads the ELF. Vitis already connected — do not call connect again.
################################################################################

puts "INFO: dual_mipi_udp JTAG init starting"
flush stdout

set ::env(XIL_HW_SERVER) "TCP:127.0.0.1:3121"

if {![info exists ::PDI_FILE]} { set ::PDI_FILE "" }
if {![info exists ::ELF_FILE]} { set ::ELF_FILE "" }

proc _first_existing {paths} {
  foreach p $paths {
    if {$p ne "" && [file isfile $p]} {
      return [file normalize $p]
    }
  }
  return ""
}

proc _walk_up_file {start relparts} {
  set d $start
  for {set i 0} {$i < 8} {incr i} {
    set cand $d
    foreach p $relparts {
      set cand [file join $cand $p]
    }
    set cand [file normalize $cand]
    if {[file isfile $cand]} {
      return $cand
    }
    set parent [file dirname $d]
    if {$parent eq $d} {
      break
    }
    set d $parent
  }
  return ""
}

proc _find_target_id {want_name} {
  set fallback ""
  foreach t [targets -target-properties] {
    if {![dict exists $t name] || [dict get $t name] ne $want_name} {
      continue
    }
    set tid [dict get $t target_id]
    set under_versal 0
    if {[dict exists $t jtag_device_name]} {
      set jdn [dict get $t jtag_device_name]
      if {[string match -nocase "*xcve*" $jdn] || [string match -nocase "*versal*" $jdn]} {
        set under_versal 1
      }
    }
    if {[dict exists $t parent] && [string match -nocase "*Versal*" [dict get $t parent]]} {
      set under_versal 1
    }
    if {$under_versal} {
      return $tid
    }
    if {$fallback eq ""} {
      set fallback $tid
    }
  }
  return $fallback
}

proc _select_versal {} {
  if {![catch {targets -set -nocase -filter {jtag_device_name =~ "xcve*"}}]} {
    return
  }
  if {![catch {targets -set -nocase -filter {name =~ "Versal*"}}]} {
    return
  }
  error "Could not select Versal (xcve*)"
}

# Return A72#0 id. Prefer a live core over "(FPD Reset)".
proc _find_a72_0 {} {
  set reset_id ""
  foreach t [targets -target-properties] {
    if {![dict exists $t name]} { continue }
    set n [dict get $t name]
    if {![string match -nocase "*A72*" $n]} { continue }
    if {[string match "*#1*" $n]} { continue }
    if {![string match "*#0*" $n] && $n ne "Cortex-A72 #0"} { continue }
    set tid [dict get $t target_id]
    if {[string match -nocase "*Reset*" $n]} {
      if {$reset_id eq ""} { set reset_id $tid }
      continue
    }
    return $tid
  }
  return $reset_id
}

proc _dump_targets {} {
  puts "==== targets ===="
  catch {puts [targets]}
  foreach t [targets -target-properties] {
    if {[dict exists $t name]} {
      puts "  id=[dict get $t target_id] name={[dict get $t name]}"
    }
  }
  flush stdout
}

# PLM UART can show "Boot PDI Load: Done" while XSDB still has a stale
# pre-program tree (DAP 0x30000021, no A72). Re-select Versal and poll.
proc _wait_a72 {timeout_ms} {
  set waited 0
  while {$waited < $timeout_ms} {
    catch {_select_versal}
    # Touch the target list so XSDB re-enumerates after PDI.
    catch {targets}
    set id [_find_a72_0]
    if {$id ne ""} {
      return $id
    }
    after 500
    incr waited 500
    if {($waited % 5000) == 0} {
      puts "INFO: still waiting for A72... ${waited}ms"
      flush stdout
      _dump_targets
    }
  }
  return ""
}

# Vitis already connected — do not connect again (hangs IDE).
proc _ensure_connected {} {
  if {![catch {targets}]} {
    puts "INFO: XSDB already connected — skip connect"
    flush stdout
    return
  }
  puts "INFO: connect $::env(XIL_HW_SERVER)"
  flush stdout
  connect -url $::env(XIL_HW_SERVER)
}

set script_dir [file dirname [file normalize [info script]]]

set pdi $::PDI_FILE
set elf $::ELF_FILE

if {$pdi eq ""} {
  set pdi [_walk_up_file $script_dir [list hw_versal export system_wrapper.pdi]]
}
if {$pdi eq ""} {
  set pdi [_first_existing [list \
    [file join $script_dir bootimage resources te0950_dual_mipi_udp.pdi] \
    [file join $script_dir .. _ide bootimage resources te0950_dual_mipi_udp.pdi] \
  ]]
}

if {$elf eq ""} {
  set elf [_first_existing [list \
    [file join $script_dir .. build dual_mipi_udp.elf] \
    [_walk_up_file $script_dir [list sw_vitis export dual_mipi_udp.elf]] \
    [_walk_up_file $script_dir [list sw_vitis unified_ws dual_mipi_udp build dual_mipi_udp.elf]] \
  ]]
}

if {$pdi eq ""} { error "PDI not found (expected hw_versal/export/system_wrapper.pdi)" }
if {$elf eq ""} { error "ELF not found — build dual_mipi_udp first" }

puts "INFO: PDI=$pdi"
puts "INFO: ELF=$elf"
flush stdout

_ensure_connected
catch {configparams force-mem-accesses 1}

_select_versal
puts "INFO: Versal device selected"
flush stdout

set pmc_id [_find_target_id "PMC"]
if {$pmc_id eq ""} { error "Exact target name PMC not found" }
puts "INFO: Selecting PMC id=$pmc_id"
flush stdout
targets $pmc_id

puts "INFO: rst -system"
flush stdout
catch {rst -system}
after 1000

_select_versal
puts "INFO: Programming Versal PDI..."
flush stdout
device program $pdi

puts "INFO: PDI programmed — waiting for A72 (PLM Done can precede XSDB target refresh)"
flush stdout
set a72 [_wait_a72 60000]
if {$a72 eq ""} {
  _dump_targets
  error "Cortex-A72 #0 not found after PDI (UART may show Boot Done; XSDB tree stale — power-cycle and retry with Vivado HW Manager closed)"
}
puts "INFO: Selecting A72#0 id=$a72"
flush stdout
targets $a72
catch {rst -processor}
catch {stop}
after 500

puts "INFO: waiting for DDR at 0x0"
flush stdout
set waited 0
while {$waited < 20000} {
  if {![catch {mwr 0x0 0xA5A55A5A}] && ![catch {mrd 0x0}]} {
    break
  }
  after 200
  incr waited 200
}
if {$waited >= 20000} {
  error "DDR at 0x0 not writable after PDI. Close Vivado HW Manager, power-cycle, retry."
}

puts "INFO: DDR OK — downloading ELF"
flush stdout
dow $elf
con
puts "INFO: ELF downloaded and running on A72#0 (open serial @115200 for prints)"
flush stdout
