# XSCT entry: set PDI/ELF from the environment, then run the shared init script.
if {[info exists ::env(PDI)] && $::env(PDI) ne ""} {
  set ::PDI_FILE [file normalize $::env(PDI)]
}
if {[info exists ::env(ELF)] && $::env(ELF) ne ""} {
  set ::ELF_FILE [file normalize $::env(ELF)]
}
source [file join [file dirname [file normalize [info script]]] vitis_init_versal_artix_chain.tcl]
