################################################################################
# build_vitis.tcl — XSCT platform + lwIP dual_mipi_udp
################################################################################
set script_dir [file dirname [file normalize [info script]]]
set root_dir   [file normalize [file join $script_dir .. ..]]
set xsa        [file join $root_dir hw_versal export te0950_dual_mipi_udp.xsa]
set ws         [file join $root_dir sw_vitis workspace]
set app_src    [file join $root_dir sw_vitis dual_mipi_udp src]

if {![file exists $xsa]} {
  puts "ERROR: XSA not found: $xsa"
  exit 1
}

file mkdir $ws
setws $ws
catch {app remove dual_mipi_udp}
catch {platform remove te0950_mipi_udp_plat}

platform create -name te0950_mipi_udp_plat -hw $xsa -proc psv_cortexa72_0 -os standalone
bsp setlib -name lwip213
catch {bsp config lwip_dhcp true}
catch {bsp config phy_link_speed CONFIG_LINKSPEED1000}
platform generate

if {[catch {
  app create -name dual_mipi_udp -platform te0950_mipi_udp_plat \
    -domain standalone_domain -template {lwIP Echo Server}
}]} {
  app create -name dual_mipi_udp -platform te0950_mipi_udp_plat \
    -domain standalone_domain -template {Hello World}
}

foreach f [glob -nocomplain [file join $ws dual_mipi_udp src echo.c]] { file delete -force $f }
foreach f [glob -nocomplain [file join $ws dual_mipi_udp src helloworld.c]] { file delete -force $f }
foreach f [glob -nocomplain [file join $ws dual_mipi_udp src main.c]] { file delete -force $f }
foreach f [glob -nocomplain [file join $app_src *]] {
  file copy -force $f [file join $ws dual_mipi_udp src]
}

app build -name dual_mipi_udp

set elf [file join $ws dual_mipi_udp Debug dual_mipi_udp.elf]
if {![file exists $elf]} {
  set elf [file join $ws dual_mipi_udp build dual_mipi_udp.elf]
}
if {[file exists $elf]} {
  file mkdir [file join $root_dir sw_vitis export]
  file copy -force $elf [file join $root_dir sw_vitis export dual_mipi_udp.elf]
  puts "INFO: Built ELF: $elf"
} else {
  puts "ERROR: ELF not found after build"
  exit 1
}
