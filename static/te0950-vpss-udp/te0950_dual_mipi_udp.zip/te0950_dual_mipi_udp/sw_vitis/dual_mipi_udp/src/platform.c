/******************************************************************************
 * Minimal Versal A72 platform glue for lwIP (NO_SYS=1).
 * GEM RX is driven by xemacif_input() in the main loop; TCP timers via
 * sys_check_timeouts().
 *****************************************************************************/
#include "platform.h"
#include "xil_cache.h"
#include "xil_exception.h"
#include "xparameters.h"
#include "platform_config.h"
#include "xscugic.h"
#include "lwip/init.h"
#include "lwip/timeouts.h"

#ifndef INTC_DEVICE_ID
#if defined(XPAR_SCUGIC_0_DEVICE_ID)
#define INTC_DEVICE_ID XPAR_SCUGIC_0_DEVICE_ID
#elif defined(XPAR_XSCUGIC_0_DEVICE_ID)
#define INTC_DEVICE_ID XPAR_XSCUGIC_0_DEVICE_ID
#else
#define INTC_DEVICE_ID 0
#endif
#endif

static XScuGic Intc;

void platform_enable_interrupts(void)
{
    Xil_ExceptionEnable();
}

void platform_setup_timer(void)
{
    /* NO_SYS: sys_check_timeouts() from net_poll() */
}

void init_platform(void)
{
    XScuGic_Config *cfg;

    Xil_ICacheEnable();
    Xil_DCacheEnable();

    cfg = XScuGic_LookupConfig(INTC_DEVICE_ID);
    if (cfg == NULL)
        return;
    if (XScuGic_CfgInitialize(&Intc, cfg, cfg->CpuBaseAddress) != XST_SUCCESS)
        return;
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
                                 (Xil_ExceptionHandler)XScuGic_InterruptHandler,
                                 &Intc);
    platform_setup_timer();
}

void cleanup_platform(void)
{
    Xil_DCacheDisable();
    Xil_ICacheDisable();
}
