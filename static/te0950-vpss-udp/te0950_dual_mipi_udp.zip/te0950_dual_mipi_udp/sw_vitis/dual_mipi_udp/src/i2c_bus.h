#ifndef I2C_BUS_H
#define I2C_BUS_H

#include "xil_types.h"

int i2c_bus_init(void);
/* Fail if Artix soft-PCA9548 @ 0x70 does not ACK (bitstream missing / C2C_RST). */
int i2c_check_artix_programmed(void);
int i2c_artix_select_hs1(void);
int i2c_ps_write(void *ctx, u8 addr7, u16 reg, u8 val);
int i2c_ps_read(void *ctx, u8 addr7, u16 reg, u8 *val);
int i2c_axi_write(void *ctx, u8 addr7, u16 reg, u8 val);
int i2c_axi_read(void *ctx, u8 addr7, u16 reg, u8 *val);
void cam0_gpio_enable(void);

#endif
