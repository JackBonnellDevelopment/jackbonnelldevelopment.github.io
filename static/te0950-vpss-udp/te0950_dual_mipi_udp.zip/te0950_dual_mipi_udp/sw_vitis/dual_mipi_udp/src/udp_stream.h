#ifndef UDP_STREAM_H
#define UDP_STREAM_H

#include "xil_types.h"
#include "lwip/udp.h"

#define MIPI_UDP_MAGIC      0x3150494DU /* 'MIP1' */
#define MIPI_UDP_HDR_LEN    24U
#define MIPI_UDP_PAYLOAD    1460U
/*
 * 640x180 RGB8 is 237 datagrams/frame. A line-rate burst is ~8100 pkt/s and
 * this PC keeps ~6500/s, so frames arrive with holes. 25 fps is 5925 pkt/s.
 */
#define UDP_MAX_FPS         25U

#define BOARD_IP_ADDR       "192.168.8.20"  /* DHCP fallback if no lease */
#define BOARD_IP_MASK       "255.255.255.0"
#define BOARD_IP_GW         "192.168.8.1"
#define DEST_IP_ADDR        "192.168.8.220" /* this PC — avoid broadcast drops */
#define DEST_PORT_CAM0      55000
#define DEST_PORT_CAM1      55001

struct mipi_udp_hdr {
    u32 magic;
    u16 cam_id;
    u16 hdr_len;
    u32 frame_id;
    u32 offset;
    u32 total;
    u16 width;
    u16 height;
};

void te0950_eth_phy_release(void);
int  net_init(void);
void net_poll(void);
void net_wait_ms(u32 ms);
void net_announce(void);
/* ARP to DEST_IP so the first UDP frame is not dropped. */
void net_prime_dest(void);
void net_arp_poke(void);
int  net_tx_ready(void);
u32  net_last_send_ms(void);
int  udp_send_frame(unsigned cam, u32 frame_id, const u8 *data, u32 nbytes,
                    u16 width, u16 height);

#endif
