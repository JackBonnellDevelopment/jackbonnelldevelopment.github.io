/******************************************************************************
 * cam0 = AXI IIC (J15), cam1 = PS I2C0 via Artix PCA9548 ch0 (CR00240 HS1)
 *****************************************************************************/
#include "i2c_bus.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "xiicps.h"
#include "xiic.h"
#include "xparameters.h"
#include "sleep.h"

#define ARTIX_MUX_ADDR  0x70U
#define ARTIX_MUX_CH0   0x01U
#define CR00240_EEPROM  0x52U
#define IIC_SCLK_HZ     100000U

static XIicPs PsIic;
static UINTPTR AxiIicBase;

static UINTPTR axi_iic_base(void)
{
#ifdef XPAR_AXI_IIC_CAM0_BASEADDR
    return XPAR_AXI_IIC_CAM0_BASEADDR;
#elif defined(XPAR_AXI_IIC_0_BASEADDR)
    return XPAR_AXI_IIC_0_BASEADDR;
#elif defined(XPAR_IIC_0_BASEADDR)
    return XPAR_IIC_0_BASEADDR;
#else
    return 0;
#endif
}

static UINTPTR gpio_cam0_base(void)
{
#ifdef XPAR_AXI_GPIO_CAM0_BASEADDR
    return XPAR_AXI_GPIO_CAM0_BASEADDR;
#elif defined(XPAR_GPIO_0_BASEADDR)
    return XPAR_GPIO_0_BASEADDR;
#else
    return 0;
#endif
}

void cam0_gpio_enable(void)
{
    UINTPTR b = gpio_cam0_base();
    if (!b)
        return;
    /* AXI GPIO data + tri-state (0 = output). Pulse enable low then high
     * so IMX219 XCLR/PWDN is released after power-up. */
    Xil_Out32(b + 0x04U, 0x0U);
    Xil_Out32(b + 0x00U, 0x0U);
    usleep(10000);
    Xil_Out32(b + 0x00U, 0x3U);
    usleep(20000);
}

static int ps_wait(void)
{
    u32 t = 0;
    while (XIicPs_BusIsBusy(&PsIic)) {
        if (++t > 100000U)
            return -1;
    }
    return 0;
}

int i2c_bus_init(void)
{
    XIicPs_Config *cfg = NULL;

    AxiIicBase = axi_iic_base();
    cam0_gpio_enable();
    usleep(50000);

#if defined(XPAR_XIICPS_0_BASEADDR)
    cfg = XIicPs_LookupConfig(XPAR_XIICPS_0_BASEADDR);
#elif defined(XPAR_XIICPS_0_DEVICE_ID)
    cfg = XIicPs_LookupConfig(XPAR_XIICPS_0_DEVICE_ID);
#elif defined(XPAR_PSV_I2C_0_BASEADDR)
    cfg = XIicPs_LookupConfig(XPAR_PSV_I2C_0_BASEADDR);
#endif
    if (cfg == NULL) {
        xil_printf("ERROR: PS I2C0 not in BSP\r\n");
        return -1;
    }
    if (XIicPs_CfgInitialize(&PsIic, cfg, cfg->BaseAddress) != XST_SUCCESS)
        return -1;
    XIicPs_SetSClk(&PsIic, IIC_SCLK_HZ);
    xil_printf("PS I2C0 ready; AXI IIC @ 0x%08lx  cam0 GPIO @ 0x%08lx\r\n",
               (unsigned long)AxiIicBase, (unsigned long)gpio_cam0_base());
    return 0;
}

int i2c_artix_select_hs1(void)
{
    u8 ch = ARTIX_MUX_CH0;
    if (XIicPs_MasterSendPolled(&PsIic, &ch, 1, ARTIX_MUX_ADDR) != XST_SUCCESS) {
        xil_printf("ERROR: Artix mux @0x70 NACK — program Artix MIPI companion first\r\n");
        return -1;
    }
    return ps_wait();
}

int i2c_check_artix_programmed(void)
{
    u8 ch = ARTIX_MUX_CH0;
    u8 mux = 0;
    u8 eeprom[6];
    int i;

    xil_printf("Artix: probing I2C mux @0x%02x (PS I2C0 EMIO)...\r\n", ARTIX_MUX_ADDR);
    if (XIicPs_MasterSendPolled(&PsIic, &ch, 1, ARTIX_MUX_ADDR) != XST_SUCCESS) {
        xil_printf("ERROR: Artix not programmed — mux @0x%02x NACK\r\n", ARTIX_MUX_ADDR);
        xil_printf("       Flash hw_artix/export/te0950_artix_mipi.bit, check C2C_RST\r\n");
        return -1;
    }
    if (ps_wait() != 0) {
        xil_printf("ERROR: I2C bus stuck after Artix mux select\r\n");
        return -1;
    }

    if (XIicPs_MasterRecvPolled(&PsIic, &mux, 1, ARTIX_MUX_ADDR) != XST_SUCCESS) {
        xil_printf("ERROR: Artix mux @0x%02x ACK on write but NACK on read\r\n",
                   ARTIX_MUX_ADDR);
        return -1;
    }
    (void)ps_wait();
    xil_printf("Artix: I2C mux @0x%02x ACK (ctrl=0x%02x, ch0=HS1) — companion OK\r\n",
               ARTIX_MUX_ADDR, mux);

    if (XIicPs_MasterRecvPolled(&PsIic, eeprom, (int)sizeof(eeprom), CR00240_EEPROM)
        != XST_SUCCESS) {
        xil_printf("WARN: CR00240 EEPROM @0x%02x NACK (adapter missing?) — Artix OK\r\n",
                   CR00240_EEPROM);
        return 0;
    }
    (void)ps_wait();
    xil_printf("CR00240 EEPROM @0x%02x:", CR00240_EEPROM);
    for (i = 0; i < (int)sizeof(eeprom); i++)
        xil_printf(" %02x", eeprom[i]);
    xil_printf("\r\n");
    return 0;
}

int i2c_ps_write(void *ctx, u8 addr7, u16 reg, u8 val)
{
    u8 buf[3];
    (void)ctx;
    /* Keep Artix mux on HS1 — other SMBus activity can clear the channel. */
    if (addr7 != ARTIX_MUX_ADDR && i2c_artix_select_hs1() != 0)
        return -1;
    buf[0] = (u8)(reg >> 8);
    buf[1] = (u8)reg;
    buf[2] = val;
    if (XIicPs_MasterSendPolled(&PsIic, buf, 3, addr7) != XST_SUCCESS)
        return -1;
    return ps_wait();
}

int i2c_ps_read(void *ctx, u8 addr7, u16 reg, u8 *val)
{
    u8 buf[2];
    (void)ctx;
    if (addr7 != ARTIX_MUX_ADDR && i2c_artix_select_hs1() != 0)
        return -1;
    buf[0] = (u8)(reg >> 8);
    buf[1] = (u8)reg;
    if (XIicPs_MasterSendPolled(&PsIic, buf, 2, addr7) != XST_SUCCESS)
        return -1;
    if (ps_wait() != 0)
        return -1;
    if (XIicPs_MasterRecvPolled(&PsIic, val, 1, addr7) != XST_SUCCESS)
        return -1;
    return ps_wait();
}

int i2c_axi_write(void *ctx, u8 addr7, u16 reg, u8 val)
{
    u8 buf[3];
    (void)ctx;
    if (!AxiIicBase)
        return -1;
    buf[0] = (u8)(reg >> 8);
    buf[1] = (u8)reg;
    buf[2] = val;
    return (XIic_Send(AxiIicBase, addr7, buf, 3, XIIC_STOP) == 3) ? 0 : -1;
}

int i2c_axi_read(void *ctx, u8 addr7, u16 reg, u8 *val)
{
    u8 buf[2];
    (void)ctx;
    if (!AxiIicBase)
        return -1;
    buf[0] = (u8)(reg >> 8);
    buf[1] = (u8)reg;
    if (XIic_Send(AxiIicBase, addr7, buf, 2, XIIC_REPEATED_START) != 2)
        return -1;
    return (XIic_Recv(AxiIicBase, addr7, val, 1, XIIC_STOP) == 1) ? 0 : -1;
}
