/******************************************************************************
 * Capture per-cam via v_frmbuf_wr into DDR at 320x180 (VPSS bilinear).
 * PS waits for both writers, memcpy-stitches 320|320 into 640x180.
 *****************************************************************************/
#include "mipi_pipe.h"
#include "xil_io.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "xparameters.h"
#include "xcsi_hw.h"
#include "xvprocss.h"
#include "xvidc.h"
#include "sleep.h"
#include <string.h>

#define FRM_AP_CTRL     0x00U
#define FRM_GIE         0x04U
#define FRM_IER         0x08U
#define FRM_ISR         0x0cU
#define FRM_WIDTH       0x10U
#define FRM_HEIGHT      0x18U
#define FRM_STRIDE      0x20U
#define FRM_FORMAT      0x28U
#define FRM_ADDR        0x30U
#define FRM_ADDR_MSB    0x34U
#define FRM_AP_START    0x81U /* ap_start | auto_restart */
#define FRM_FMT_RGB8    20U

#define DEMO_AP_CTRL    0x00U
#define DEMO_WIDTH      0x10U
#define DEMO_HEIGHT     0x18U
#define DEMO_BAYER      0x28U
/* IMX219 Bayer is RGGB → phase 0 (RG/GB). */
#define DEMO_BAYER_PHASE 0U
#define DEMO_PAINT      0x5AU

#define MIX_AP_CTRL     0x00U
#define MIX_WIDTH       0x10U
#define MIX_HEIGHT      0x18U
#define MIX_VIDFMT      0x20U
#define MIX_BG_R        0x28U
#define MIX_BG_G        0x30U
#define MIX_BG_B        0x38U
#define MIX_LAYER_EN    0x40U
#define MIX_L1_ALPHA    0x200U
#define MIX_L1_X        0x208U
#define MIX_L1_Y        0x210U
#define MIX_L1_W        0x218U
#define MIX_L1_H        0x228U
#define MIX_L2_ALPHA    0x300U
#define MIX_L2_X        0x308U
#define MIX_L2_Y        0x310U
#define MIX_L2_W        0x318U
#define MIX_L2_H        0x328U

#define TPG_AP_CTRL     0x00U
#define TPG_HEIGHT      0x10U
#define TPG_WIDTH       0x18U
#define TPG_BCKGND      0x20U
#define TPG_COLORFMT    0x40U
#define TPG_BKGND_BLACK TPG_PAT_SOLID_BLACK
#define TPG_BKGND_BARS  TPG_PAT_COLOR_BARS

static UINTPTR OutFb[2] = {OUT_FB0, OUT_FB1};
static UINTPTR CamFb[2][2] = {
    {CAM0_FB0, CAM0_FB1},
    {CAM1_FB0, CAM1_FB1}
};
static UINTPTR LastOut;
static UINTPTR CsiBase[2];
static UINTPTR DemoBase[2];
static UINTPTR CamWrBase[2];
static UINTPTR VpssBase[2];
static XVprocSs Vpss[2];
static int VpssReady[2];
static UINTPTR CamRdBase[2];
static UINTPTR MixBase;
static UINTPTR OutBase;
static UINTPTR TpgBase;
static u32     OutIdx;
static u32     CamWrIdx[2];
static u32     CamDispIdx[2];
static u8      CamDonePend[2];
static u8      CamCaptureEn[2];
static u8      StitchReady;

static UINTPTR first_defined(UINTPTR a, UINTPTR b, UINTPTR c)
{
    if (a) return a;
    if (b) return b;
    return c;
}

static void resolve_bases(void)
{
    CsiBase[0] = first_defined(
#ifdef XPAR_MIPI_CSI_CAM0_BASEADDR
        XPAR_MIPI_CSI_CAM0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_MIPI_CSI2_RX_SUBSYSTEM_0_BASEADDR
        XPAR_MIPI_CSI2_RX_SUBSYSTEM_0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XMIPICSI2RXSS_0_BASEADDR
        XPAR_XMIPICSI2RXSS_0_BASEADDR
#else
        0
#endif
    );
    CsiBase[1] = first_defined(
#ifdef XPAR_MIPI_CSI_CAM1_BASEADDR
        XPAR_MIPI_CSI_CAM1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_MIPI_CSI2_RX_SUBSYSTEM_1_BASEADDR
        XPAR_MIPI_CSI2_RX_SUBSYSTEM_1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XMIPICSI2RXSS_1_BASEADDR
        XPAR_XMIPICSI2RXSS_1_BASEADDR
#else
        0
#endif
    );
    DemoBase[0] = first_defined(
#ifdef XPAR_V_DEMOSAIC_CAM0_BASEADDR
        XPAR_V_DEMOSAIC_CAM0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_DEMOSAIC_0_S_AXI_CTRL_BASEADDR
        XPAR_XV_DEMOSAIC_0_S_AXI_CTRL_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_DEMOSAIC_0_BASEADDR
        XPAR_XV_DEMOSAIC_0_BASEADDR
#else
        0
#endif
    );
    DemoBase[1] = first_defined(
#ifdef XPAR_V_DEMOSAIC_CAM1_BASEADDR
        XPAR_V_DEMOSAIC_CAM1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_DEMOSAIC_1_S_AXI_CTRL_BASEADDR
        XPAR_XV_DEMOSAIC_1_S_AXI_CTRL_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_DEMOSAIC_1_BASEADDR
        XPAR_XV_DEMOSAIC_1_BASEADDR
#else
        0
#endif
    );
    CamWrBase[0] = first_defined(
#ifdef XPAR_V_FRMBUF_WR_CAM0_BASEADDR
        XPAR_V_FRMBUF_WR_CAM0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_WR_0_BASEADDR
        XPAR_XV_FRMBUF_WR_0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_WR_0_S_AXI_CTRL_BASEADDR
        XPAR_XV_FRMBUF_WR_0_S_AXI_CTRL_BASEADDR
#else
        0
#endif
    );
    CamWrBase[1] = first_defined(
#ifdef XPAR_V_FRMBUF_WR_CAM1_BASEADDR
        XPAR_V_FRMBUF_WR_CAM1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_WR_1_BASEADDR
        XPAR_XV_FRMBUF_WR_1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_WR_1_S_AXI_CTRL_BASEADDR
        XPAR_XV_FRMBUF_WR_1_S_AXI_CTRL_BASEADDR
#else
        0
#endif
    );
    VpssBase[0] = first_defined(
#ifdef XPAR_V_PROC_SS_CAM0_BASEADDR
        XPAR_V_PROC_SS_CAM0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_V_PROC_SS_0_BASEADDR
        XPAR_V_PROC_SS_0_BASEADDR,
#else
        0,
#endif
        0
    );
    VpssBase[1] = first_defined(
#ifdef XPAR_V_PROC_SS_CAM1_BASEADDR
        XPAR_V_PROC_SS_CAM1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_V_PROC_SS_1_BASEADDR
        XPAR_V_PROC_SS_1_BASEADDR,
#else
        0,
#endif
        0
    );
    CamRdBase[0] = first_defined(
#ifdef XPAR_V_FRMBUF_RD_CAM0_BASEADDR
        XPAR_V_FRMBUF_RD_CAM0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_RD_0_BASEADDR
        XPAR_XV_FRMBUF_RD_0_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_RD_0_S_AXI_CTRL_BASEADDR
        XPAR_XV_FRMBUF_RD_0_S_AXI_CTRL_BASEADDR
#else
        0
#endif
    );
    CamRdBase[1] = first_defined(
#ifdef XPAR_V_FRMBUF_RD_CAM1_BASEADDR
        XPAR_V_FRMBUF_RD_CAM1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_RD_1_BASEADDR
        XPAR_XV_FRMBUF_RD_1_BASEADDR,
#else
        0,
#endif
#ifdef XPAR_XV_FRMBUF_RD_1_S_AXI_CTRL_BASEADDR
        XPAR_XV_FRMBUF_RD_1_S_AXI_CTRL_BASEADDR
#else
        0
#endif
    );
#ifdef XPAR_V_MIX_0_BASEADDR
    MixBase = XPAR_V_MIX_0_BASEADDR;
#elif defined(XPAR_XV_MIX_0_BASEADDR)
    MixBase = XPAR_XV_MIX_0_BASEADDR;
#elif defined(XPAR_XV_MIX_0_S_AXI_CTRL_BASEADDR)
    MixBase = XPAR_XV_MIX_0_S_AXI_CTRL_BASEADDR;
#else
    MixBase = 0;
#endif
#ifdef XPAR_V_FRMBUF_OUT_BASEADDR
    OutBase = XPAR_V_FRMBUF_OUT_BASEADDR;
#else
    OutBase = 0;
#endif
#ifdef XPAR_V_TPG_MIX_BASEADDR
    TpgBase = XPAR_V_TPG_MIX_BASEADDR;
#elif defined(XPAR_XV_TPG_0_BASEADDR)
    TpgBase = XPAR_XV_TPG_0_BASEADDR;
#elif defined(XPAR_XV_TPG_0_S_AXI_CTRL_BASEADDR)
    TpgBase = XPAR_XV_TPG_0_S_AXI_CTRL_BASEADDR;
#else
    TpgBase = 0;
#endif
}

static void csi_prog(UINTPTR base, int do_soft_reset, int core_on)
{
    const u32 pcr_2lane = (1U << XCSI_PCR_MAXLANES_SHIFT) |
                          (1U << XCSI_PCR_ACTLANES_SHIFT);

    /*
     * PG232: never leave COREENB set while demosaic/wr are stopped —
     * VFB runs with no tready → SLBF / zero video_out while pktcount stays OK.
     * Soft-reset only with core left off; enable after frm_start in arm_pipe.
     */
    if (do_soft_reset) {
        Xil_Out32(base + XCSI_CCR_OFFSET, XCSI_CCR_SOFTRESET_MASK);
        usleep(1000);
        Xil_Out32(base + XCSI_CCR_OFFSET, 0U);
        usleep(100);
    }
    Xil_Out32(base + XCSI_PCR_OFFSET, pcr_2lane);
    Xil_Out32(base + XCSI_VC_SEL_OFFSET, 0xFFFFU);
    Xil_Out32(base + XCSI_ISR_OFFSET, 0xFFFFFFFFU);
    Xil_Out32(base + XCSI_CCR_OFFSET, core_on ? XCSI_CCR_COREENB_MASK : 0U);
}

/* Soft-reset + program; core left OFF. Sensors standby; sinks stopped. */
void mipi_pipe_csi_kick(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return;
    csi_prog(CsiBase[cam], 1, 0);
}

/* Drop COREENB before stopping sinks — otherwise VFB wedges (black RGB). */
static void csi_core_off(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return;
    Xil_Out32(CsiBase[cam] + XCSI_CCR_OFFSET, 0U);
}

/* Assert COREENB only — sinks must already be running (end of arm_pipe). */
void mipi_pipe_csi_core_on(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return;
    /* Clear sticky ISR (esp. SLBF) before enabling VFB again. */
    Xil_Out32(CsiBase[cam] + XCSI_ISR_OFFSET, 0xFFFFFFFFU);
    csi_prog(CsiBase[cam], 0, 1);
}

static void tpg_start_pat(u32 pattern)
{
    if (!TpgBase)
        return;
    Xil_Out32(TpgBase + TPG_AP_CTRL, 0U);
    usleep(100);
    Xil_Out32(TpgBase + TPG_HEIGHT, OUT_HEIGHT);
    Xil_Out32(TpgBase + TPG_WIDTH, OUT_WIDTH);
    Xil_Out32(TpgBase + TPG_BCKGND, pattern);
    Xil_Out32(TpgBase + TPG_COLORFMT, 0U);
    Xil_Out32(TpgBase + TPG_AP_CTRL, FRM_AP_START);
}

static void tpg_start(void)
{
    tpg_start_pat(TPG_BKGND_BLACK);
}

static void demo_stop(UINTPTR base)
{
    if (!base)
        return;
    Xil_Out32(base + DEMO_AP_CTRL, 0U);
}

static void demo_start(UINTPTR base)
{
    if (!base)
        return;
    Xil_Out32(base + DEMO_AP_CTRL, 0U);
    usleep(100);
    Xil_Out32(base + DEMO_WIDTH, SENSOR_WIDTH);
    Xil_Out32(base + DEMO_HEIGHT, SENSOR_HEIGHT);
    Xil_Out32(base + DEMO_BAYER, DEMO_BAYER_PHASE);
    Xil_Out32(base + DEMO_AP_CTRL, FRM_AP_START);
}

static void frm_setup(UINTPTR base, UINTPTR addr, u32 w, u32 h, u32 stride)
{
    if (!base)
        return;
    Xil_Out32(base + FRM_AP_CTRL, 0U);
    usleep(50);
    Xil_Out32(base + FRM_WIDTH,  w);
    Xil_Out32(base + FRM_HEIGHT, h);
    Xil_Out32(base + FRM_STRIDE, stride);
    Xil_Out32(base + FRM_FORMAT, FRM_FMT_RGB8);
    Xil_Out32(base + FRM_ADDR,   (u32)addr);
    Xil_Out32(base + FRM_ADDR_MSB, 0U);
    Xil_Out32(base + FRM_IER,    1U);
    Xil_Out32(base + FRM_GIE,    0U);
    Xil_Out32(base + FRM_ISR,    1U);
}

static void frm_start(UINTPTR base)
{
    if (!base)
        return;
    Xil_Out32(base + FRM_ISR, 1U);
    Xil_Out32(base + FRM_AP_CTRL, FRM_AP_START);
}

static void frm_stop(UINTPTR base)
{
    if (!base)
        return;
    Xil_Out32(base + FRM_AP_CTRL, 0U);
}

static u32 VpssTimerRef;

static void vpss_delay(void *ref, u32 us)
{
    (void)ref;
    usleep(us);
}

static void fill_rgb_stream(XVidC_VideoStream *s, u16 w, u16 h)
{
    memset(s, 0, sizeof(*s));
    s->VmId = XVIDC_VM_CUSTOM;
    s->ColorFormatId = XVIDC_CSF_RGB;
    s->ColorDepth = XVIDC_BPC_8;
    s->PixPerClk = XVIDC_PPC_2;
    s->FrameRate = XVIDC_FR_30HZ;
    s->Timing.HActive = w;
    s->Timing.VActive = h;
}

static void vpss_stop(unsigned cam)
{
    if (cam > 1U || !VpssReady[cam])
        return;
    XVprocSs_Stop(&Vpss[cam]);
}

/* Program bilinear 1920x1080 → 320x180 and start both scalers. */
static int vpss_start(unsigned cam)
{
    XVprocSs_Config *cfg;
    XVidC_VideoStream in_s;
    XVidC_VideoStream out_s;
    UINTPTR base;

    if (cam > 1U)
        return -1;
    base = VpssBase[cam];
    if (!base) {
        xil_printf("cam%u VPSS missing\r\n", cam);
        return -1;
    }
    cfg = XVprocSs_LookupConfig(base);
    if (cfg == NULL) {
        xil_printf("cam%u VPSS lookup failed\r\n", cam);
        return -1;
    }
    memset(&Vpss[cam], 0, sizeof(Vpss[cam]));
    VpssReady[cam] = 0;
    if (XVprocSs_CfgInitialize(&Vpss[cam], cfg, base) != XST_SUCCESS) {
        xil_printf("cam%u VPSS init failed\r\n", cam);
        return -1;
    }
    XVprocSs_SetUserTimerHandler(&Vpss[cam], vpss_delay, &VpssTimerRef);
    fill_rgb_stream(&in_s, (u16)SENSOR_WIDTH, (u16)SENSOR_HEIGHT);
    fill_rgb_stream(&out_s, (u16)CAP_WIDTH, (u16)CAP_HEIGHT);
    XVprocSs_SetVidStreamIn(&Vpss[cam], &in_s);
    XVprocSs_SetVidStreamOut(&Vpss[cam], &out_s);
    if (XVprocSs_SetSubsystemConfig(&Vpss[cam]) != XST_SUCCESS) {
        xil_printf("cam%u VPSS scaler config failed\r\n", cam);
        return -1;
    }
    VpssReady[cam] = 1;
    return 0;
}

static void mean_log(UINTPTR fb)
{
    static u32 mean_n;
    u32 sum = 0;
    u32 i;
    const u8 *p = (const u8 *)fb;
    const u32 n = OUT_FRAME_B / 64U;

    Xil_DCacheInvalidateRange((INTPTR)fb, OUT_FRAME_B);
    for (i = 0; i < n; i++)
        sum += p[i * 64U];
    if ((++mean_n % 300U) == 1U)
        xil_printf("out mean=%u\r\n", n ? (unsigned)(sum / n) : 0U);
}


/* Side-by-side stitch of PL-resized 320x180 tiles. */
static void compose_stitch(UINTPTR dst)
{
    u32 y;
    u8 *out = (u8 *)dst;
    const u8 *c0 = NULL;
    const u8 *c1 = NULL;

    if (CamCaptureEn[0]) {
        c0 = (const u8 *)CamFb[0][CamDispIdx[0]];
        Xil_DCacheInvalidateRange((INTPTR)c0, CAP_FRAME_B);
    }
    if (CamCaptureEn[1]) {
        c1 = (const u8 *)CamFb[1][CamDispIdx[1]];
        Xil_DCacheInvalidateRange((INTPTR)c1, CAP_FRAME_B);
    }
    if (!c0 || !c1)
        memset(out, 0, OUT_FRAME_B);

    for (y = 0; y < CAM_HEIGHT; y++) {
        u8 *row = out + y * OUT_STRIDE;
        if (c0)
            memcpy(row, c0 + y * CAM_STRIDE, CAM_STRIDE);
        if (c1)
            memcpy(row + OUT_CAM1_X * 3U, c1 + y * CAM_STRIDE, CAM_STRIDE);
    }
    Xil_DCacheFlushRange((INTPTR)dst, OUT_FRAME_B);
}

u32 mipi_pipe_out_mean(void)
{
    u32 sum = 0;
    u32 i;
    const u8 *p;
    const u32 n = OUT_FRAME_B / 64U;

    if (!LastOut)
        return 0;
    p = (const u8 *)LastOut;
    Xil_DCacheInvalidateRange((INTPTR)LastOut, OUT_FRAME_B);
    for (i = 0; i < n; i++)
        sum += p[i * 64U];
    return n ? (sum / n) : 0U;
}

void mipi_pipe_tile_means(u32 *left, u32 *right)
{
    mipi_pipe_half_means(left, right);
}

void mipi_pipe_half_means(u32 *left, u32 *right)
{
    u32 y;
    u64 sum0 = 0;
    u64 sum1 = 0;
    u32 n = 0;
    const u8 *p;

    if (left)  *left = 0;
    if (right) *right = 0;
    if (!LastOut)
        return;
    p = (const u8 *)LastOut;
    Xil_DCacheInvalidateRange((INTPTR)LastOut, OUT_FRAME_B);
    for (y = 0; y < OUT_HEIGHT; y += 4U) {
        u32 x;
        const u8 *row = p + y * OUT_STRIDE;
        for (x = 0; x < (OUT_WIDTH / 2U); x += 8U) {
            const u8 *p0 = row + x * 3U;
            const u8 *p1 = row + (x + OUT_WIDTH / 2U) * 3U;
            sum0 += ((u32)p0[0] + p0[1] + p0[2]) / 3U;
            sum1 += ((u32)p1[0] + p1[1] + p1[2]) / 3U;
            n++;
        }
    }
    if (n == 0U)
        return;
    if (left)  *left  = (u32)(sum0 / n);
    if (right) *right = (u32)(sum1 / n);
}

int mipi_pipe_csi_raw10_ok(unsigned cam)
{
    u32 inf;
    u32 inf2;
    u32 bytes;
    u32 dt;

    if (cam > 1U || !CsiBase[cam])
        return 0;
    inf = Xil_In32(CsiBase[cam] + XCSI_VC0INF1R_OFFSET);
    inf2 = Xil_In32(CsiBase[cam] + XCSI_VC0INF2R_OFFSET);
    bytes = inf & 0xFFFFU;
    dt = inf2 & 0x3FU;
    return (bytes == 2400U && dt == 0x2BU) ? 1 : 0;
}

int mipi_pipe_csi_streaming(unsigned cam)
{
    static u32 prev_pkt[2];
    static u8  have_prev[2];
    u32 now;

    if (cam > 1U || !CsiBase[cam])
        return 0;
    now = mipi_pipe_csi_pktcount(cam);
    if (!have_prev[cam]) {
        prev_pkt[cam] = now;
        have_prev[cam] = 1;
        return 0;
    }
    if (now != prev_pkt[cam] && mipi_pipe_csi_raw10_ok(cam)) {
        prev_pkt[cam] = now;
        return 1;
    }
    prev_pkt[cam] = now;
    return 0;
}

void mipi_pipe_set_mix_xy(u32 l1_x, u32 l2_x)
{
    if (!MixBase)
        return;
    Xil_Out32(MixBase + MIX_L1_X, l1_x);
    Xil_Out32(MixBase + MIX_L1_Y, 0U);
    Xil_Out32(MixBase + MIX_L1_W, OUT_TILE_W);
    Xil_Out32(MixBase + MIX_L1_H, OUT_TILE_H);
    Xil_Out32(MixBase + MIX_L2_X, l2_x);
    Xil_Out32(MixBase + MIX_L2_Y, 0U);
    Xil_Out32(MixBase + MIX_L2_W, OUT_TILE_W);
    Xil_Out32(MixBase + MIX_L2_H, OUT_TILE_H);
    Xil_Out32(MixBase + MIX_AP_CTRL, FRM_AP_START);
}

int mipi_pipe_wait_frame(u32 timeout_ms)
{
    u32 t;
    for (t = 0; t < timeout_ms; t += 5U) {
        mipi_pipe_sync_service();
        if (mipi_pipe_harvest(0))
            return 1;
        usleep(5000);
    }
    return 0;
}

int mipi_pipe_init(void)
{
    unsigned cam;
    resolve_bases();
    LastOut = OutFb[0];
    OutIdx = 0;
    StitchReady = 0;
    CamWrIdx[0] = CamWrIdx[1] = 0;
    CamDispIdx[0] = CamDispIdx[1] = 0;
    CamDonePend[0] = CamDonePend[1] = 0;
    CamCaptureEn[0] = CamCaptureEn[1] = 0;
    /* Capture-only: never treat cam wr as "out". */
#ifdef XPAR_V_FRMBUF_OUT_BASEADDR
    OutBase = XPAR_V_FRMBUF_OUT_BASEADDR;
#else
    OutBase = 0;
#endif

    for (cam = 0; cam < 2; cam++) {
        xil_printf("cam%u CSI@0x%08lx demo@0x%08lx wr@0x%08lx\r\n",
                   cam,
                   (unsigned long)CsiBase[cam], (unsigned long)DemoBase[cam],
                   (unsigned long)CamWrBase[cam]);
        /* Soft-reset CSI with core OFF — COREENB only after frm_start. */
        demo_stop(DemoBase[cam]);
        frm_stop(CamWrBase[cam]);
        if (CsiBase[cam])
            csi_prog(CsiBase[cam], 1, 0);
    }

    if (!CamWrBase[0] && !CamWrBase[1]) {
        xil_printf("ERROR: no cam frmbuf_wr — need capture-only PDI\r\n");
        return -1;
    }

    xil_printf("PS stitch: PL NN decimate -> frmbuf %ux%u|%ux%u -> 640x180 UDP\r\n",
               CAM_WIDTH, CAM_HEIGHT, CAM_WIDTH, CAM_HEIGHT);
    xil_printf("  camFB 0x%08lx / 0x%08lx  stitch 0x%08lx\r\n",
               (unsigned long)CAM0_FB0, (unsigned long)CAM1_FB0,
               (unsigned long)OUT_FB0);
    return 0;
}

int mipi_pipe_start_layers(u32 layer_mask, u32 tpg_pattern)
{
    (void)layer_mask;
    (void)tpg_pattern;
    return 0;
}

int mipi_pipe_start_tpg_bars(void)
{
    return mipi_pipe_start_layers(MIX_LAYER_MASTER, TPG_BKGND_BARS);
}

void mipi_pipe_set_layer_enable(u32 layer_mask)
{
    (void)layer_mask;
}

/*
 * Demosaic + VPSS + cam writer. CSI core stays off until the scaler and
 * frame writer are accepting pixels (PG232: COREENB with TREADY low wedges
 * the VFB).
 */
int mipi_pipe_arm_pipe(unsigned cam)
{
    if (cam > 1U)
        return -1;
    CamCaptureEn[cam] = 0;
    csi_core_off(cam);
    usleep(500);
    frm_stop(CamWrBase[cam]);
    vpss_stop(cam);
    demo_stop(DemoBase[cam]);
    usleep(2000);
    demo_start(DemoBase[cam]);
    if (vpss_start(cam) != 0)
        return -1;
    usleep(cam == 1U ? 120000 : 30000);
    if (!CamWrBase[cam]) {
        xil_printf("cam%u frmbuf_wr missing\r\n", cam);
        return -1;
    }
    CamWrIdx[cam] = 0;
    CamDispIdx[cam] = 0;
    CamDonePend[cam] = 0;
    CamCaptureEn[cam] = 1;
    /* Paint so we can tell "no MM write" (stays 0x5A) vs "writes zeros". */
    memset((void *)(UINTPTR)CamFb[cam][0], DEMO_PAINT, CAP_FRAME_B);
    memset((void *)(UINTPTR)CamFb[cam][1], DEMO_PAINT, CAP_FRAME_B);
    Xil_DCacheFlushRange((INTPTR)CamFb[cam][0], CAP_FRAME_B);
    Xil_DCacheFlushRange((INTPTR)CamFb[cam][1], CAP_FRAME_B);
    frm_setup(CamWrBase[cam], CamFb[cam][0], CAP_WIDTH, CAP_HEIGHT, CAP_STRIDE);
    frm_start(CamWrBase[cam]);
    usleep(cam == 1U ? 50000 : 10000);
    /* tready now live — enable CSI core / VFB. */
    mipi_pipe_csi_core_on(cam);
    xil_printf("cam%u capture %ux%u wr->0x%08lx\r\n",
               cam, CAP_WIDTH, CAP_HEIGHT, (unsigned long)CamFb[cam][0]);
    return 0;
}

/*
 * After CSI soft-reset the AXIS into demosaic can desync while frmbuf
 * keeps auto-restarting black frames. Full re-arm (including frmbuf).
 * Caller must ensure sensor is streaming and CSI is NOT soft-reset here.
 */
void mipi_pipe_restart_ingest(unsigned cam)
{
    if (cam > 1U)
        return;
    xil_printf("cam%u full re-arm (demo+wr, no CSI reset)\r\n", cam);
    (void)mipi_pipe_arm_pipe(cam);
}

/*
 * Safe CSI soft-reset: stop demosaic/wr first so VFB is not mid-transfer.
 * Sensor must be in standby (stream_off) before calling.
 */
void mipi_pipe_csi_reset_idle(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return;
    CamCaptureEn[cam] = 0;
    csi_core_off(cam);
    usleep(500);
    frm_stop(CamWrBase[cam]);
    vpss_stop(cam);
    demo_stop(DemoBase[cam]);
    usleep(2000);
    csi_prog(CsiBase[cam], 1, 0); /* soft-reset, core stays OFF until arm_pipe */
    Xil_Out32(CsiBase[cam] + XCSI_ISR_OFFSET, 0xFFFFFFFFU);
}

/*
 * Hot VFB unblock: sinks stay running, CSI soft-reset + COREENB.
 * Use when idle re-arm still leaves RGB black but pktcount advances.
 */
void mipi_pipe_csi_hot_reset(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return;
    xil_printf("cam%u CSI hot-reset (sinks stay up)\r\n", cam);
    csi_core_off(cam);
    usleep(1000);
    Xil_Out32(CsiBase[cam] + XCSI_CCR_OFFSET, XCSI_CCR_SOFTRESET_MASK);
    usleep(1000);
    Xil_Out32(CsiBase[cam] + XCSI_CCR_OFFSET, 0U);
    usleep(200);
    Xil_Out32(CsiBase[cam] + XCSI_PCR_OFFSET,
              (1U << XCSI_PCR_MAXLANES_SHIFT) | (1U << XCSI_PCR_ACTLANES_SHIFT));
    Xil_Out32(CsiBase[cam] + XCSI_VC_SEL_OFFSET, 0xFFFFU);
    Xil_Out32(CsiBase[cam] + XCSI_ISR_OFFSET, 0xFFFFFFFFU);
    /* Ensure demosaic + writer are still accepting. */
    if (DemoBase[cam] && (Xil_In32(DemoBase[cam] + DEMO_AP_CTRL) & 1U) == 0U)
        demo_start(DemoBase[cam]);
    if (vpss_start(cam) != 0)
        return;
    if (CamWrBase[cam] && (Xil_In32(CamWrBase[cam] + FRM_AP_CTRL) & 1U) == 0U)
        frm_start(CamWrBase[cam]);
    usleep(10000);
    mipi_pipe_csi_core_on(cam);
}

u32 mipi_pipe_cam_mean(unsigned cam)
{
    u32 sum = 0;
    u32 i;
    const u8 *p;
    const u32 n = CAP_FRAME_B / 64U;
    UINTPTR fb;

    if (cam > 1U || !CamCaptureEn[cam])
        return 0;
    fb = CamFb[cam][CamDispIdx[cam]];
    p = (const u8 *)fb;
    Xil_DCacheInvalidateRange((INTPTR)fb, CAP_FRAME_B);
    for (i = 0; i < n; i++)
        sum += p[i * 64U];
    return n ? (sum / n) : 0U;
}

/*
 * Start both readers on the same beat so mix overlays stay frame-aligned.
 * Call after both writers have produced at least one frame (or after arm).
 */
void mipi_pipe_start_synced_readers(void)
{
    /* PS stitch path — readers unused. */
}

/*
 * When both writers finish a frame, point both readers at those buffers and
 * flip write targets together. Keeps LDR/R overlays phase-locked.
 */
void mipi_pipe_sync_service(void)
{
    unsigned cam;

    if (!CamCaptureEn[0] && !CamCaptureEn[1])
        return;

    for (cam = 0; cam < 2; cam++) {
        if (!CamCaptureEn[cam] || !CamWrBase[cam])
            continue;
        if (Xil_In32(CamWrBase[cam] + FRM_ISR) & 1U) {
            Xil_Out32(CamWrBase[cam] + FRM_ISR, 1U);
            CamDonePend[cam] = 1;
        }
    }

    if (CamCaptureEn[0] && !CamDonePend[0])
        return;
    if (CamCaptureEn[1] && !CamDonePend[1])
        return;

    for (cam = 0; cam < 2; cam++) {
        if (!CamCaptureEn[cam])
            continue;
        CamDispIdx[cam] = CamWrIdx[cam];
        CamWrIdx[cam] ^= 1U;
        CamDonePend[cam] = 0;
        Xil_Out32(CamWrBase[cam] + FRM_ADDR,
                  (u32)CamFb[cam][CamWrIdx[cam]]);
        Xil_Out32(CamWrBase[cam] + FRM_ADDR_MSB, 0U);
    }
    StitchReady = 1;
}

u32 mipi_pipe_csi_pktcount(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return 0;
    return (Xil_In32(CsiBase[cam] + XCSI_CSR_OFFSET) >> 16) & 0xFFFFU;
}

u32 mipi_pipe_csi_csr(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return 0;
    return Xil_In32(CsiBase[cam] + XCSI_CSR_OFFSET);
}

u32 mipi_pipe_csi_clkinfr(unsigned cam)
{
    if (cam > 1U || !CsiBase[cam])
        return 0;
    return Xil_In32(CsiBase[cam] + XCSI_CLKINFR_OFFSET);
}

u32 mipi_pipe_harvest(unsigned cam)
{
    (void)cam;
    if (!StitchReady)
        return 0;
    StitchReady = 0;
    LastOut = OutFb[OutIdx];
    compose_stitch(LastOut);
    OutIdx ^= 1U;
    return 1;
}

UINTPTR mipi_pipe_out_fb(void)
{
    return LastOut;
}

void mipi_pipe_dump_mix_layers(void)
{
    xil_printf("PS stitch mode (mix overlays unused) cam0=%u cam1=%u\r\n",
               (unsigned)CamCaptureEn[0], (unsigned)CamCaptureEn[1]);
}

void mipi_pipe_dump_status(void)
{
    unsigned cam;

    xil_printf("stitch ready=%u last=0x%08lx capture=%u/%u\r\n",
               (unsigned)StitchReady, (unsigned long)LastOut,
               (unsigned)CamCaptureEn[0], (unsigned)CamCaptureEn[1]);
    for (cam = 0; cam < 2; cam++) {
        u32 csr = CsiBase[cam] ? Xil_In32(CsiBase[cam] + XCSI_CSR_OFFSET) : 0;
        u32 clk = CsiBase[cam] ? Xil_In32(CsiBase[cam] + XCSI_CLKINFR_OFFSET) : 0;
        u32 inf = CsiBase[cam] ? Xil_In32(CsiBase[cam] + XCSI_VC0INF1R_OFFSET) : 0;
        u32 inf2 = CsiBase[cam] ? Xil_In32(CsiBase[cam] + XCSI_VC0INF2R_OFFSET) : 0;
        u32 wctrl = CamWrBase[cam] ? Xil_In32(CamWrBase[cam] + FRM_AP_CTRL) : 0;
        u32 wisr  = CamWrBase[cam] ? Xil_In32(CamWrBase[cam] + FRM_ISR) : 0;
        u32 waddr = CamWrBase[cam] ? Xil_In32(CamWrBase[cam] + FRM_ADDR) : 0;
        u32 dctrl = DemoBase[cam] ? Xil_In32(DemoBase[cam] + DEMO_AP_CTRL) : 0;
        u32 cisr  = CsiBase[cam] ? Xil_In32(CsiBase[cam] + XCSI_ISR_OFFSET) : 0;
        u32 bytes = inf & 0xFFFFU;
        u32 dt = inf2 & 0x3FU;
        xil_printf("cam%u CSI CSR=%08lx CLK=%08lx ISR=%08lx VC0 bytes=%u dt=0x%02x%s "
                   "wr=%08lx/%08lx addr=%08lx demo=%08lx fbmean=%u\r\n",
                   cam, (unsigned long)csr, (unsigned long)clk,
                   (unsigned long)cisr,
                   (unsigned)bytes, (unsigned)dt,
                   (bytes == 2400U && dt == 0x2BU) ? " OK" : "",
                   (unsigned long)wctrl, (unsigned long)wisr,
                   (unsigned long)waddr, (unsigned long)dctrl,
                   (unsigned)mipi_pipe_cam_mean(cam));
        if (cisr & (XCSI_ISR_CRCERR_MASK | XCSI_ISR_ECC2BERR_MASK |
                    XCSI_ISR_SOTERR_MASK | XCSI_ISR_SOTSYNCERR_MASK))
            xil_printf("  cam%u CSI DPHY/CRC ERR — check lanes\r\n", cam);
        else if (cisr & XCSI_ISR_SLBF_MASK)
            xil_printf("  cam%u CSI SLBF sticky (AXIS backpressure)\r\n", cam);
    }
}
