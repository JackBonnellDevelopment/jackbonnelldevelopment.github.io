#ifndef CAM_IMX219_H
#define CAM_IMX219_H

#include "xil_types.h"

#define IMX219_I2C_ADDR     0x10U
#define IMX219_CHIP_ID_H    0x0000U
#define IMX219_CHIP_ID_L    0x0001U
#define IMX219_CHIP_ID      0x0219U

typedef int (*cam_i2c_write_fn)(void *ctx, u8 addr7, u16 reg, u8 val);
typedef int (*cam_i2c_read_fn)(void *ctx, u8 addr7, u16 reg, u8 *val);

int imx219_detect(cam_i2c_write_fn wr, cam_i2c_read_fn rd, void *ctx);
int imx219_init(cam_i2c_write_fn wr, cam_i2c_read_fn rd, void *ctx);
int imx219_stream_on(cam_i2c_write_fn wr, void *ctx);
int imx219_stream_off(cam_i2c_write_fn wr, void *ctx);
/* 0=off, 1=solid white, 2=colour bars */
int imx219_set_test_pattern(cam_i2c_write_fn wr, void *ctx, u16 pattern);

#endif
