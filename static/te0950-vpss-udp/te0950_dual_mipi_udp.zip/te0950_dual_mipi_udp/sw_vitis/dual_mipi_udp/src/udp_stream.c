/******************************************************************************
 * lwIP UDP sender for dual MIPI frames (DHCP with static fallback).
 * Built on the Vitis lwIP echo-server BSP (xemac_add / xemacif_input).
 *****************************************************************************/
#include "udp_stream.h"
#include "mipi_pipe.h"
#include <string.h>
#include "xil_printf.h"
#include "xparameters.h"
#include "xil_cache.h"
#include "netif/xadapter.h"
#include "netif/xemacpsif.h"
#include "netif/etharp.h"
#include "lwip/init.h"
#include "lwip/ip.h"
#include "lwip/def.h"
#include "lwip/netif.h"
#include "lwip/udp.h"
#include "lwip/err.h"
#include "lwip/inet.h"
#include "lwipopts.h"
#if LWIP_DHCP
#include "lwip/dhcp.h"
#include "xiltimer.h"
#endif
#include "platform.h"
#include "xil_io.h"
#include "sleep.h"
#include "xemacps.h"

void platform_enable_interrupts(void);
static void gem_tx_irq_polled_only(void);

static struct netif ServerNetif;
struct netif *echo_netif;
static struct udp_pcb *Pcb[2];
static ip_addr_t DestIp;
static unsigned char MacAddr[] = {0x00, 0x0a, 0x35, 0x00, 0x01, 0x02};

/* TE0950 ETH_RESET is active-low to the 88E1512.
 * Trenz preset: PS_MIO23 (LPD). The old working ELF also pulsed PMC_MIO23.
 * Drive both so a wrong mux/preset cannot leave RESETn asserted. */
#define LPD_IOU_SLCR        0xFF080000U
#define LPD_IOU_WPROT0      0x728U
#define LPD_MIO_PIN0        0x000U
#define LPD_MIO_PIN23       0x05CU
#define LPD_MIO_PIN24       0x060U
#define LPD_MIO_PIN25       0x064U
#define LPD_BNK2_WK_PU      0x114U
#define LPD_MIO_MST_TRI0    0x204U
#define LPD_MIO_SEL         0x410U
#define LPD_GPIO_BASE       0xFF0B0000U
#define LPD_GPIO_MASK_MSW   0x04U
#define LPD_GPIO_DATA0      0x40U
#define LPD_GPIO_DIRM0      0x204U
#define LPD_GPIO_OEN0       0x208U
#define PMC_GPIO_BASE       0xF1020000U
#define PMC_GPIO_DATA0      0x40U
#define PMC_GPIO_DIRM0      0x204U
#define PMC_GPIO_OEN0       0x208U
#define ETH_RESET_BIT       (1U << 23)

static void te0950_ps_mio23_as_gpio_out(void)
{
    u32 v;

    Xil_Out32(LPD_IOU_SLCR + LPD_IOU_WPROT0, 0U);
    /* GPIO on MIO23; GEM MDIO on MIO24/25 (L3_SEL=5 -> 0x280). */
    v = Xil_In32(LPD_IOU_SLCR + LPD_MIO_PIN23);
    Xil_Out32(LPD_IOU_SLCR + LPD_MIO_PIN23, v & ~0x3FEU);
    Xil_Out32(LPD_IOU_SLCR + LPD_MIO_PIN24, 0x280U);
    Xil_Out32(LPD_IOU_SLCR + LPD_MIO_PIN25, 0x280U);
    v = Xil_In32(LPD_IOU_SLCR + LPD_BNK2_WK_PU);
    Xil_Out32(LPD_IOU_SLCR + LPD_BNK2_WK_PU, v | ETH_RESET_BIT | (3U << 24));
    /*
     * PDI only programs MST_TRI bits 0..13 + 24..25. Bits 14..23 wake up
     * tristated (0x7FCxxx). Force CDO-like OE: tristate unused mid pins,
     * drive RGMII/MDIO/ETH_RESET (clear 0..11, 23..25).
     */
    Xil_Out32(LPD_IOU_SLCR + LPD_MIO_MST_TRI0, 0x002FC0U);
    v = Xil_In32(LPD_IOU_SLCR + LPD_MIO_SEL);
    Xil_Out32(LPD_IOU_SLCR + LPD_MIO_SEL, v | 0x3U);
    Xil_Out32(LPD_IOU_SLCR + LPD_IOU_WPROT0, 1U);
}

static void te0950_eth_reset_pin(int released)
{
    u32 data = released ? (1U << 7) : 0U;
    u32 pmc;

    /* LPD MASK_DATA_0_MSW: MIO 16..31 */
    Xil_Out32(LPD_GPIO_BASE + LPD_GPIO_MASK_MSW, 0xFF7F0000U | data);
    /* PMC bank0 bit23 â€” same pulse the Sep-13 working ELF used */
    pmc = Xil_In32(PMC_GPIO_BASE + PMC_GPIO_DATA0);
    if (released)
        pmc |= ETH_RESET_BIT;
    else
        pmc &= ~ETH_RESET_BIT;
    Xil_Out32(PMC_GPIO_BASE + PMC_GPIO_DATA0, pmc);
}

void te0950_eth_phy_release(void)
{
    u32 dirm;
    u32 oen;

    te0950_ps_mio23_as_gpio_out();
    dirm = Xil_In32(LPD_GPIO_BASE + LPD_GPIO_DIRM0);
    oen  = Xil_In32(LPD_GPIO_BASE + LPD_GPIO_OEN0);
    Xil_Out32(LPD_GPIO_BASE + LPD_GPIO_DIRM0, dirm | ETH_RESET_BIT);
    Xil_Out32(LPD_GPIO_BASE + LPD_GPIO_OEN0,  oen  | ETH_RESET_BIT);

    dirm = Xil_In32(PMC_GPIO_BASE + PMC_GPIO_DIRM0);
    oen  = Xil_In32(PMC_GPIO_BASE + PMC_GPIO_OEN0);
    Xil_Out32(PMC_GPIO_BASE + PMC_GPIO_DIRM0, dirm | ETH_RESET_BIT);
    Xil_Out32(PMC_GPIO_BASE + PMC_GPIO_OEN0,  oen  | ETH_RESET_BIT);

    te0950_eth_reset_pin(0);
    usleep(50000);
    te0950_eth_reset_pin(1);
    /* 88E1512 needs >100 ms after RESET# deassert before MDIO/autoneg. */
    usleep(300000);
    xil_printf("ETH_RESET LPD+PMC MIO23  PIN23=%08lx MIO24=%08lx MIO25=%08lx\r\n",
               (unsigned long)Xil_In32(LPD_IOU_SLCR + LPD_MIO_PIN23),
               (unsigned long)Xil_In32(LPD_IOU_SLCR + LPD_MIO_PIN24),
               (unsigned long)Xil_In32(LPD_IOU_SLCR + LPD_MIO_PIN25));
    xil_printf("  LPD DIRM=%08lx DATA=%08lx  PMC DIRM=%08lx DATA=%08lx  MIO_SEL=%08lx TRI=%08lx\r\n",
               (unsigned long)Xil_In32(LPD_GPIO_BASE + LPD_GPIO_DIRM0),
               (unsigned long)Xil_In32(LPD_GPIO_BASE + LPD_GPIO_DATA0),
               (unsigned long)Xil_In32(PMC_GPIO_BASE + PMC_GPIO_DIRM0),
               (unsigned long)Xil_In32(PMC_GPIO_BASE + PMC_GPIO_DATA0),
               (unsigned long)Xil_In32(LPD_IOU_SLCR + LPD_MIO_SEL),
               (unsigned long)Xil_In32(LPD_IOU_SLCR + LPD_MIO_MST_TRI0));
}

/* SDT lwIP skips SetUpSLCRDivisors. CIPS gem0_ref DIV0: 7=1G, 35=100M, 350=10M. */
#define CRL_GEM0_REF_CTRL      0xFF5E0118U
#define CRL_GEM_DIV_MASK       0x0003FF00U
#define CRL_GEM_DIV_SHIFT      8
#define CRL_GEM_DIV_1G         7U
#define CRL_GEM_DIV_100        35U
#define CRL_GEM_DIV_10         350U
#ifndef GEM_BASE
#define GEM_BASE               0xFF0C0000U
#endif

static u32 te0950_gem_div_for_speed(u32 speed_mbps)
{
    if (speed_mbps >= 1000U)
        return CRL_GEM_DIV_1G;
    if (speed_mbps >= 100U)
        return CRL_GEM_DIV_100;
    return CRL_GEM_DIV_10;
}

static void te0950_gem_set_div0(u32 div0);
static void te0950_gem_set_refclk(u32 speed_mbps);

static void te0950_gem_set_div0(u32 div0)
{
    u32 ctrl = Xil_In32(CRL_GEM0_REF_CTRL);
    u32 old_div = (ctrl & CRL_GEM_DIV_MASK) >> CRL_GEM_DIV_SHIFT;

    ctrl = (ctrl & ~CRL_GEM_DIV_MASK) | (div0 << CRL_GEM_DIV_SHIFT);
    Xil_Out32(CRL_GEM0_REF_CTRL, ctrl);
    xil_printf("GEM0 CRL %08lx: DIV0 %u -> %u\r\n",
               (unsigned long)Xil_In32(CRL_GEM0_REF_CTRL), old_div, div0);
}


/* Clause-22 MDIO without XEmacPs instance (before xemac_add). */
static void te0950_mdio_raw_enable(void)
{
    u32 nwcfg = Xil_In32(GEM_BASE + XEMACPS_NWCFG_OFFSET);
    unsigned i;

    Xil_Out32(GEM_BASE + XEMACPS_NWCTRL_OFFSET,
              Xil_In32(GEM_BASE + XEMACPS_NWCTRL_OFFSET) | XEMACPS_NWCTRL_MDEN_MASK);
    nwcfg = (nwcfg & ~XEMACPS_NWCFG_MDCCLKDIV_MASK) |
            ((u32)MDC_DIV_224 << XEMACPS_NWCFG_MDC_SHIFT_MASK);
    Xil_Out32(GEM_BASE + XEMACPS_NWCFG_OFFSET, nwcfg);
    for (i = 0; i < 10000U; i++) {
        if (Xil_In32(GEM_BASE + XEMACPS_NWSR_OFFSET) & XEMACPS_NWSR_MDIOIDLE_MASK)
            break;
    }
}

static u16 te0950_mdio_raw_read(u32 phy, u32 reg)
{
    u32 mgt;
    unsigned i;

    te0950_mdio_raw_enable();
    mgt = XEMACPS_PHYMNTNC_OP_MASK | XEMACPS_PHYMNTNC_OP_R_MASK |
          (phy << XEMACPS_PHYMNTNC_PHAD_SHFT_MSK) |
          (reg << XEMACPS_PHYMNTNC_PREG_SHFT_MSK);
    Xil_Out32(GEM_BASE + XEMACPS_PHYMNTNC_OFFSET, mgt);
    for (i = 0; i < 100000U; i++) {
        if (Xil_In32(GEM_BASE + XEMACPS_NWSR_OFFSET) & XEMACPS_NWSR_MDIOIDLE_MASK)
            break;
    }
    return (u16)Xil_In32(GEM_BASE + XEMACPS_PHYMNTNC_OFFSET);
}

static void te0950_mdio_raw_write(u32 phy, u32 reg, u16 data)
{
    u32 mgt;
    unsigned i;

    te0950_mdio_raw_enable();
    mgt = XEMACPS_PHYMNTNC_OP_MASK | XEMACPS_PHYMNTNC_OP_W_MASK |
          (phy << XEMACPS_PHYMNTNC_PHAD_SHFT_MSK) |
          (reg << XEMACPS_PHYMNTNC_PREG_SHFT_MSK) | (u32)data;
    Xil_Out32(GEM_BASE + XEMACPS_PHYMNTNC_OFFSET, mgt);
    for (i = 0; i < 100000U; i++) {
        if (Xil_In32(GEM_BASE + XEMACPS_NWSR_OFFSET) & XEMACPS_NWSR_MDIOIDLE_MASK)
            break;
    }
}

static void te0950_mdio_raw_page(u16 page)
{
    te0950_mdio_raw_write(1, 22, page);
}

/*
 * 88E1512 must be mode 0 (RGMII-to-copper) BEFORE lwIP AN. Prefer Gigabit
 * so 640x180 RGB stitch can hit 30 fps (~83 Mbps). Fall back to 100 FDX if
 * AN does not resolve (some TE0950 + switch combos stall at 1G).
 */
static void te0950_mdio_probe_early(void)
{
    u16 id1, id2, mode, mscr, spec = 0;
    u32 a;
    u32 speed = 100;
    unsigned i;

    te0950_eth_phy_release();
    te0950_gem_set_div0(CRL_GEM_DIV_1G);
    Xil_Out32(GEM_BASE + XEMACPS_NWCTRL_OFFSET,
              XEMACPS_NWCTRL_MDEN_MASK | XEMACPS_NWCTRL_STATCLR_MASK);
    id1 = te0950_mdio_raw_read(1, 2);
    id2 = te0950_mdio_raw_read(1, 3);
    xil_printf("early MDIO phy1 ID %04x:%04x  NWCTRL=%08lx NWSR=%08lx TRI=%08lx\r\n",
               id1, id2,
               (unsigned long)Xil_In32(GEM_BASE + XEMACPS_NWCTRL_OFFSET),
               (unsigned long)Xil_In32(GEM_BASE + XEMACPS_NWSR_OFFSET),
               (unsigned long)Xil_In32(LPD_IOU_SLCR + LPD_MIO_MST_TRI0));
    if (id1 == 0U && id2 == 0U) {
        for (a = 0; a < 8U; a++) {
            id1 = te0950_mdio_raw_read(a, 2);
            id2 = te0950_mdio_raw_read(a, 3);
            xil_printf("  early phy %u ID %04x:%04x\r\n", a, id1, id2);
        }
        return;
    }

    te0950_mdio_raw_page(18);
    mode = te0950_mdio_raw_read(1, 20);
    mode = (u16)((mode & (u16)~0x7U) | 0x8000U); /* mode 0 + apply */
    te0950_mdio_raw_write(1, 20, mode);
    usleep(50000);

    te0950_mdio_raw_page(2);
    mscr = te0950_mdio_raw_read(1, 21);
    /* Try TX+RX RGMII delay first (common TE0950); retry TX-only if AN fails. */
    te0950_mdio_raw_write(1, 21, (u16)((mscr & (u16)~0x0030U) | 0x0030U));
    te0950_mdio_raw_page(0);

    /* Soft-reset then advertise 1G + 100; wait up to ~5s for copper link. */
    te0950_mdio_raw_write(1, 0, 0x8000);
    usleep(20000);
    te0950_mdio_raw_write(1, 4, 0x0DE1); /* 10/100 + pause */
    te0950_mdio_raw_write(1, 9, 0x0600); /* 1000BASE-T FDX + HDX advertise */
    te0950_mdio_raw_write(1, 0, 0x1340); /* AN enable + restart */
    usleep(200000);
    for (i = 0; i < 50U; i++) {
        spec = te0950_mdio_raw_read(1, 17);
        if (spec & 0x0C00U) /* link or speed-resolved */
            break;
        usleep(100000);
    }
    if (!(spec & 0x0400U)) {
        /* TX-only RGMII delay + 1G-only advertise */
        xil_printf("early PHY AN retry TX-delay/1G  SPEC=%04x\r\n", spec);
        te0950_mdio_raw_page(2);
        mscr = te0950_mdio_raw_read(1, 21);
        te0950_mdio_raw_write(1, 21, (u16)((mscr & (u16)~0x0030U) | 0x0010U));
        te0950_mdio_raw_page(0);
        te0950_mdio_raw_write(1, 4, 0x0001);
        te0950_mdio_raw_write(1, 9, 0x1B00); /* 1000 FDX + master prefer */
        te0950_mdio_raw_write(1, 0, 0x1340);
        usleep(200000);
        for (i = 0; i < 40U; i++) {
            spec = te0950_mdio_raw_read(1, 17);
            if (spec & 0x0400U)
                break;
            usleep(100000);
        }
    }
    if (spec & 0x0400U) {
        switch ((spec >> 14) & 3U) {
        case 2: speed = 1000; break;
        case 1: speed = 100; break;
        default: speed = 10; break;
        }
        xil_printf("early PHY AN link %u Mbps  SPEC=%04x\r\n", speed, spec);
    } else {
        xil_printf("early PHY AN failed - force 100 FDX  SPEC=%04x\r\n", spec);
        te0950_mdio_raw_page(2);
        mscr = te0950_mdio_raw_read(1, 21);
        te0950_mdio_raw_write(1, 21, (u16)((mscr & (u16)~0x0030U) | 0x0030U));
        te0950_mdio_raw_page(0);
        te0950_mdio_raw_write(1, 9, 0x0000);
        te0950_mdio_raw_write(1, 4, 0x0DE1);
        te0950_mdio_raw_write(1, 0, 0x2100);
        usleep(200000);
        speed = 100;
    }
    te0950_gem_set_refclk(speed);
}

static void te0950_gem_set_refclk(u32 speed_mbps)
{
    u32 div0;
    u32 nwctrl;
    u32 nwcfg;

    if (speed_mbps < 10U || speed_mbps == 1U)
        speed_mbps = 100U;
    div0 = te0950_gem_div_for_speed(speed_mbps);
    te0950_gem_set_div0(div0);

    nwctrl = Xil_In32(GEM_BASE + XEMACPS_NWCTRL_OFFSET);
    Xil_Out32(GEM_BASE + XEMACPS_NWCTRL_OFFSET,
              nwctrl & ~(XEMACPS_NWCTRL_TXEN_MASK | XEMACPS_NWCTRL_RXEN_MASK));
    usleep(1000);
    nwcfg = Xil_In32(GEM_BASE + XEMACPS_NWCFG_OFFSET);
    if (speed_mbps >= 1000U) {
        nwcfg |= XEMACPS_NWCFG_1000_MASK;
        nwcfg &= ~XEMACPS_NWCFG_100_MASK;
    } else if (speed_mbps >= 100U) {
        nwcfg &= ~XEMACPS_NWCFG_1000_MASK;
        nwcfg |= XEMACPS_NWCFG_100_MASK;
    } else {
        nwcfg &= ~(XEMACPS_NWCFG_1000_MASK | XEMACPS_NWCFG_100_MASK);
    }
    nwcfg |= XEMACPS_NWCFG_FDEN_MASK;
    Xil_Out32(GEM_BASE + XEMACPS_NWCFG_OFFSET, nwcfg);
    usleep(100);
    Xil_Out32(GEM_BASE + XEMACPS_NWCTRL_OFFSET,
              nwctrl | XEMACPS_NWCTRL_TXEN_MASK | XEMACPS_NWCTRL_RXEN_MASK);

    xil_printf("GEM0 %u Mbps NWCFG=%08lx TXSR=%08lx\r\n",
               speed_mbps,
               (unsigned long)Xil_In32(GEM_BASE + XEMACPS_NWCFG_OFFSET),
               (unsigned long)Xil_In32(GEM_BASE + XEMACPS_TXSR_OFFSET));
}

#define TE0950_PHY_ADDR        1U
#define PHY_PAGE_REG           22U
#define PHY_88E1512_GEN_CTRL   20U
#define PHY_88E1512_MODE_PAGE  18U
#define PHY_88E1512_MSCR_PAGE  2U
#define PHY_88E1512_MSCR       21U
#define PHY_SPEC_STATUS        17U

static XEmacPs *te0950_emac(void)
{
    /* netif->state is struct xemac_s *; xemac->state is xemacpsif_s *. */
    struct xemac_s *xemac = (struct xemac_s *)echo_netif->state;
    xemacpsif_s *ei = (xemacpsif_s *)xemac->state;
    return &ei->emacps;
}

static void te0950_phy_page(XEmacPs *ep, u16 page)
{
    (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, PHY_PAGE_REG, page);
}

/* Prefer Gigabit; retry AN before falling back to forced 100. */
static u32 te0950_phy_bringup(void)
{
    XEmacPs *ep = te0950_emac();
    u16 id1 = 0, id2 = 0, bmsr = 0, spec = 0;
    u32 speed = 100;
    unsigned i;
    extern u32_t link_speed;

    XEmacPs_SetMdioDivisor(ep, MDC_DIV_224);
    te0950_phy_page(ep, 0);
    (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, 2, &id1);
    (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, 3, &id2);
    (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, 1, &bmsr);
    (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, PHY_SPEC_STATUS, &spec);
    xil_printf("PHY ID %04x:%04x  BMSR=%04x SPEC=%04x\r\n", id1, id2, bmsr, spec);

    /* Keep a working copper link. Only retry AN if down or not yet 1G. */
    if ((spec & 0x0400U) && (((spec >> 14) & 3U) == 2U)) {
        speed = 1000;
        xil_printf("PHY copper link 1000 Mbps\r\n");
    } else if ((spec & 0x0400U) && (((spec >> 14) & 3U) == 1U)) {
        speed = 100;
        xil_printf("PHY copper link 100 Mbps (SPEC=%04x) — try elevate to 1G\r\n",
                   spec);
        (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 4, 0x0001);
        (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 9, 0x1B00);
        (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 0, 0x1340);
        for (i = 0; i < 30U; i++) {
            usleep(100000);
            (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, PHY_SPEC_STATUS, &spec);
            if ((spec & 0x0400U) && (((spec >> 14) & 3U) == 2U)) {
                speed = 1000;
                break;
            }
        }
        if (speed != 1000U) {
            xil_printf("PHY stay 100 Mbps after 1G try SPEC=%04x\r\n", spec);
            speed = 100;
            (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 9, 0x0000);
            (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 4, 0x0DE1);
            (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 0, 0x2100);
            usleep(50000);
        } else {
            xil_printf("PHY copper link 1000 Mbps\r\n");
        }
    } else if (!(spec & 0x0400U)) {
        xil_printf("PHY AN retry for 1G...\r\n");
        (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 4, 0x0DE1);
        (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 9, 0x0600);
        (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 0, 0x1340);
        for (i = 0; i < 40U; i++) {
            usleep(100000);
            (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, PHY_SPEC_STATUS, &spec);
            if (spec & 0x0400U)
                break;
        }
        (void)XEmacPs_PhyRead(ep, TE0950_PHY_ADDR, 1, &bmsr);
        xil_printf("PHY after retry BMSR=%04x SPEC=%04x\r\n", bmsr, spec);
        if (spec & 0x0400U) {
            switch ((spec >> 14) & 3U) {
            case 2: speed = 1000; break;
            case 1: speed = 100; break;
            default: speed = 10; break;
            }
            xil_printf("PHY copper link %u Mbps\r\n", speed);
        } else if (bmsr & 0x0004U) {
            speed = (link_speed >= 10U) ? link_speed : 100U;
            xil_printf("PHY SPEC no copper bit - keep %u Mbps (BMSR link)\r\n", speed);
        } else {
            xil_printf("PHY no link - force 100 FDX\r\n");
            (void)XEmacPs_PhyWrite(ep, TE0950_PHY_ADDR, 0, 0x2100);
            usleep(50000);
            speed = 100;
        }
    }

    link_speed = speed;
    XEmacPs_SetOperatingSpeed(ep, (u16)speed);
    te0950_gem_set_refclk(speed);
    return speed;
}

static void set_ip4(ip_addr_t *dst, const char *dotted)
{
    ipaddr_aton(dotted, dst);
}

/* Keep DEST_IP_ADDR (unicast). Broadcast bursts are dropped mid-frame on Windows. */
static void dest_keep_unicast(void)
{
    set_ip4(&DestIp, DEST_IP_ADDR);
}

int net_init(void)
{
    ip_addr_t ipaddr, netmask, gw;
    unsigned cam;
#if LWIP_DHCP
    unsigned n;
#endif

#if LWIP_DHCP
    ip_addr_set_zero_ip4(&ipaddr);
    ip_addr_set_zero_ip4(&netmask);
    ip_addr_set_zero_ip4(&gw);
#else
    set_ip4(&ipaddr,  BOARD_IP_ADDR);
    set_ip4(&netmask, BOARD_IP_MASK);
    set_ip4(&gw,      BOARD_IP_GW);
#endif
    set_ip4(&DestIp,  DEST_IP_ADDR);

    echo_netif = &ServerNetif;
    init_platform();
    /* Probe MDIO before lwIP AN so UART shows PHY ID without the  long wait. */
    te0950_mdio_probe_early();
    lwip_init();
    if (!xemac_add(echo_netif, &ipaddr, &netmask, &gw, MacAddr, GEM_BASE)) {
        xil_printf("ERROR: xemac_add failed (GEM0)\r\n");
        return -1;
    }
    netif_set_default(echo_netif);
    xil_printf("xemac_add done â€” retune GEM for link\r\n");
    /*
     * SDT SetUpSLCRDivisors used to be a no-op ("Using default Speed from design"),
     * so GEM stayed at 1G while PHY is 100. physpeed.c now writes CRL; this
     * path also fixes netif->state indirection and re-applies speed.
     */
    te0950_phy_bringup();
    platform_enable_interrupts();
    gem_tx_irq_polled_only();
    netif_set_up(echo_netif);
    /* Drain any frames that arrived during bring-up. */
    {
        unsigned drain;
        for (drain = 0; drain < 64U; drain++) {
            if (xemacif_input(echo_netif) == 0)
                break;
        }
    }
#if LWIP_DHCP
    xil_printf("DHCP: discovering (MAC %02x:%02x:%02x:%02x:%02x:%02x)...\r\n",
               MacAddr[0], MacAddr[1], MacAddr[2],
               MacAddr[3], MacAddr[4], MacAddr[5]);
    dhcp_start(echo_netif);
    /* ~20 s: poll RX every 1 ms, DHCP fine timer every 500 ms. */
    for (n = 0; n < 20000U; n++) {
        xemacif_input(echo_netif);
        if ((n % 500U) == 0U)
            dhcp_fine_tmr();
        if ((n % 60000U) == 0U)
            dhcp_coarse_tmr();
        if (!ip_addr_isany(&echo_netif->ip_addr))
            break;
        usleep(1000);
    }
    if (ip_addr_isany(&echo_netif->ip_addr)) {
        xil_printf("DHCP timeout - static %s\r\n", BOARD_IP_ADDR);
        set_ip4(&ipaddr,  BOARD_IP_ADDR);
        set_ip4(&netmask, BOARD_IP_MASK);
        set_ip4(&gw,      BOARD_IP_GW);
        netif_set_addr(echo_netif, ip_2_ip4(&ipaddr),
                       ip_2_ip4(&netmask), ip_2_ip4(&gw));
        etharp_gratuitous(echo_netif);
    } else {
        xil_printf("DHCP lease %s\r\n", ipaddr_ntoa(&echo_netif->ip_addr));
        etharp_gratuitous(echo_netif);
    }
#else
    etharp_gratuitous(echo_netif);
#endif
    dest_keep_unicast();
    xil_printf("Board IP %s  ping this\r\n",
               ipaddr_ntoa(&echo_netif->ip_addr));
    xil_printf("GEM0 NWSR=0x%08lx  UDP unicast %s:%u/%u\r\n",
               (unsigned long)Xil_In32(GEM_BASE + XEMACPS_NWSR_OFFSET),
               ipaddr_ntoa(&DestIp), DEST_PORT_CAM0, DEST_PORT_CAM1);

    for (cam = 0; cam < 2; cam++) {
        Pcb[cam] = udp_new();
        if (Pcb[cam] == NULL) {
            xil_printf("ERROR: udp_new cam%u\r\n", cam);
            return -1;
        }
        udp_bind(Pcb[cam], IP_ADDR_ANY, (u16_t)(4000 + cam));
    }
    return 0;
}

/*
 * Disable GEM TX-complete IRQs. low_level_output already calls process_sent
 * under SYS_ARCH_PROTECT; an ISR doing the same races and yields freecnt=1
 * hw=0. Poll reclaim + kick here instead — that previously held ~16 fps.
 */
static void gem_tx_irq_polled_only(void)
{
    XEmacPs *ep;
    u8 q;

    if (echo_netif == NULL || echo_netif->state == NULL)
        return;
    ep = te0950_emac();
    XEmacPs_IntDisable(ep, XEMACPS_IXR_TXCOMPL_MASK | XEMACPS_IXR_TX_ERR_MASK |
                               XEMACPS_IXR_TXUSED_MASK | XEMACPS_IXR_TXEXH_MASK |
                               XEMACPS_IXR_RETRY_MASK | XEMACPS_IXR_URUN_MASK);
    for (q = 1U; q < (u8)ep->MaxQueues; q++)
        XEmacPs_IntQiDisable(ep, q, XEMACPS_INTQ1_IXR_TX_MASK);
}

static void gem_tx_kick(xemacpsif_s *ei)
{
    u32 base = ei->emacps.Config.BaseAddress;
    u32 txsr = XEmacPs_ReadReg(base, XEMACPS_TXSR_OFFSET);
    XEmacPs_BdRing *txring = &(XEmacPs_GetTxRing(&ei->emacps));

    if (txring->HwCnt == 0U)
        return;
    if ((txsr & XEMACPS_TXSR_TXGO_MASK) == 0U) {
        XEmacPs_WriteReg(base, XEMACPS_NWCTRL_OFFSET,
                         XEmacPs_ReadReg(base, XEMACPS_NWCTRL_OFFSET) |
                         XEMACPS_NWCTRL_STARTTX_MASK);
    }
}

#define GEM_TXSR_HARD_ERR ((u32)XEMACPS_TXSR_HRESPNOK_MASK | \
                           (u32)XEMACPS_TXSR_URUN_MASK |     \
                           (u32)XEMACPS_TXSR_BUFEXH_MASK)

static void gem_tx_recover(struct xemac_s *xemac)
{
    static u32 recover_n;

    HandleTxErrors(xemac);
    reset_dma(xemac);
    gem_tx_irq_polled_only();
    recover_n++;
    if ((recover_n & 0x1FU) == 1U)
        xil_printf("GEM TX ring rebuild x%lu\r\n", (unsigned long)recover_n);
}

static void gem_tx_reclaim(void)
{
    struct xemac_s *xemac;
    xemacpsif_s *ei;
    XEmacPs_BdRing *txring;
    u32 base;
    u32 txsr;
    u32 hard;

    if (echo_netif == NULL || echo_netif->state == NULL)
        return;
    xemac = (struct xemac_s *)echo_netif->state;
    ei = (xemacpsif_s *)xemac->state;
    if (ei == NULL)
        return;

    base = ei->emacps.Config.BaseAddress;
    txring = &(XEmacPs_GetTxRing(&ei->emacps));
    txsr = XEmacPs_ReadReg(base, XEMACPS_TXSR_OFFSET);
    hard = txsr & GEM_TXSR_HARD_ERR;

    if (hard != 0U) {
        XEmacPs_WriteReg(base, XEMACPS_TXSR_OFFSET, hard);
        gem_tx_recover(xemac);
        return;
    }

    if ((txsr & (XEMACPS_TXSR_TXCOMPL_MASK | XEMACPS_TXSR_USEDREAD_MASK)) != 0U)
        XEmacPs_WriteReg(base, XEMACPS_TXSR_OFFSET,
                         XEMACPS_TXSR_TXCOMPL_MASK | XEMACPS_TXSR_USEDREAD_MASK);

    xemacps_process_sent_bds(ei, txring);
    gem_tx_kick(ei);
}

void net_poll(void)
{
    gem_tx_reclaim();
    xemacif_input(echo_netif);
#if LWIP_DHCP
    {
        static XTime last_fine;
        static XTime last_coarse;
        XTime now;
        XTime_GetTime(&now);
        if (last_fine == 0) {
            last_fine = now;
            last_coarse = now;
        }
        if ((now - last_fine) >= ((XTime)COUNTS_PER_SECOND / 2U)) {
            last_fine = now;
            dhcp_fine_tmr();
        }
        if ((now - last_coarse) >= ((XTime)COUNTS_PER_SECOND * 60U)) {
            last_coarse = now;
            dhcp_coarse_tmr();
        }
    }
#endif
}

static s32_t gem_tx_freecnt(void)
{
    struct xemac_s *xemac;
    xemacpsif_s *ei;

    if (echo_netif == NULL || echo_netif->state == NULL)
        return -1;
    xemac = (struct xemac_s *)echo_netif->state;
    ei = (xemacpsif_s *)xemac->state;
    if (ei == NULL)
        return -1;
    return xemacps_is_tx_space_available(ei);
}

static s32_t gem_tx_hwcnt(void)
{
    struct xemac_s *xemac;
    xemacpsif_s *ei;

    if (echo_netif == NULL || echo_netif->state == NULL)
        return -1;
    xemac = (struct xemac_s *)echo_netif->state;
    ei = (xemacpsif_s *)xemac->state;
    if (ei == NULL)
        return -1;
    return (s32_t)XEmacPs_GetTxRing(&ei->emacps).HwCnt;
}

/*
 * Wait for free TX BDs. Cap at ~40 ms (one 640x180 frame on 100M) so a
 * wedged ring cannot freeze forever, but we can still ride the wire.
 */
static int tx_wait_space(s32_t need, u32 timeout_spins)
{
    u32 spins = 0;
    XTime t0, now;
    u32 wedge_tries = 0;

    XTime_GetTime(&t0);

    while (gem_tx_freecnt() < need) {
        s32_t free;
        s32_t hw;

        gem_tx_reclaim();
        free = gem_tx_freecnt();
        hw = gem_tx_hwcnt();
        XTime_GetTime(&now);

        if ((now - t0) > ((XTime)COUNTS_PER_SECOND / 25U))
            return -1;

        if (hw > 0 && echo_netif != NULL && echo_netif->state != NULL) {
            struct xemac_s *xemac = (struct xemac_s *)echo_netif->state;
            xemacpsif_s *ei = (xemacpsif_s *)xemac->state;
            if (ei != NULL)
                gem_tx_kick(ei);
        } else if (hw == 0 && free >= 0 && free < need && wedge_tries < 1U &&
                   echo_netif != NULL && echo_netif->state != NULL) {
            gem_tx_recover((struct xemac_s *)echo_netif->state);
            wedge_tries++;
            XTime_GetTime(&t0);
        }

        if (++spins > timeout_spins)
            return -1;
    }
    return 0;
}

void net_announce(void)
{
    etharp_gratuitous(echo_netif);
    net_poll();
}

void net_prime_dest(void)
{
    u32 i;
    struct eth_addr *eth = NULL;
    const ip4_addr_t *ip = NULL;

    dest_keep_unicast();
    xil_printf("ARP resolve %s ...\r\n", ipaddr_ntoa(&DestIp));
    for (i = 0; i < 50U; i++) {
        (void)etharp_request(echo_netif, ip_2_ip4(&DestIp));
        net_poll();
        if (etharp_find_addr(echo_netif, ip_2_ip4(&DestIp), &eth, &ip) >= 0 &&
            eth != NULL) {
            xil_printf("ARP ok %s -> %02x:%02x:%02x:%02x:%02x:%02x\r\n",
                       ipaddr_ntoa(&DestIp),
                       eth->addr[0], eth->addr[1], eth->addr[2],
                       eth->addr[3], eth->addr[4], eth->addr[5]);
            return;
        }
        usleep(100000);
    }
    xil_printf("WARN: no ARP for %s — UDP may be dropped until PC replies\r\n",
               ipaddr_ntoa(&DestIp));
}

void net_arp_poke(void)
{
    dest_keep_unicast();
    (void)etharp_request(echo_netif, ip_2_ip4(&DestIp));
    net_poll();
}

void net_wait_ms(u32 ms)
{
    u32 i;
    for (i = 0; i < ms; i++) {
        net_poll();
        if ((i % 500U) == 0U)
            etharp_gratuitous(echo_netif);
        usleep(1000);
    }
}

static int udp_sendto_pace(struct udp_pcb *pcb, struct pbuf *p,
                           const ip_addr_t *dst, u16_t port)
{
    u32 spins = 0;

    /* Prefer blocking on the wire over dropping — need 2 BDs (hdr+payload). */
    if (tx_wait_space(2, 500000U) != 0)
        return -1;

    for (;;) {
        err_t e = udp_sendto(pcb, p, dst, port);
        if (e == ERR_OK)
            return 0;
        if (e == ERR_MEM) {
            gem_tx_reclaim();
            if (tx_wait_space(2, 500000U) != 0)
                return -1;
        }
        if (++spins > 100000U) {
            xil_printf("TX timeout err=%d TXSR=%08lx freecnt=%ld hw=%ld\r\n",
                       (int)e,
                       (unsigned long)Xil_In32(GEM_BASE + XEMACPS_TXSR_OFFSET),
                       (long)gem_tx_freecnt(), (long)gem_tx_hwcnt());
            return -1;
        }
    }
}

int net_tx_ready(void)
{
    s32_t free;

    if (echo_netif == NULL || echo_netif->state == NULL)
        return 0;

    gem_tx_reclaim();
    free = gem_tx_freecnt();
    return (free >= 2) ? 1 : 0;
}

/* Last completed send duration (ms) — read by main for rate line. */
static volatile u32 LastSendMs;

u32 net_last_send_ms(void)
{
    return LastSendMs;
}

int udp_send_frame(unsigned cam, u32 frame_id, const u8 *data, u32 nbytes,
                   u16 width, u16 height)
{
    u32 off = 0;
    u16 port = (cam == 0) ? DEST_PORT_CAM0 : DEST_PORT_CAM1;
    struct mipi_udp_hdr hdr;
    u32 pkts = 0;
    u32 npkt;
    XTime t0, t1;
    XTime per_pkt;

    XTime_GetTime(&t0);
    npkt = (nbytes + MIPI_UDP_PAYLOAD - 1U) / MIPI_UDP_PAYLOAD;
    if (npkt == 0U)
        npkt = 1U;
    /* Spread the frame across the slot. A back-to-back burst is ~8100 pkt/s
     * and the PC drops the extra; the gap is what keeps each frame whole. */
    per_pkt = (XTime)(COUNTS_PER_SECOND / UDP_MAX_FPS) / (XTime)npkt;
    /* One flush of the stitch FB — payload BDs DMA straight from DDR. */
    Xil_DCacheFlushRange((INTPTR)data, nbytes);
    gem_tx_reclaim();

    hdr.magic   = MIPI_UDP_MAGIC;
    hdr.cam_id  = (u16)cam;
    hdr.hdr_len = MIPI_UDP_HDR_LEN;
    hdr.frame_id = frame_id;
    hdr.total   = nbytes;
    hdr.width   = width;
    hdr.height  = height;

    while (off < nbytes) {
        u32 chunk = nbytes - off;
        struct pbuf *hdr_p;
        struct pbuf *ref_p;
        u32 alloc_spins = 0;
        if (chunk > MIPI_UDP_PAYLOAD)
            chunk = MIPI_UDP_PAYLOAD;
        hdr.offset = off;

        /*
         * Zero-copy: tiny RAM pbuf for our 24B header, PBUF_REF chain to the
         * stitch buffer. emacps_sgsend maps each segment to its own TX BD.
         */
        do {
            hdr_p = pbuf_alloc(PBUF_TRANSPORT, MIPI_UDP_HDR_LEN, PBUF_RAM);
            if (hdr_p != NULL)
                break;
            gem_tx_reclaim();
            xemacif_input(echo_netif);
        } while (++alloc_spins < 5000U);
        if (hdr_p == NULL) {
            xil_printf("TX hdr alloc fail off=%lu freecnt=%ld\r\n",
                       (unsigned long)off, (long)gem_tx_freecnt());
            if (echo_netif != NULL && echo_netif->state != NULL)
                gem_tx_recover((struct xemac_s *)echo_netif->state);
            return -1;
        }

        ref_p = pbuf_alloc(PBUF_RAW, (u16_t)chunk, PBUF_REF);
        if (ref_p == NULL) {
            pbuf_free(hdr_p);
            xil_printf("TX ref alloc fail off=%lu\r\n", (unsigned long)off);
            return -1;
        }
        ref_p->payload = (void *)(data + off);
        ref_p->len = ref_p->tot_len = (u16_t)chunk;

        memcpy(hdr_p->payload, &hdr, sizeof(hdr));
        pbuf_cat(hdr_p, ref_p);

        if (udp_sendto_pace(Pcb[cam], hdr_p, &DestIp, port) != 0) {
            pbuf_free(hdr_p);
            xil_printf("TX abort off=%lu/%lu TXSR=%08lx freecnt=%ld hw=%ld\r\n",
                       (unsigned long)off, (unsigned long)nbytes,
                       (unsigned long)Xil_In32(GEM_BASE + XEMACPS_TXSR_OFFSET),
                       (long)gem_tx_freecnt(), (long)gem_tx_hwcnt());
            if (echo_netif != NULL && echo_netif->state != NULL)
                gem_tx_recover((struct xemac_s *)echo_netif->state);
            return -1;
        }
        pbuf_free(hdr_p);
        off += chunk;
        pkts++;
        gem_tx_reclaim();
        {
            XTime due = t0 + per_pkt * (XTime)pkts;
            XTime nowp;
            do {
                XTime_GetTime(&nowp);
            } while (nowp < due);
        }
    }
    gem_tx_reclaim();
    XTime_GetTime(&t1);
    LastSendMs = (u32)(((t1 - t0) * 1000U) / COUNTS_PER_SECOND);
    return 0;
}
