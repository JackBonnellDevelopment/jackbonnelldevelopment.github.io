/******************************************************************************
 * dual_mipi_udp — TE0950 J15 + CR00240/HS1 IMX219 → Gigabit Ethernet UDP
 *
 * Capture: CSI → demosaic → VPSS → v_frmbuf_wr → DDR (320x180 each)
 * Sync:    PS waits for both writers, stitches 320|320 → 640x180
 * Output:  UDP (no VPSS / Vision / mix / frmbuf_rd)
 *****************************************************************************/
#include <stdio.h>
#include <string.h>
#include "xil_printf.h"
#include "xil_cache.h"
#include "sleep.h"
#include "xiltimer.h"
#include "cam_imx219.h"
#include "i2c_bus.h"
#include "mipi_pipe.h"
#include "xil_io.h"
#include "udp_stream.h"

static int wait_csi_live(unsigned cam, u32 timeout_ms)
{
    u32 t;
    u32 prev = mipi_pipe_csi_pktcount(cam);
    u32 bumps = 0;
    int raw_ok = 0;

    for (t = 0; t < timeout_ms; t += 20U) {
        u32 now = mipi_pipe_csi_pktcount(cam);
        u32 csr = mipi_pipe_csi_csr(cam);
        u32 clk = mipi_pipe_csi_clkinfr(cam);

        if (now != prev) {
            bumps++;
            prev = now;
        }
        raw_ok = mipi_pipe_csi_raw10_ok(cam);
        if (bumps >= 2U && raw_ok) {
            xil_printf("cam%u CSI live pkt=%u bumps=%u raw10 OK csr=%08lx clk=%08lx\r\n",
                       cam, (unsigned)now, (unsigned)bumps,
                       (unsigned long)csr, (unsigned long)clk);
            return 0;
        }
        usleep(20000);
    }
    xil_printf("cam%u CSI NOT live (bumps=%u raw10=%d pkt=%u)\r\n",
               cam, (unsigned)bumps, raw_ok,
               (unsigned)mipi_pipe_csi_pktcount(cam));
    return -1;
}

static void send_stitch(u32 *stitch_id, u32 *sent_since)
{
    /* Send DDR stitch buffer directly; block in udp_send_frame for GEM space. */
    const u8 *fb = (const u8 *)mipi_pipe_out_fb();
    if (udp_send_frame(0, *stitch_id, fb,
                       OUT_FRAME_B, (u16)OUT_WIDTH,
                       (u16)OUT_HEIGHT) == 0) {
        (*stitch_id)++;
        (*sent_since)++;
    }
}

int main(void)
{
    int cam_ok[2] = {0, 0};
    u32 frames = 0;
    u32 prev_frames = 0;

    Xil_ICacheEnable();
    Xil_DCacheEnable();

    xil_printf("\r\n=== TE0950 dual MIPI -> UDP ===\r\n");
    xil_printf("BUILD vpss-20260927c  stitch %ux%u (%ux%u|%ux%u)\r\n",
               OUT_WIDTH, OUT_HEIGHT, CAM_WIDTH, CAM_HEIGHT, CAM_WIDTH, CAM_HEIGHT);
    xil_printf("NOTE: CSI COREENB only after frm_start (PG232 tready)\r\n");
    te0950_eth_phy_release();
    xil_printf("cam0=J15  cam1=CR00240/HS1  %ux%u -> %s:%u\r\n",
               SENSOR_WIDTH, SENSOR_HEIGHT, DEST_IP_ADDR, DEST_PORT_CAM0);

    if (i2c_bus_init() != 0)
        return -1;
    if (i2c_check_artix_programmed() != 0)
        return -1;
    if (mipi_pipe_init() != 0)
        return -1;

    xil_printf("-- cam0 J15 --\r\n");
    cam0_gpio_enable();
    usleep(50000);
    if (imx219_init(i2c_axi_write, i2c_axi_read, NULL) == 0)
        cam_ok[0] = 1;
    else
        xil_printf("WARN: J15 IMX219 missing\r\n");

    xil_printf("-- cam1 CR00240 --\r\n");
    if (i2c_artix_select_hs1() == 0 &&
        imx219_init(i2c_ps_write, i2c_ps_read, NULL) == 0)
        cam_ok[1] = 1;
    else
        xil_printf("WARN: HS1 IMX219 missing\r\n");

    /*
     * Order: soft-reset CSI with COREENB=0 → arm sinks → COREENB in arm_pipe
     * after frm_start → stream_on. Enabling CSI before tready wedges VFB
     * (pktcount OK, RGB zeros) — especially cam1/HS1.
     * Bring HS1 up first so cam0 traffic cannot wedge cam1's VFB mid-arm.
     */
    xil_printf("arming sinks (CSI core off until frm_start)...\r\n");
    if (cam_ok[1] && mipi_pipe_arm_pipe(1) != 0)
        cam_ok[1] = 0;
    if (cam_ok[1]) {
        (void)i2c_artix_select_hs1();
        imx219_stream_on(i2c_ps_write, NULL);
        xil_printf("stream-on cam1 first\r\n");
        usleep(400000);
        (void)wait_csi_live(1, 3000);
        /* Prove HS1 RGB before bringing up J15. */
        {
            u32 t;
            for (t = 0; t < 1500U; t += 20U) {
                mipi_pipe_sync_service();
                if (mipi_pipe_harvest(0))
                    break;
                usleep(20000);
            }
            xil_printf("cam1-only FB mean=%u (paint=0x5A if no MM write)\r\n",
                       (unsigned)mipi_pipe_cam_mean(1));
        }
    }

    if (cam_ok[0] && mipi_pipe_arm_pipe(0) != 0)
        cam_ok[0] = 0;
    if (cam_ok[0]) {
        imx219_stream_on(i2c_axi_write, NULL);
        usleep(200000);
        (void)wait_csi_live(0, 3000);
    }
    xil_printf("stream-on cam0=%d cam1=%d\r\n", cam_ok[0], cam_ok[1]);

    if (cam_ok[0] && !mipi_pipe_csi_streaming(0)) {
        xil_printf("cam0 CSI soft — idle reset then re-arm\r\n");
        imx219_stream_off(i2c_axi_write, NULL);
        mipi_pipe_csi_reset_idle(0);
        usleep(20000);
        if (mipi_pipe_arm_pipe(0) != 0)
            cam_ok[0] = 0;
        else {
            imx219_stream_on(i2c_axi_write, NULL);
            usleep(200000);
        }
    }
    if (cam_ok[1] && !mipi_pipe_csi_streaming(1)) {
        xil_printf("cam1 CSI soft — idle reset then re-arm\r\n");
        (void)i2c_artix_select_hs1();
        imx219_stream_off(i2c_ps_write, NULL);
        mipi_pipe_csi_reset_idle(1);
        usleep(20000);
        if (mipi_pipe_arm_pipe(1) != 0)
            cam_ok[1] = 0;
        else {
            imx219_stream_on(i2c_ps_write, NULL);
            usleep(200000);
        }
    }

    if (!cam_ok[0] && !cam_ok[1]) {
        xil_printf("ERROR: no capture path armed\r\n");
        mipi_pipe_dump_status();
        return -1;
    }

    xil_printf("PS stitch armed cam0=%d cam1=%d — waiting for wr done\r\n",
               cam_ok[0], cam_ok[1]);
    {
        u32 hl = 0, hr = 0;
        u32 c0 = 0, c1 = 0;
        int attempt;

        if (mipi_pipe_wait_frame(3000)) {
            mipi_pipe_half_means(&hl, &hr);
            c0 = mipi_pipe_cam_mean(0);
            c1 = mipi_pipe_cam_mean(1);
            xil_printf("first stitch L/R mean=%u/%u  camFB=%u/%u\r\n",
                       (unsigned)hl, (unsigned)hr,
                       (unsigned)c0, (unsigned)c1);
        } else {
            xil_printf("WARN: no stitch frame yet\r\n");
            mipi_pipe_dump_status();
        }

        /*
         * cam1 black with pktcount OK = CSI VFB wedged (no tready history).
         * Recover: stream_off → core-off idle reset → arm sinks → core on →
         * stream_on. Then hot-reset CSI while sinks stay up. Finally colour
         * bars TP to prove the RGB path.
         */
        for (attempt = 0; cam_ok[1] && c1 < 2U && attempt < 3; attempt++) {
            xil_printf("cam1 FB black — recover attempt %d\r\n", attempt + 1);
            (void)i2c_artix_select_hs1();
            imx219_stream_off(i2c_ps_write, NULL);
            usleep(20000);
            mipi_pipe_csi_reset_idle(1);
            usleep(30000);
            if (mipi_pipe_arm_pipe(1) != 0) {
                cam_ok[1] = 0;
                break;
            }
            imx219_stream_on(i2c_ps_write, NULL);
            usleep(500000);
            (void)wait_csi_live(1, 3000);
            if (mipi_pipe_wait_frame(3000)) {
                c0 = mipi_pipe_cam_mean(0);
                c1 = mipi_pipe_cam_mean(1);
                xil_printf("cam1 after idle-rearm camFB=%u/%u\r\n",
                           (unsigned)c0, (unsigned)c1);
            }
            if (c1 >= 2U)
                break;

            xil_printf("cam1 still black — CSI hot-reset\r\n");
            mipi_pipe_csi_hot_reset(1);
            usleep(400000);
            if (mipi_pipe_wait_frame(3000)) {
                c0 = mipi_pipe_cam_mean(0);
                c1 = mipi_pipe_cam_mean(1);
                xil_printf("cam1 after hot-reset camFB=%u/%u\r\n",
                           (unsigned)c0, (unsigned)c1);
            }
            if (c1 >= 2U)
                break;
        }

        if (cam_ok[1] && c1 < 2U) {
            u8 tp_hi = 0, tp_lo = 0;
            xil_printf("cam1 still black — leave colour-bars TP ON for debug\r\n");
            (void)i2c_artix_select_hs1();
            imx219_stream_off(i2c_ps_write, NULL);
            if (imx219_set_test_pattern(i2c_ps_write, NULL, 2U) != 0)
                xil_printf("ERROR: cam1 test pattern write failed\r\n");
            (void)i2c_ps_read(NULL, 0x10, 0x0600, &tp_hi);
            (void)i2c_ps_read(NULL, 0x10, 0x0601, &tp_lo);
            xil_printf("cam1 TP regs 0600/0601=%02x/%02x (kept ON)\r\n",
                       tp_hi, tp_lo);
            mipi_pipe_csi_reset_idle(1);
            usleep(30000);
            if (mipi_pipe_arm_pipe(1) != 0)
                cam_ok[1] = 0;
            else {
                imx219_stream_on(i2c_ps_write, NULL);
                usleep(500000);
                mipi_pipe_csi_hot_reset(1);
                usleep(300000);
                if (mipi_pipe_wait_frame(3000)) {
                    c1 = mipi_pipe_cam_mean(1);
                    xil_printf("after cam1 bars-TP camFB=%u%s\r\n",
                               (unsigned)c1,
                               (c1 < 2U) ? " DEAD" : " OK — bars left on");
                }
            }
        }
        mipi_pipe_half_means(&hl, &hr);
        xil_printf("pre-UDP stitch L/R=%u/%u camFB=%u/%u\r\n",
                   (unsigned)hl, (unsigned)hr,
                   (unsigned)mipi_pipe_cam_mean(0),
                   (unsigned)mipi_pipe_cam_mean(1));
    }
    mipi_pipe_dump_status();

    if (net_init() != 0)
        return -1;
    net_prime_dest();
    xil_printf("UDP -> %s:%u  paced <=%u fps (640x180 RGB)\r\n",
               DEST_IP_ADDR, DEST_PORT_CAM0, (unsigned)UDP_MAX_FPS);

    {
        XTime last_hb = 0;
        XTime last_fps = 0;
        XTime last_send = 0;
        u32 sent_since = 0;
        u32 stitch_id = 0;
        u32 skip_tx = 0;
        u32 out_mean = 0;
        u32 mean_l = 0;
        u32 mean_r = 0;
        const XTime min_send_dt = (XTime)(COUNTS_PER_SECOND / UDP_MAX_FPS);

        XTime_GetTime(&last_hb);
        last_fps = last_hb;
        last_send = last_hb;

        while (1) {
            XTime now;
            net_poll();
            XTime_GetTime(&now);
            mipi_pipe_sync_service();

            if (mipi_pipe_harvest(0)) {
                if ((frames % 30U) == 0U) {
                    out_mean = mipi_pipe_out_mean();
                    mipi_pipe_half_means(&mean_l, &mean_r);
                }
                if (frames == 0U) {
                    out_mean = mipi_pipe_out_mean();
                    mipi_pipe_half_means(&mean_l, &mean_r);
                    xil_printf("first UDP stitch mean=%u L=%u R=%u\r\n",
                               (unsigned)out_mean, (unsigned)mean_l,
                               (unsigned)mean_r);
                }
                frames++;
                if ((now - last_send) < min_send_dt) {
                    skip_tx++;
                } else {
                    u32 before = stitch_id;
                    XTime_GetTime(&last_send);
                    send_stitch(&stitch_id, &sent_since);
                    if (stitch_id == before) {
                        skip_tx++;
                    } else {
                        /*
                         * Eat the rest of this frame slot here so the next
                         * harvest is not delayed by another camera period.
                         */
                        do {
                            net_poll();
                            XTime_GetTime(&now);
                        } while ((now - last_send) < min_send_dt);
                    }
                }
            }

            if ((now - last_fps) >= (XTime)COUNTS_PER_SECOND) {
                xil_printf("rate %u fps  frames=%lu stitch=%lu skip=%lu "
                           "send=%ums mean=%u L=%u R=%u cFB=%u/%u "
                           "pkt=%u/%u live=%d/%d\r\n",
                           (unsigned)sent_since,
                           (unsigned long)frames,
                           (unsigned long)stitch_id,
                           (unsigned long)skip_tx,
                           (unsigned)net_last_send_ms(),
                           (unsigned)out_mean,
                           (unsigned)mean_l, (unsigned)mean_r,
                           (unsigned)mipi_pipe_cam_mean(0),
                           (unsigned)mipi_pipe_cam_mean(1),
                           (unsigned)mipi_pipe_csi_pktcount(0),
                           (unsigned)mipi_pipe_csi_pktcount(1),
                           mipi_pipe_csi_streaming(0),
                           mipi_pipe_csi_streaming(1));
                sent_since = 0;
                skip_tx = 0;
                last_fps = now;
            }

            if ((now - last_hb) >= ((XTime)COUNTS_PER_SECOND * 2U)) {
                last_hb = now;
                net_announce();
                net_arp_poke();
                if (cam_ok[1])
                    (void)i2c_artix_select_hs1();
                /* Runtime: one-shot HS1 unblock, not every heartbeat. */
                if (cam_ok[1] && mipi_pipe_cam_mean(1) < 2U &&
                    mipi_pipe_csi_streaming(1)) {
                    static u8 hs1_rt_tries;
                    if (hs1_rt_tries < 3U) {
                        xil_printf("cam1 runtime black — hot-reset (%u)\r\n",
                                   (unsigned)hs1_rt_tries + 1U);
                        mipi_pipe_csi_hot_reset(1);
                        hs1_rt_tries++;
                    }
                }
                if (frames == prev_frames) {
                    xil_printf("output stalled\r\n");
                    mipi_pipe_dump_status();
                }
                prev_frames = frames;
            }
        }
    }
    return 0;
}
