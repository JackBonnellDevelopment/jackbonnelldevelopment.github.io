#ifndef MIPI_PIPE_H
#define MIPI_PIPE_H

#include "xil_types.h"

#ifndef SENSOR_WIDTH
#define SENSOR_WIDTH  1920U
#define SENSOR_HEIGHT 1080U
#endif

/*
 * Capture: CSI -> demosaic -> VPSS bilinear -> v_frmbuf_wr (320x180 RGB8).
 * Sync:    PS waits until both writers finish, then stitches side-by-side.
 * Output:  640x180 RGB8 in DDR -> UDP (paced at UDP_MAX_FPS).
 * CSI COREENB is set only after VPSS and frmbuf are already accepting.
 */
#define CAP_WIDTH    320U
#define CAP_HEIGHT   180U
#define CAP_STRIDE   (CAP_WIDTH * 3U)
#define CAP_FRAME_B  (CAP_STRIDE * CAP_HEIGHT)

#define CAM_WIDTH    CAP_WIDTH
#define CAM_HEIGHT   CAP_HEIGHT
#define CAM_STRIDE   CAP_STRIDE
#define CAM_FRAME_B  CAP_FRAME_B

#define OUT_TILE_W   CAM_WIDTH
#define OUT_TILE_H   CAM_HEIGHT
#define OUT_CAM1_X   320U
#define OUT_WIDTH    640U
#define OUT_HEIGHT   180U
#define OUT_STRIDE   (OUT_WIDTH * 3U)
#define OUT_FRAME_B  (OUT_STRIDE * OUT_HEIGHT)

#define OUT_FB0      0x20000000UL
#define OUT_FB1      0x20080000UL
#define CAM0_FB0     0x21000000UL
#define CAM0_FB1     0x21080000UL
#define CAM1_FB0     0x21200000UL
#define CAM1_FB1     0x21280000UL

/* Legacy constants kept for older snippets that still reference mix/TPG. */
#define TPG_PAT_SOLID_BLUE  6U
#define TPG_PAT_SOLID_BLACK 7U
#define TPG_PAT_COLOR_BARS  9U

#define MIX_LAYER_MASTER 0x1U
#define MIX_LAYER_CAM0   0x2U
#define MIX_LAYER_CAM1   0x4U
#define MIX_LAYER_ALL    0x7U

int  mipi_pipe_init(void);
int  mipi_pipe_arm_pipe(unsigned cam);
void mipi_pipe_csi_kick(unsigned cam);
void mipi_pipe_csi_core_on(unsigned cam);
void mipi_pipe_csi_reset_idle(unsigned cam);
void mipi_pipe_csi_hot_reset(unsigned cam);
u32  mipi_pipe_csi_pktcount(unsigned cam);
u32  mipi_pipe_csi_csr(unsigned cam);
u32  mipi_pipe_csi_clkinfr(unsigned cam);
int  mipi_pipe_csi_raw10_ok(unsigned cam);
int  mipi_pipe_csi_streaming(unsigned cam);
/* Poll cam writers; when both done, stitch into DDR and return 1. */
u32  mipi_pipe_harvest(unsigned cam);
UINTPTR mipi_pipe_out_fb(void);
void mipi_pipe_dump_status(void);
void mipi_pipe_dump_mix_layers(void);
u32  mipi_pipe_out_mean(void);
void mipi_pipe_half_means(u32 *left, u32 *right);
void mipi_pipe_tile_means(u32 *left, u32 *right);
int  mipi_pipe_wait_frame(u32 timeout_ms);
void mipi_pipe_sync_service(void);
u32  mipi_pipe_cam_mean(unsigned cam);
void mipi_pipe_restart_ingest(unsigned cam);

/* Kept for link compatibility with older main snippets (no-ops / TPG-only). */
int  mipi_pipe_start_layers(u32 layer_mask, u32 tpg_pattern);
int  mipi_pipe_start_tpg_bars(void);
void mipi_pipe_set_layer_enable(u32 layer_mask);
void mipi_pipe_start_synced_readers(void);
void mipi_pipe_set_mix_xy(u32 l1_x, u32 l2_x);

#endif
