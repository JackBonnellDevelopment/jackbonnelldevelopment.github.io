/******************************************************************************
 * Sony IMX219 2-lane RAW10 1920x1080 (Raspberry Pi Camera Module v2)
 * Register set aligned with Linux drivers/media/i2c/imx219.c (2-lane PLL).
 *****************************************************************************/
#include "cam_imx219.h"
#include "mipi_pipe.h"
#include "xil_printf.h"
#include "sleep.h"

typedef struct {
    u16 reg;
    u8  val;
} Imx219Reg;

/* Linux imx219_common_regs + imx219_2lane_regs + 1080p crop */
static const Imx219Reg kMode1920x1080[] = {
    {0x0100, 0x00}, /* standby */
    {0x30eb, 0x05}, {0x30eb, 0x0c}, {0x300a, 0xff}, {0x300b, 0xff},
    {0x30eb, 0x05}, {0x30eb, 0x09},
    {0x0114, 0x01}, /* 2-lane */
    {0x0128, 0x00}, /* DPHY timing auto */
    {0x012a, 0x18}, {0x012b, 0x00}, /* EXCK 24 MHz */
    /* PLL 2-lane (Linux imx219_2lane_regs) */
    {0x0301, 0x05}, {0x0303, 0x01}, {0x0304, 0x03}, {0x0305, 0x03},
    {0x0306, 0x00}, {0x0307, 0x39}, /* VT_MPY 57 */
    {0x0309, 0x0a}, /* OPPXCK_DIV = 10 bpp */
    {0x030b, 0x01}, {0x030c, 0x00}, {0x030d, 0x72}, /* OP_MPY 114 */
    /* CSI data format RAW10 (was missing — required by Linux driver) */
    {0x018c, 0x0a}, {0x018d, 0x0a},
    /* 1080p crop window (centred) */
    {0x0164, 0x02}, {0x0165, 0xa8}, /* x start 680 */
    {0x0166, 0x0a}, {0x0167, 0x27}, /* x end 2599 */
    {0x0168, 0x01}, {0x0169, 0x48}, /* y start 328 */
    {0x016a, 0x05}, {0x016b, 0x1f}, /* y end 1311 */
    {0x016c, 0x07}, {0x016d, 0x80}, /* 1920 */
    {0x016e, 0x04}, {0x016f, 0x38}, /* 1080 */
    {0x0160, 0x04}, {0x0161, 0x59}, /* VTS 1113 */
    {0x0162, 0x0d}, {0x0163, 0x78}, /* line length 3448 */
    {0x0170, 0x01}, {0x0171, 0x01}, /* odd inc */
    {0x0174, 0x00}, {0x0175, 0x00}, /* no binning */
    {0x0624, 0x07}, {0x0625, 0x80}, /* TP window 1920 */
    {0x0626, 0x04}, {0x0627, 0x38}, /* TP window 1080 */
    {0x455e, 0x00}, {0x471e, 0x4b}, {0x4767, 0x0f}, {0x4750, 0x14},
    {0x4540, 0x00}, {0x47b4, 0x14}, {0x4713, 0x30}, {0x478b, 0x10},
    {0x478f, 0x10}, {0x4793, 0x10}, {0x4797, 0x0e}, {0x479b, 0x0e},
    /* High gain / exposure for indoor */
    {0x0157, 0xe0},
    {0x0158, 0x02}, {0x0159, 0x00}, /* digital gain 2.0x */
    {0x015a, 0x04}, {0x015b, 0x40}, /* exposure */
};

static int wr16(cam_i2c_write_fn wr, void *ctx, u16 reg, u8 val)
{
    return wr(ctx, IMX219_I2C_ADDR, reg, val);
}

static int rd16(cam_i2c_read_fn rd, void *ctx, u16 reg, u8 *val)
{
    return rd(ctx, IMX219_I2C_ADDR, reg, val);
}

int imx219_detect(cam_i2c_write_fn wr, cam_i2c_read_fn rd, void *ctx)
{
    u8 hi = 0, lo = 0;
    u16 id;
    (void)wr;
    if (rd16(rd, ctx, IMX219_CHIP_ID_H, &hi) != 0)
        return -1;
    if (rd16(rd, ctx, IMX219_CHIP_ID_L, &lo) != 0)
        return -1;
    id = ((u16)hi << 8) | lo;
    xil_printf("IMX219 chip id = 0x%04x\r\n", id);
    return (id == IMX219_CHIP_ID) ? 0 : -1;
}

int imx219_init(cam_i2c_write_fn wr, cam_i2c_read_fn rd, void *ctx)
{
    unsigned i;
    if (imx219_detect(wr, rd, ctx) != 0) {
        xil_printf("ERROR: IMX219 not detected\r\n");
        return -1;
    }
    /* Soft reset then wait (Linux XCLR delay ballpark). */
    (void)wr16(wr, ctx, 0x0103, 0x01);
    usleep(10000);
    for (i = 0; i < sizeof(kMode1920x1080) / sizeof(kMode1920x1080[0]); i++) {
        if (wr16(wr, ctx, kMode1920x1080[i].reg, kMode1920x1080[i].val) != 0) {
            xil_printf("ERROR: IMX219 write 0x%04x\r\n", kMode1920x1080[i].reg);
            return -1;
        }
    }
    xil_printf("IMX219 programmed %ux%u RAW10 2-lane\r\n",
               SENSOR_WIDTH, SENSOR_HEIGHT);
    return 0;
}

int imx219_stream_on(cam_i2c_write_fn wr, void *ctx)
{
    return wr16(wr, ctx, 0x0100, 0x01);
}

int imx219_stream_off(cam_i2c_write_fn wr, void *ctx)
{
    return wr16(wr, ctx, 0x0100, 0x00);
}

/*
 * pattern: 0=off, 1=solid colour, 2=colour bars (Linux IMX219_TEST_PATTERN_*).
 * Solid white uses max R/Gr/B/Gb components.
 */
int imx219_set_test_pattern(cam_i2c_write_fn wr, void *ctx, u16 pattern)
{
    if (wr16(wr, ctx, 0x0600, (u8)((pattern >> 8) & 0xffU)) != 0)
        return -1;
    if (wr16(wr, ctx, 0x0601, (u8)(pattern & 0xffU)) != 0)
        return -1;
    if (pattern == 1U) {
        /* Solid white @ 10-bit full scale */
        static const u16 comps[4] = {0x03ff, 0x03ff, 0x03ff, 0x03ff};
        static const u16 regs[4] = {0x0602, 0x0604, 0x0606, 0x0608};
        unsigned i;
        for (i = 0; i < 4U; i++) {
            if (wr16(wr, ctx, regs[i], (u8)((comps[i] >> 8) & 0xffU)) != 0)
                return -1;
            if (wr16(wr, ctx, (u16)(regs[i] + 1U),
                     (u8)(comps[i] & 0xffU)) != 0)
                return -1;
        }
    }
    return 0;
}
