################################################################################
# Lean Artix-7 companion for dual MIPI UDP
# xc7a35t: I2C mux (HS1 camera) + CR00240 CSI GPIO held high
################################################################################
set script_dir [file dirname [file normalize [info script]]]
set hw_dir     [file normalize [file join $script_dir ..]]
set root_dir   [file normalize [file join $hw_dir ..]]
set proj_dir   [file join $hw_dir vivado_mipi_companion]
set ip_repo    [file join $root_dir hw_artix trenz_ref ip_lib]
set constr     [file join $hw_dir constraints te0950_artix_mipi.xdc]
set bit_out    [file join $hw_dir export te0950_artix_mipi.bit]

if {![file isdirectory $ip_repo]} {
  puts "ERROR: Missing $ip_repo — run scripts/fetch_trenz_refs.ps1 first"
  exit 1
}

file mkdir [file join $hw_dir export]
file mkdir $proj_dir

create_project te0950_artix_mipi $proj_dir -part xc7a35tcsg324-2 -force
set_property target_language VHDL [current_project]
set_property ip_repo_paths [list $ip_repo] [current_project]
update_ip_catalog -rebuild

source [file join $script_dir create_bd.tcl]

add_files -fileset constrs_1 $constr

set wrapper [make_wrapper -files [get_files artix_mipi.bd] -top]
add_files -norecurse $wrapper
set_property top artix_mipi_wrapper [current_fileset]
update_compile_order -fileset sources_1

generate_target all [get_files artix_mipi.bd]
launch_runs impl_1 -to_step write_bitstream -jobs 8
wait_on_run impl_1

if {[get_property PROGRESS [get_runs impl_1]] != "100%"} {
  puts "ERROR: Artix impl did not finish"
  exit 1
}

file copy -force [lindex [glob -nocomplain [file join $proj_dir *.runs impl_1 *.bit]] 0] $bit_out
puts "INFO: Artix bitstream → $bit_out"
