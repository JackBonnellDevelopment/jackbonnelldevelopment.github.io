################################################################################
# artix_mipi BD: Trenz iic_pca9548a + HS1 camera enable
# Slave I2C from Versal 3-wire; master 0 = CRUVI HS1 SMB (IMX219 + EEPROM)
################################################################################
create_bd_design artix_mipi

create_bd_port -dir I -type clk -freq_hz 25000000 A_USR_CLK25M
create_bd_port -dir I C2C_RST

create_bd_cell -type ip -vlnv xilinx.com:ip:clk_wiz clk_wiz_0
set_property -dict [list \
  CONFIG.PRIM_IN_FREQ {25.000} \
  CONFIG.CLKOUT1_REQUESTED_OUT_FREQ {100.000} \
  CONFIG.USE_LOCKED {true} \
  CONFIG.USE_RESET {false} \
] [get_bd_cells clk_wiz_0]
connect_bd_net [get_bd_ports A_USR_CLK25M] [get_bd_pins clk_wiz_0/clk_in1]

create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset rst_0
connect_bd_net [get_bd_pins clk_wiz_0/clk_out1] [get_bd_pins rst_0/slowest_sync_clk]
connect_bd_net [get_bd_pins clk_wiz_0/locked]   [get_bd_pins rst_0/dcm_locked]
# Versal C2C_RST is aresetn (high = run)
connect_bd_net [get_bd_ports C2C_RST] [get_bd_pins rst_0/ext_reset_in]

create_bd_cell -type ip -vlnv trenz.biz:user:iic_pca9548a iic_pca9548a_0
connect_bd_net [get_bd_pins clk_wiz_0/clk_out1] [get_bd_pins iic_pca9548a_0/clk_in]
connect_bd_net [get_bd_pins rst_0/peripheral_aresetn] [get_bd_pins iic_pca9548a_0/rst_n]

# Versal 3-wire (same net names as Trenz te0950-artix)
create_bd_port -dir I IIC_SCL_I
create_bd_port -dir I IIC_SDA_I
create_bd_port -dir O IIC_SDA_O

connect_bd_net [get_bd_ports IIC_SCL_I] [get_bd_pins iic_pca9548a_0/s_scl_o]
connect_bd_net [get_bd_ports IIC_SCL_I] [get_bd_pins iic_pca9548a_0/s_scl_t]
connect_bd_net [get_bd_ports IIC_SDA_I] [get_bd_pins iic_pca9548a_0/s_sda_o]
connect_bd_net [get_bd_ports IIC_SDA_I] [get_bd_pins iic_pca9548a_0/s_sda_t]
connect_bd_net [get_bd_pins iic_pca9548a_0/s_sda_i] [get_bd_ports IIC_SDA_O]

make_bd_intf_pins_external -name C_HS1_SMB_IIC [get_bd_intf_pins iic_pca9548a_0/M0_IIC]

# CR00240 CSI GPIO0/1 on CRUVI ALERT/REFCLK — hold high so IMX219 is enabled
create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant xlconst_cam_en
set_property -dict [list CONFIG.CONST_WIDTH {2} CONFIG.CONST_VAL {3}] [get_bd_cells xlconst_cam_en]
create_bd_port -dir O -from 1 -to 0 C_HS1_CAM_GPIO
connect_bd_net [get_bd_pins xlconst_cam_en/dout] [get_bd_ports C_HS1_CAM_GPIO]

save_bd_design
if {[catch {validate_bd_design -force} err]} {
  puts "WARNING: validate_bd_design: $err"
}
puts "INFO: artix_mipi BD saved"
