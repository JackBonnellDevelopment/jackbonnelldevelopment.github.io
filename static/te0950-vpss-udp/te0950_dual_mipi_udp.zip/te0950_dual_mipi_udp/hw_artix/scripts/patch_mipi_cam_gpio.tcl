# Patch Trenz te0950-artix BD so HS1 GPIO bits are outputs default-high.
# CR00240 CSI GPIO0/1 ride CRUVI ALERT + REFCLK (same pins as Trenz C_HS1_tri_io).
# Safe for the MIPI UDP design (HDMI HPD on pin 3 is unused).
set bd [get_bd_cells -quiet axi_c_hs1]
if {$bd eq ""} {
  puts "WARNING: axi_c_hs1 not found — skip MIPI GPIO patch"
} else {
  set_property -dict [list \
    CONFIG.C_GPIO_WIDTH {2} \
    CONFIG.C_ALL_OUTPUTS {1} \
    CONFIG.C_DOUT_DEFAULT {0x00000003} \
  ] $bd
  puts "INFO: axi_c_hs1 → outputs, default 0x3 (CR00240 cam enable)"
}
