# Artix MIPI companion (xc7a35t)

Lean bitstream: Trenz `iic_pca9548a` (HS1 SMB) + CR00240 CSI GPIO held high.

```powershell
.\scripts\build_artix.ps1
```

Output: `hw_artix\export\te0950_artix_mipi.bit`

Program this **before** the Versal PDI. DIP S4 must include Artix in the JTAG chain when flashing it.
