@echo off
call "C:\Xilinx\Vivado\2024.2\settings64.bat"
vivado -mode batch -source "%~dp0scripts\create_project.tcl" -notrace
exit /b %ERRORLEVEL%
