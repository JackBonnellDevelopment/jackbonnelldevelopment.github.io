# TE0950-03 Artix xc7a35t — MIPI companion (I2C mux + CR00240 cam GPIO)
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
set_property BITSTREAM.CONFIG.UNUSEDPIN PULLUP [current_design]
set_property BITSTREAM.CONFIG.OVERTEMPPOWERDOWN ENABLE [current_design]
set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]
set_property BITSTREAM.CONFIG.CONFIGRATE 33 [current_design]
set_property CONFIG_MODE SPIx4 [current_design]

set_property PACKAGE_PIN P15 [get_ports A_USR_CLK25M]
set_property IOSTANDARD LVCMOS33 [get_ports A_USR_CLK25M]
create_clock -period 40.000 -name sys_clk_pin [get_ports A_USR_CLK25M]

# Versal 3-wire I2C + reset (bank 15 @ 1.2 V)
set_property PACKAGE_PIN K13 [get_ports IIC_SCL_I]
set_property PACKAGE_PIN J13 [get_ports IIC_SDA_O]
set_property PACKAGE_PIN B18 [get_ports IIC_SDA_I]
set_property PACKAGE_PIN A14 [get_ports C2C_RST]
set_property IOSTANDARD LVCMOS12 [get_ports {IIC_SCL_I IIC_SDA_O IIC_SDA_I C2C_RST}]

# CRUVI HS1 SMB (camera I2C) — Artix bank 14 @ 3.3 V
set_property PACKAGE_PIN T16 [get_ports C_HS1_SMB_IIC_scl_io]
set_property PACKAGE_PIN T18 [get_ports C_HS1_SMB_IIC_sda_io]
set_property IOSTANDARD LVCMOS33 [get_ports {C_HS1_SMB_IIC_*}]

# CR00240 CSI GPIO: ALERT=GPIO0 (enable), REFCLK=GPIO1
set_property PACKAGE_PIN R16 [get_ports {C_HS1_CAM_GPIO[0]}]
set_property PACKAGE_PIN N17 [get_ports {C_HS1_CAM_GPIO[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {C_HS1_CAM_GPIO[*]}]
