-------------------------------------------------------------------------------
-- Company: 		Trenz Electronic GmbH
-- Engineer: 		Oleksandr Kiyenko
----------------------------------------------------------------------------------
library ieee;
use ieee.STD_LOGIC_1164.all;
use ieee.numeric_std.all;
library UNISIM; 
use UNISIM.VCOMPONENTS.ALL;
----------------------------------------------------------------------------------
entity iic_to_3wire is
generic(
	C_MODE					: integer range 0 to 1	:= 0	-- 0=3 wire, 1=4 wire
);
port (
	-- Slave IIC
	iic_scl_I				: out STD_LOGIC;
	iic_scl_O				: in  STD_LOGIC;
	iic_scl_T				: in  STD_LOGIC;
	iic_sda_I				: out STD_LOGIC;
	iic_sda_O				: in  STD_LOGIC;
	iic_sda_T				: in  STD_LOGIC;
	
	SCL_out					: out STD_LOGIC;
	SCL_in					: in  STD_LOGIC;
	SDA_out					: out STD_LOGIC;
	SDA_in					: in  STD_LOGIC
);
end iic_to_3wire;
----------------------------------------------------------------------------------
architecture arch_imp of iic_to_3wire is
----------------------------------------------------------------------------------
begin
----------------------------------------------------------------------------------
SCL_out			<= iic_scl_T;
mode3wire_gen: if C_MODE = 0 generate
	iic_scl_I	<= iic_scl_T;
end generate;
mode4wire_gen: if C_MODE = 1 generate
	iic_scl_I	<= SCL_in and iic_scl_T;
end generate;

SDA_out			<= iic_sda_T;
iic_sda_I		<= SDA_in and iic_sda_T;
----------------------------------------------------------------------------------
end arch_imp;
