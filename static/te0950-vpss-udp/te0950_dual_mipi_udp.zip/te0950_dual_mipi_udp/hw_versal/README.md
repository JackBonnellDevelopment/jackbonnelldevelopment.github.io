# Dual MIPI CSI-2 → UDP (Versal)

## Cameras

| Stream | Connector | Sensor I2C | MIPI pins |
|--------|-----------|------------|-----------|
| cam0 | TE0950 **J15** 15-pin CSI | AXI IIC @ A13/B13, GPIO F11/E11 | CLK H25/J26, D0 G25/G26, D1 F26/E26 |
| cam1 | **CR00240** J4 on **CRUVI HS1 (J10)** | Artix PCA9548 ch0 → HS1 SMB | CLK HS1_B2 (J27), D0 HS1_B3 (H27), D1 HS1_B4 (G27) |

CR00240 CSI lane map matches CR00300 (CLK=B2, D0=B3, D1=B4). HDMI TMDS on A1/A2/A3/B1 is unused in this design.

## Build

From repo root (Vivado 2024.2 on PATH):

```powershell
.\scripts\fetch_trenz_refs.ps1
.\scripts\build_hw.ps1
```

XSA: `hw_versal\export\te0950_dual_mipi_udp.xsa`

MIPI CSI-2 Rx Subsystem must be licensed in Vivado. If batch CIPS/NoC automation fails, open the generated project and follow `scripts/create_bd_gui_checklist.tcl`.

## Pipeline

```text
IMX219 → MIPI CSI-2 RX (2-lane RAW10, 2 ppc)
       → v_demosaic → RGB8 subset → VPSS (320×180) → v_frmbuf_wr → DDR4
  ×2 (J15 + HS1)
A72 stitches 320|320 → 640×180 RGB8 and UDP-sends to 192.168.8.220:55000 (paced at 25 fps)
```

No PL `v_mix` / TPG / `frmbuf_rd` — see `scripts/create_bd.tcl`.
