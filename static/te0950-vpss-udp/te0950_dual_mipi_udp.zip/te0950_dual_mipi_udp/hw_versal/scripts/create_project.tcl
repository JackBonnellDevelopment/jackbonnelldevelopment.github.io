################################################################################
# create_project.tcl — batch build TE0950 dual MIPI UDP (Versal)
################################################################################
set script_dir [file dirname [file normalize [info script]]]
source [file join $script_dir project_config.tcl]

set root_dir   [file normalize [file join $script_dir .. ..]]
set hw_dir     [file normalize [file join $script_dir ..]]
set proj_dir   [file join $hw_dir vivado_project]
set constr     [file join $hw_dir constraints dual_mipi.xdc]
set constr_iic [file join $hw_dir constraints artix_iic_bridge.xdc]
set xsa_out    [file join $hw_dir export ${::PROJ_NAME}.xsa]
set board_repo [file join $root_dir board_files trenz]
set ip_repo    [file join $root_dir hw_versal ip_repo]

file mkdir [file join $hw_dir export]
file mkdir $proj_dir

puts "INFO: board_repo=$board_repo"
set_param board.repoPaths [list $board_repo]
# Nested PHY regen (CSI + DDRMC) must not spawn extra rodin slaves on Windows.
set_param general.maxThreads 1
catch { set_param synth.maxThreads 1 }
catch { set_param chipscope.maxJobs 1 }

create_project $::PROJ_NAME $proj_dir -part $::TE0950_PART -force
set_property board_part $::TE0950_BOARD [current_project]
set_property target_language Verilog [current_project]
set_property ip_repo_paths [list $ip_repo] [current_project]
update_ip_catalog -rebuild

source [file join $script_dir create_bd.tcl]

add_files -fileset constrs_1 $constr
if {[file isfile $constr_iic]} {
  add_files -fileset constrs_1 $constr_iic
}

set wrapper [make_wrapper -files [get_files system.bd] -top]
add_files -norecurse $wrapper
set_property top system_wrapper [current_fileset]
update_compile_order -fileset sources_1

# Global synth: one checkpoint, fewer OOC workers before DDR PHY regen.
set_property synth_checkpoint_mode None [get_files system.bd]
generate_target all [get_files system.bd]

set_property STEPS.ROUTE_DESIGN.ARGS.DIRECTIVE Quick [get_runs impl_1]

proc te0950_run_impl {} {
  puts "INFO: Launching synth + impl (write_device_image), jobs=1..."
  if {[catch {
    launch_runs impl_1 -to_step write_device_image -jobs 1
    wait_on_run impl_1
  } err]} {
    puts "WARNING: impl launch/wait failed: $err"
  }
  set status [get_property STATUS [get_runs impl_1]]
  set prog   [get_property PROGRESS [get_runs impl_1]]
  puts "INFO: impl_1 STATUS=$status PROGRESS=$prog"
  return [list $status $prog]
}

proc te0950_pdi_list {proj_dir} {
  return [glob -nocomplain [file join $proj_dir *.runs impl_1 *.pdi]]
}

# Windows Vivado often fails DDR PHY regen once with rodin:slaveN; reset + retry.
set max_tries 6
set pdi_candidates {}
for {set try 1} {$try <= $max_tries} {incr try} {
  if {$try > 1} {
    puts "WARNING: Retry $try/$max_tries after rodin/DDR PHY or empty PDI..."
    catch { reset_run impl_1 }
    after 5000
  }
  lassign [te0950_run_impl] status prog
  set pdi_candidates [te0950_pdi_list $proj_dir]
  if {[llength $pdi_candidates] > 0 || $prog eq "100%"} {
    break
  }
}
if {[llength $pdi_candidates] == 0 && $prog != "100%"} {
  puts "ERROR: Implementation did not complete successfully after $max_tries tries."
  exit 1
}

write_hw_platform -fixed -include_bit -force -file $xsa_out
puts "INFO: XSA written to $xsa_out"
puts "INFO: Done."
