################################################################################
# create_bd.tcl — Dual MIPI → demosaic → VPSS → v_frmbuf_wr → DDR
#
# Scaler-only VPSS, bilinear, 1920x1080 → 320x180 @2ppc.
# Software starts VPSS + frmbuf before setting CSI COREENB.
#
# cam0/cam1: CSI → demosaic → RGB8 @2ppc → v_proc_ss → frmbuf tile
################################################################################

create_bd_design system

proc te0950_apply_cips {} {
  set_property -dict [list \
    CONFIG.CLOCK_MODE {Custom} \
    CONFIG.PS_PL_CONNECTIVITY_MODE {Custom} \
    CONFIG.PS_PMC_CONFIG { \
      CLOCK_MODE {Custom} \
      DESIGN_MODE {1} \
      PMC_CRP_PL0_REF_CTRL_FREQMHZ {100} \
      PMC_CRP_PL1_REF_CTRL_FREQMHZ {200} \
      PMC_REF_CLK_FREQMHZ {33.333333} \
      PMC_CRP_HSM0_REF_CTRL_FREQMHZ {33.333333} \
      PMC_USE_PMC_NOC_AXI0 {1} \
      PS_USE_FPD_CCI_NOC {1} \
      PS_USE_NOC_LPD_AXI0 {1} \
      PS_USE_PMCPL_CLK0 {1} \
      PS_USE_PMCPL_CLK1 {1} \
      PS_NUM_FABRIC_RESETS {1} \
      PS_PL_CONNECTIVITY_MODE {Custom} \
      PS_USE_M_AXI_FPD {1} \
      PS_M_AXI_FPD_DATA_WIDTH {128} \
      PS_UART1_PERIPHERAL {{ENABLE 1} {IO {PS_MIO 12 .. 13}}} \
      PS_I2C0_PERIPHERAL {{ENABLE 1} {IO EMIO}} \
      PS_ENET0_PERIPHERAL {{ENABLE 1} {IO {PS_MIO 0 .. 11}}} \
      PS_ENET0_MDIO {{ENABLE 1} {IO {PS_MIO 24 .. 25}}} \
      PS_MIO23 {{AUX_IO 0} {DIRECTION out} {DRIVE_STRENGTH 8mA} {OUTPUT_DATA high} {PULL pullup} {SCHMITT 0} {SLEW slow} {USAGE GPIO}} \
      PS_BANK_2_IO_STANDARD {LVCMOS1.8} \
      PS_BANK_3_IO_STANDARD {LVCMOS3.3} \
      PS_IRQ_USAGE {{CH0 1} {CH1 0} {CH2 0} {CH3 0} {CH4 0} {CH5 0} {CH6 0} {CH7 0}} \
    } \
  ] [get_bd_cells versal_cips_0]
}

proc te0950_noc_conn {} {
  return [list MC_0 {read_bw {800} write_bw {800} read_avg_burst {4} write_avg_burst {4}}]
}

# Wire CIPS NOC + PL video SmartConnect (2 MM writers) + DDR.
proc te0950_wire_noc {} {
  set noc [lindex [get_bd_cells -quiet axi_noc*] 0]
  if {$noc eq ""} {
    create_bd_cell -type ip -vlnv xilinx.com:ip:axi_noc axi_noc_0
    set noc [get_bd_cells axi_noc_0]
  }

  set_property -dict [list \
    CONFIG.NUM_SI {7} \
    CONFIG.NUM_MI {0} \
    CONFIG.NUM_NSI {0} \
    CONFIG.NUM_NMI {0} \
    CONFIG.NUM_CLKS {7} \
    CONFIG.NUM_MC {1} \
    CONFIG.NUM_MCP {4} \
  ] $noc

  set pairs [list \
    FPD_CCI_NOC_0 S00_AXI \
    FPD_CCI_NOC_1 S01_AXI \
    FPD_CCI_NOC_2 S02_AXI \
    FPD_CCI_NOC_3 S03_AXI \
    LPD_AXI_NOC_0 S04_AXI \
    PMC_NOC_AXI_0 S05_AXI \
  ]
  foreach {cips si} $pairs {
    if {[llength [get_bd_intf_pins -quiet versal_cips_0/$cips]] && \
        [llength [get_bd_intf_nets -quiet -of_objects [get_bd_intf_pins $noc/$si]]] == 0} {
      connect_bd_intf_net [get_bd_intf_pins versal_cips_0/$cips] [get_bd_intf_pins $noc/$si]
    }
  }
  if {[llength [get_bd_intf_nets -quiet -of_objects [get_bd_intf_pins $noc/S06_AXI]]] == 0} {
    connect_bd_intf_net [get_bd_intf_pins axi_smc_mm/M00_AXI] [get_bd_intf_pins $noc/S06_AXI]
  }

  set clk_pairs [list \
    fpd_cci_noc_axi0_clk aclk0 \
    fpd_cci_noc_axi1_clk aclk1 \
    fpd_cci_noc_axi2_clk aclk2 \
    fpd_cci_noc_axi3_clk aclk3 \
    lpd_axi_noc_clk      aclk4 \
    pmc_axi_noc_axi0_clk aclk5 \
    pl0_ref_clk          aclk6 \
  ]
  foreach {src dst} $clk_pairs {
    if {[llength [get_bd_pins -quiet versal_cips_0/$src]] == 0} {
      puts "WARNING: missing CIPS clock pin $src"
      continue
    }
    if {[llength [get_bd_nets -quiet -of_objects [get_bd_pins $noc/$dst]]] == 0} {
      connect_bd_net [get_bd_pins versal_cips_0/$src] [get_bd_pins $noc/$dst]
    }
  }

  catch {
    apply_bd_automation -rule xilinx.com:bd_rule:board \
      -config {Board_Interface {ddr4_bank0} Manual_Source {Auto}} \
      [get_bd_intf_pins $noc/CH0_DDR4_0]
  }
  catch {
    apply_bd_automation -rule xilinx.com:bd_rule:board \
      -config {Board_Interface {ddr4_bank0_sys_clk} Manual_Source {Auto}} \
      [get_bd_intf_pins $noc/sys_clk0]
  }

  set cats [list ps_cci ps_cci ps_cci ps_cci ps_rpu ps_pmc pl]
  for {set i 0} {$i < 7} {incr i} {
    set pin [get_bd_intf_pins $noc/[format "S%02d_AXI" $i]]
    set cat [lindex $cats $i]
    catch {
      set_property -dict [list \
        CONFIG.CONNECTIONS [te0950_noc_conn] \
        CONFIG.CATEGORY $cat \
      ] $pin
    }
    catch {
      set_property CONFIG.ASSOCIATED_BUSIF [format "S%02d_AXI" $i] \
        [get_bd_pins $noc/[format "aclk%d" $i]]
    }
  }
  puts "INFO: NoC SI=[get_bd_intf_pins -quiet $noc/S*_AXI]"
}

proc te0950_clk_rst {cell} {
  foreach pin [list ap_clk aclk s_axi_aclk s_axis_aclk m_axis_aclk aclk_axis aclk_ctrl] {
    if {[llength [get_bd_pins -quiet $cell/$pin]]} {
      connect_bd_net [get_bd_pins versal_cips_0/pl0_ref_clk] [get_bd_pins $cell/$pin]
    }
  }
  foreach pin [list ap_rst_n aresetn s_axi_aresetn s_axis_aresetn aresetn_ctrl] {
    if {[llength [get_bd_pins -quiet $cell/$pin]]} {
      connect_bd_net [get_bd_pins rst_pl0/peripheral_aresetn] [get_bd_pins $cell/$pin]
    }
  }
}

#------------------------------------------------------------------------------
# CIPS + resets + AXI-Lite SMC (8 MI)
#------------------------------------------------------------------------------
create_bd_cell -type ip -vlnv xilinx.com:ip:versal_cips versal_cips_0
te0950_apply_cips

create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset rst_pl0
create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset rst_pl1
connect_bd_net [get_bd_pins versal_cips_0/pl0_ref_clk] [get_bd_pins rst_pl0/slowest_sync_clk]
connect_bd_net [get_bd_pins versal_cips_0/pl1_ref_clk] [get_bd_pins rst_pl1/slowest_sync_clk]
connect_bd_net [get_bd_pins versal_cips_0/pl0_resetn]  [get_bd_pins rst_pl0/ext_reset_in]
connect_bd_net [get_bd_pins versal_cips_0/pl0_resetn]  [get_bd_pins rst_pl1/ext_reset_in]

# M00 CSI0, M01 CSI1, M02 IIC, M03 GPIO,
# M04 Demo0, M05 Demo1, M06 Cam0Wr, M07 Cam1Wr, M08 VPSS0, M09 VPSS1
create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect axi_smc
set_property -dict [list CONFIG.NUM_SI {1} CONFIG.NUM_MI {10}] [get_bd_cells axi_smc]
connect_bd_net [get_bd_pins versal_cips_0/pl0_ref_clk] [get_bd_pins axi_smc/aclk]
connect_bd_net [get_bd_pins rst_pl0/peripheral_aresetn] [get_bd_pins axi_smc/aresetn]
connect_bd_intf_net [get_bd_intf_pins versal_cips_0/M_AXI_FPD] [get_bd_intf_pins axi_smc/S00_AXI]
connect_bd_net [get_bd_pins versal_cips_0/pl0_ref_clk] [get_bd_pins versal_cips_0/m_axi_fpd_aclk]

#------------------------------------------------------------------------------
# Helper: MIPI → demosaic → RGB8 → VPSS → v_frmbuf_wr (tile)
#------------------------------------------------------------------------------
proc add_mipi_pipe {name smc_csi smc_vpss} {
  set csi    mipi_csi_${name}
  set demo   v_demosaic_${name}
  set subset axis_rgb8_${name}
  set vpss   v_proc_ss_${name}
  set wr     v_frmbuf_wr_${name}

  create_bd_cell -type ip -vlnv xilinx.com:ip:mipi_csi2_rx_subsystem $csi
  set_property -dict [list \
    CONFIG.C_DPHY_LANES {2} \
    CONFIG.CMN_NUM_LANES {2} \
    CONFIG.CMN_PXL_FORMAT {RAW10} \
    CONFIG.CMN_NUM_PIXELS {2} \
    CONFIG.CMN_INC_VFB {true} \
    CONFIG.CMN_INC_IIC {false} \
    CONFIG.C_EN_CSI_V2_0 {true} \
    CONFIG.C_CSI_EN_ACTIVELANES {true} \
    CONFIG.DPY_LINE_RATE {1500} \
    CONFIG.SupportLevel {1} \
  ] [get_bd_cells $csi]

  create_bd_cell -type ip -vlnv xilinx.com:ip:v_demosaic $demo
  set_property -dict [list \
    CONFIG.SAMPLES_PER_CLOCK {2} \
    CONFIG.MAX_DATA_WIDTH {10} \
    CONFIG.MAX_COLS $::VIDEO_WIDTH \
    CONFIG.MAX_ROWS $::VIDEO_HEIGHT \
    CONFIG.ALGORITHM {0} \
    CONFIG.ENABLE_ZIPPER_REMOVAL {true} \
  ] [get_bd_cells $demo]

  create_bd_cell -type ip -vlnv xilinx.com:ip:axis_subset_converter $subset
  set_property -dict [list \
    CONFIG.S_TDATA_NUM_BYTES {8} \
    CONFIG.M_TDATA_NUM_BYTES {6} \
    CONFIG.S_HAS_TLAST {1} \
    CONFIG.M_HAS_TLAST {1} \
    CONFIG.S_TUSER_WIDTH {1} \
    CONFIG.M_TUSER_WIDTH {1} \
    CONFIG.TDATA_REMAP {tdata[59:52],tdata[49:42],tdata[39:32],tdata[29:22],tdata[19:12],tdata[9:2]} \
    CONFIG.TUSER_REMAP {tuser[0:0]} \
    CONFIG.TLAST_REMAP {tlast[0]} \
  ] [get_bd_cells $subset]

  create_bd_cell -type ip -vlnv xilinx.com:ip:v_proc_ss $vpss
  set_property -dict [list \
    CONFIG.C_TOPOLOGY {0} \
    CONFIG.C_SCALER_ALGORITHM {0} \
    CONFIG.C_SAMPLES_PER_CLK {2} \
    CONFIG.C_MAX_DATA_WIDTH {8} \
    CONFIG.C_NUM_VIDEO_COMPONENTS {3} \
    CONFIG.C_MAX_COLS $::VIDEO_WIDTH \
    CONFIG.C_MAX_ROWS $::VIDEO_HEIGHT \
    CONFIG.C_COLORSPACE_SUPPORT {2} \
    CONFIG.C_ENABLE_DMA {false} \
    CONFIG.C_ENABLE_INTERLACED {false} \
  ] [get_bd_cells $vpss]

  create_bd_cell -type ip -vlnv xilinx.com:ip:v_frmbuf_wr $wr
  set_property -dict [list \
    CONFIG.AXIMM_DATA_WIDTH {128} \
    CONFIG.SAMPLES_PER_CLOCK {2} \
    CONFIG.MAX_COLS $::TILE_WIDTH \
    CONFIG.MAX_ROWS $::TILE_HEIGHT \
    CONFIG.MAX_NR_PLANES {1} \
    CONFIG.MAX_DATA_WIDTH {8} \
    CONFIG.HAS_RGB8 {1} \
    CONFIG.HAS_Y8 {1} \
    CONFIG.HAS_YUYV8 {0} \
  ] [get_bd_cells $wr]

  foreach pin [list video_aclk lite_aclk] {
    if {[llength [get_bd_pins -quiet $csi/$pin]]} {
      connect_bd_net [get_bd_pins versal_cips_0/pl0_ref_clk] [get_bd_pins $csi/$pin]
    }
  }
  if {[llength [get_bd_pins -quiet $csi/dphy_clk_200M]]} {
    connect_bd_net [get_bd_pins versal_cips_0/pl1_ref_clk] [get_bd_pins $csi/dphy_clk_200M]
  }
  foreach pin [list video_aresetn lite_aresetn] {
    if {[llength [get_bd_pins -quiet $csi/$pin]]} {
      connect_bd_net [get_bd_pins rst_pl0/peripheral_aresetn] [get_bd_pins $csi/$pin]
    }
  }
  if {[llength [get_bd_pins -quiet $csi/dphy_reset_n]]} {
    connect_bd_net [get_bd_pins rst_pl1/peripheral_aresetn] [get_bd_pins $csi/dphy_reset_n]
  }

  te0950_clk_rst $demo
  te0950_clk_rst $subset
  te0950_clk_rst $vpss
  te0950_clk_rst $wr

  connect_bd_intf_net [get_bd_intf_pins $csi/video_out] [get_bd_intf_pins $demo/s_axis_video]
  connect_bd_intf_net [get_bd_intf_pins $demo/m_axis_video] [get_bd_intf_pins $subset/S_AXIS]
  connect_bd_intf_net [get_bd_intf_pins $subset/M_AXIS] [get_bd_intf_pins $vpss/s_axis]
  connect_bd_intf_net [get_bd_intf_pins $vpss/m_axis] [get_bd_intf_pins $wr/s_axis_video]
  connect_bd_intf_net [get_bd_intf_pins axi_smc/$smc_csi] [get_bd_intf_pins $csi/csirxss_s_axi]
  connect_bd_intf_net [get_bd_intf_pins axi_smc/$smc_vpss] [get_bd_intf_pins $vpss/s_axi_ctrl]
}

# Match tutorial: each CSI owns its DPHY PLL (SupportLevel=1). Bank 703 has
# two XPHY PLLs — one per camera.
add_mipi_pipe cam0 M00_AXI M08_AXI
add_mipi_pipe cam1 M01_AXI M09_AXI

#------------------------------------------------------------------------------
# MM SmartConnect: cam0/1 writers only → NoC
#------------------------------------------------------------------------------
create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect axi_smc_mm
set_property -dict [list CONFIG.NUM_SI {2} CONFIG.NUM_MI {1}] [get_bd_cells axi_smc_mm]
connect_bd_net [get_bd_pins versal_cips_0/pl0_ref_clk] [get_bd_pins axi_smc_mm/aclk]
connect_bd_net [get_bd_pins rst_pl0/peripheral_aresetn] [get_bd_pins axi_smc_mm/aresetn]

connect_bd_intf_net [get_bd_intf_pins v_frmbuf_wr_cam0/m_axi_mm_video] [get_bd_intf_pins axi_smc_mm/S00_AXI]
connect_bd_intf_net [get_bd_intf_pins v_frmbuf_wr_cam1/m_axi_mm_video] [get_bd_intf_pins axi_smc_mm/S01_AXI]

# AXI-Lite
connect_bd_intf_net [get_bd_intf_pins axi_smc/M04_AXI] [get_bd_intf_pins v_demosaic_cam0/s_axi_CTRL]
connect_bd_intf_net [get_bd_intf_pins axi_smc/M05_AXI] [get_bd_intf_pins v_demosaic_cam1/s_axi_CTRL]
connect_bd_intf_net [get_bd_intf_pins axi_smc/M06_AXI] [get_bd_intf_pins v_frmbuf_wr_cam0/s_axi_CTRL]
connect_bd_intf_net [get_bd_intf_pins axi_smc/M07_AXI] [get_bd_intf_pins v_frmbuf_wr_cam1/s_axi_CTRL]

#------------------------------------------------------------------------------
# J15 I2C + GPIO + Artix bridge
#------------------------------------------------------------------------------
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_iic axi_iic_cam0
set_property CONFIG.IIC_FREQ_KHZ {100} [get_bd_cells axi_iic_cam0]
te0950_clk_rst axi_iic_cam0
connect_bd_intf_net [get_bd_intf_pins axi_smc/M02_AXI] [get_bd_intf_pins axi_iic_cam0/S_AXI]
make_bd_intf_pins_external -name cam0_iic [get_bd_intf_pins axi_iic_cam0/IIC]

create_bd_cell -type ip -vlnv xilinx.com:ip:axi_gpio axi_gpio_cam0
set_property -dict [list \
  CONFIG.C_GPIO_WIDTH {2} \
  CONFIG.C_ALL_OUTPUTS {1} \
  CONFIG.C_DOUT_DEFAULT {0x00000003} \
] [get_bd_cells axi_gpio_cam0]
te0950_clk_rst axi_gpio_cam0
connect_bd_intf_net [get_bd_intf_pins axi_smc/M03_AXI] [get_bd_intf_pins axi_gpio_cam0/S_AXI]
make_bd_intf_pins_external -name cam0_gpio [get_bd_intf_pins axi_gpio_cam0/GPIO]

create_bd_cell -type ip -vlnv trenz.biz:user:iic_to_3wire:1.0 iic_to_3wire_0
set_property CONFIG.C_MODE {0} [get_bd_cells iic_to_3wire_0]
connect_bd_intf_net [get_bd_intf_pins versal_cips_0/I2C0] [get_bd_intf_pins iic_to_3wire_0/IIC]
create_bd_port -dir O A_IIC_SCL_O
create_bd_port -dir O A_IIC_SDA_O
create_bd_port -dir I A_IIC_SDA_I
connect_bd_net [get_bd_pins iic_to_3wire_0/SCL_out] [get_bd_ports A_IIC_SCL_O]
connect_bd_net [get_bd_pins iic_to_3wire_0/SDA_out] [get_bd_ports A_IIC_SDA_O]
connect_bd_net [get_bd_pins iic_to_3wire_0/SDA_in]  [get_bd_ports A_IIC_SDA_I]

create_bd_port -dir O -from 0 -to 0 C2C_RST
connect_bd_net [get_bd_pins rst_pl0/interconnect_aresetn] [get_bd_ports C2C_RST]

proc expose_mipi {cell pfx} {
  if {[llength [get_bd_intf_pins -quiet $cell/mipi_phy_if]]} {
    make_bd_intf_pins_external -name $pfx [get_bd_intf_pins $cell/mipi_phy_if]
    puts "INFO: $cell/mipi_phy_if exported as $pfx"
    return
  }
  puts "WARNING: $cell/mipi_phy_if not found — connect MIPI pins in GUI"
}
expose_mipi mipi_csi_cam0 cam0
expose_mipi mipi_csi_cam1 cam1

# IRQs: CSI0, CSI1, cam0_wr, cam1_wr
create_bd_cell -type ip -vlnv xilinx.com:ip:xlconcat xlconcat_irq
set_property CONFIG.NUM_PORTS {4} [get_bd_cells xlconcat_irq]
connect_bd_net [get_bd_pins mipi_csi_cam0/csirxss_csi_irq] [get_bd_pins xlconcat_irq/In0]
connect_bd_net [get_bd_pins mipi_csi_cam1/csirxss_csi_irq] [get_bd_pins xlconcat_irq/In1]
connect_bd_net [get_bd_pins v_frmbuf_wr_cam0/interrupt]    [get_bd_pins xlconcat_irq/In2]
connect_bd_net [get_bd_pins v_frmbuf_wr_cam1/interrupt]    [get_bd_pins xlconcat_irq/In3]
if {[llength [get_bd_pins -quiet versal_cips_0/pl_ps_irq0]]} {
  connect_bd_net [get_bd_pins xlconcat_irq/dout] [get_bd_pins versal_cips_0/pl_ps_irq0]
}

te0950_wire_noc
assign_bd_address
save_bd_design

if {[catch {validate_bd_design -force} err]} {
  puts "WARNING: validate_bd_design: $err"
}

puts "INFO: Block design 'system' saved (CSI -> demosaic -> VPSS -> frmbuf)."
