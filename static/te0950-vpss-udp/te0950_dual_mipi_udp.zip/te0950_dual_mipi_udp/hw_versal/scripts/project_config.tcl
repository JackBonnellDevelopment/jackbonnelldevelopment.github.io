################################################################################
# Dual MIPI → DDR → UDP (TE0950-03 + CR00240 HS1 + onboard J15)
################################################################################
set ::TE0950_PART        "xcve2302-sfva784-1LP-e-S"
set ::TE0950_BOARD       "trenz.biz:te0950_23_1lse:part0:1.1"
set ::PROJ_NAME          "te0950_dual_mipi_udp"
set ::PL0_CLK_MHZ        100.000
set ::PL1_CLK_MHZ        200.000
# Sensor capture 1920x1080. VPSS bilinear → 320x180 tiles;
# A72 memcpy-stitches to 640x180.
set ::VIDEO_WIDTH        1920
set ::VIDEO_HEIGHT       1080
set ::TILE_WIDTH         320
set ::TILE_HEIGHT        180
set ::OUT_WIDTH          640
set ::OUT_HEIGHT         180
set ::CSI_LANES          2
set ::CSI_LINE_RATE      1500
set ::CSI_PIXEL_FORMAT   "RAW10"
set ::CSI_PPC            2
