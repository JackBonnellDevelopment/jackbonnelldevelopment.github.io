# Sourced by every Vivado process (including nested DDR/CSI PHY regen).
# AR 000037163: Windows + 2024.2 runs out of rodin slave interpreters when
# opt_design regenerates 2x MIPI CSI PHY + DDRMC PHY in one process.
if {[info exists ::env(TE0950_MIPI_BUILD)] && $::env(TE0950_MIPI_BUILD) eq "1"} {
  set_param general.maxThreads 1
  catch { set_param synth.maxThreads 1 }
  catch { set_param chipscope.maxJobs 1 }
}
