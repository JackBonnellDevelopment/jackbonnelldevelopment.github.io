#------------------------------------------------------------------------------
# TE0950 dual MIPI CSI-2
#   cam0 = onboard J15 (2-lane)
#   cam1 = CR00240 CSI on CRUVI HS1 (J10) lanes B2/B3/B4
# Wrapper ports from mipi_phy_if: cam*_clk_p/n, cam*_data_p/n
# IOSTANDARD MIPI_DPHY on XPIO bank 703 (C_VADJ = 1.2 V)
# Place the P pin only; Vivado infers the N mate for MIPI_DPHY.
#------------------------------------------------------------------------------

# ---- J15 onboard CSI-2 (board file csi_cam1) ----
set_property PACKAGE_PIN H25 [get_ports cam0_clk_p]
set_property PACKAGE_PIN G25 [get_ports {cam0_data_p[0]}]
set_property PACKAGE_PIN F26 [get_ports {cam0_data_p[1]}]
set_property IOSTANDARD MIPI_DPHY [get_ports {cam0_clk_p cam0_clk_n}]
set_property IOSTANDARD MIPI_DPHY [get_ports {cam0_data_p[*] cam0_data_n[*]}]

# J15 GPIO (enable / LED) — HDIO bank 302 @ 3.3 V
set_property PACKAGE_PIN F11 [get_ports {cam0_gpio_tri_o[0]}]
set_property PACKAGE_PIN E11 [get_ports {cam0_gpio_tri_o[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {cam0_gpio_tri_o[*]}]

# J15 camera I2C
set_property PACKAGE_PIN A13 [get_ports cam0_iic_scl_io]
set_property PACKAGE_PIN B13 [get_ports cam0_iic_sda_io]
set_property IOSTANDARD LVCMOS33 [get_ports {cam0_iic_scl_io cam0_iic_sda_io}]

# ---- CR00240 CSI on HS1 (CLK=B2, D0=B3, D1=B4) ----
set_property PACKAGE_PIN J27 [get_ports cam1_clk_p]
set_property PACKAGE_PIN H27 [get_ports {cam1_data_p[0]}]
set_property PACKAGE_PIN G27 [get_ports {cam1_data_p[1]}]
set_property IOSTANDARD MIPI_DPHY [get_ports {cam1_clk_p cam1_clk_n}]
set_property IOSTANDARD MIPI_DPHY [get_ports {cam1_data_p[*] cam1_data_n[*]}]
