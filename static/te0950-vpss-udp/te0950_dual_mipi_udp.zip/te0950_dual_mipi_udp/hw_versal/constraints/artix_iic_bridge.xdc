#------------------------------------------------------------------------------
# Versal ↔ Artix I2C bridge + C2C_RST (Trenz TE0950 _i_io.xdc)
# Soft PCA9548 on Artix sits on this bus (addr 0x70); HS1 SMB is mux ch0.
# C2C_RST must be high or Artix mux stays in reset → I2C NACK @ 0x70.
#------------------------------------------------------------------------------
set_property PACKAGE_PIN T23 [get_ports A_IIC_SCL_O]
set_property PACKAGE_PIN R24 [get_ports A_IIC_SDA_I]
set_property PACKAGE_PIN R23 [get_ports A_IIC_SDA_O]
set_property IOSTANDARD LVCMOS12 [get_ports {A_IIC_SCL_O A_IIC_SDA_I A_IIC_SDA_O}]

set_property PACKAGE_PIN J22 [get_ports {C2C_RST[0]}]
set_property IOSTANDARD LVCMOS12 [get_ports {C2C_RST[*]}]
