# Online Trenz TE0950 references (Vivado 2024.2)

Do **not** use local Downloads copies. Always fetch from Trenz:

| Package | URL |
|---------|-----|
| Versal RD (noprebuilt) | https://shop.trenz-electronic.de/trenzdownloads/Trenz_Electronic/Development_Boards/TE0950/Reference_Design/2024.2/test_board/TE0950-te0950-rd_noprebuilt-vivado_2024.2-build_1_20250423075112.zip |
| Artix RD (noprebuilt) | https://shop.trenz-electronic.de/trenzdownloads/Trenz_Electronic/Development_Boards/TE0950/Reference_Design/2024.2/test_board/TE0950-te0950-artix_noprebuilt-vivado_2024.2-build_1_20250527142942.zip |
| Listing | https://shop.trenz-electronic.de/Download/?path=Trenz_Electronic/Development_Boards/TE0950/Reference_Design/2024.2/test_board |
| Wiki | https://wiki.trenz-electronic.de/display/PD/TE0950+Test+Board |

## Fetch

```powershell
.\scripts\fetch_trenz_refs.ps1
```

This downloads into `deps/trenz/` (gitignored) and installs:
- `board_files/trenz/` — Vivado board parts (`trenz.biz:te0950_23_1lse:part0:1.1`)
- `hw_artix/trenz_ref/` — Artix companion sources

Board part for TE0950-03: `trenz.biz:te0950_23_1lse:part0:1.1`  
FPGA part: `xcve2302-sfva784-1LP-e-S`
